import { IndianState, RESTRICTED_INDIAN_STATES } from '../types';

export interface GeolocationResult {
  state: IndianState;
  isRestricted: boolean;
  method: 'HTML5_GEOLOCATION' | 'IP_LOOKUP' | 'MANUAL_SIMULATION' | 'CACHED';
  rawLocation?: string;
}

const INDIAN_STATES_MAP: Record<string, IndianState> = {
  maharashtra: 'Maharashtra',
  delhi: 'Delhi',
  'new delhi': 'Delhi',
  nct: 'Delhi',
  karnataka: 'Karnataka',
  'tamil nadu': 'Tamil Nadu',
  'uttar pradesh': 'Uttar Pradesh',
  up: 'Uttar Pradesh',
  gujarat: 'Gujarat',
  'west bengal': 'West Bengal',
  bengal: 'West Bengal',
  rajasthan: 'Rajasthan',
  punjab: 'Punjab',
  haryana: 'Haryana',
  kerala: 'Kerala',
  goa: 'Goa',
  'madhya pradesh': 'Madhya Pradesh',
  mp: 'Madhya Pradesh',
  bihar: 'Bihar',
  assam: 'Assam',
  telangana: 'Telangana',
  hyderabad: 'Telangana',
  odisha: 'Odisha',
  orissa: 'Odisha',
  nagaland: 'Nagaland',
  sikkim: 'Sikkim',
  'andhra pradesh': 'Andhra Pradesh',
  andhra: 'Andhra Pradesh',
  ap: 'Andhra Pradesh',
};

function normalizeStateName(input: string): IndianState {
  if (!input) return 'Maharashtra';
  const clean = input.toLowerCase().trim();

  for (const [key, state] of Object.entries(INDIAN_STATES_MAP)) {
    if (clean.includes(key)) {
      return state;
    }
  }

  return 'Other';
}

class GeolocationService {
  private cachedResult: GeolocationResult | null = null;

  /**
   * Automatically detect Indian State via HTML5 Geolocation API with fallback IP-location lookup
   */
  public async detectLocation(): Promise<GeolocationResult> {
    // 1. Try HTML5 Geolocation API
    try {
      const coords = await this.getHTML5Coordinates(3500);
      if (coords) {
        const stateFromCoords = await this.reverseGeocode(coords.latitude, coords.longitude);
        if (stateFromCoords) {
          const isRestricted = RESTRICTED_INDIAN_STATES.includes(stateFromCoords as any);
          const result: GeolocationResult = {
            state: stateFromCoords,
            isRestricted,
            method: 'HTML5_GEOLOCATION',
            rawLocation: `Lat: ${coords.latitude.toFixed(2)}, Lon: ${coords.longitude.toFixed(2)}`,
          };
          this.cachedResult = result;
          return result;
        }
      }
    } catch {
      // Graceful fallback to IP lookup
    }

    // 2. Fallback to IP-location lookup
    try {
      const ipResult = await this.lookupByIP();
      if (ipResult) {
        this.cachedResult = ipResult;
        return ipResult;
      }
    } catch {
      // Fallback
    }

    // 3. Fallback default
    const fallback: GeolocationResult = {
      state: 'Maharashtra',
      isRestricted: false,
      method: 'CACHED',
      rawLocation: 'Default fallback (Mumbai / Maharashtra)',
    };
    return fallback;
  }

  /**
   * Promisified HTML5 Geolocation with strict timeout
   */
  private getHTML5Coordinates(
    timeoutMs: number
  ): Promise<{ latitude: number; longitude: number } | null> {
    if (typeof window === 'undefined' || !navigator.geolocation) {
      return Promise.resolve(null);
    }

    return new Promise((resolve) => {
      let resolved = false;

      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          resolve(null);
        }
      }, timeoutMs);

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          if (!resolved) {
            resolved = true;
            clearTimeout(timer);
            resolve({
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
            });
          }
        },
        () => {
          if (!resolved) {
            resolved = true;
            clearTimeout(timer);
            resolve(null);
          }
        },
        { enableHighAccuracy: false, timeout: timeoutMs, maximumAge: 60000 }
      );
    });
  }

  /**
   * Reverse geocode coordinates to Indian State via open reverse geocoding
   */
  private async reverseGeocode(lat: number, lon: number): Promise<IndianState | null> {
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 3000);
      const res = await fetch(
        `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=en`,
        { signal: controller.signal }
      );
      clearTimeout(id);
      if (res.ok) {
        const data = await res.json();
        const subdivision = data.principalSubdivision || data.locality || '';
        return normalizeStateName(subdivision);
      }
    } catch {
      // Fallback rough geographic bounding boxes for India if offline/blocked
      if (lat >= 24.0 && lat <= 28.5 && lon >= 89.5 && lon <= 96.0) return 'Assam';
      if (lat >= 15.8 && lat <= 19.9 && lon >= 77.2 && lon <= 81.8) return 'Telangana';
      if (lat >= 17.8 && lat <= 22.6 && lon >= 81.4 && lon <= 87.5) return 'Odisha';
      if (lat >= 25.1 && lat <= 27.1 && lon >= 93.3 && lon <= 95.3) return 'Nagaland';
      if (lat >= 27.0 && lat <= 28.2 && lon >= 88.0 && lon <= 89.0) return 'Sikkim';
      if (lat >= 12.6 && lat <= 19.1 && lon >= 76.7 && lon <= 84.8) return 'Andhra Pradesh';
      if (lat >= 15.6 && lat <= 22.0 && lon >= 72.6 && lon <= 80.9) return 'Maharashtra';
      if (lat >= 28.3 && lat <= 28.9 && lon >= 76.8 && lon <= 77.4) return 'Delhi';
      if (lat >= 11.5 && lat <= 18.5 && lon >= 74.0 && lon <= 78.6) return 'Karnataka';
    }
    return null;
  }

  /**
   * Fallback IP-location lookup
   */
  private async lookupByIP(): Promise<GeolocationResult | null> {
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 3000);
      // Try ipwho.is (CORS-friendly, free, no key required)
      const res = await fetch('https://ipwho.is/', { signal: controller.signal });
      clearTimeout(id);
      if (res.ok) {
        const data = await res.json();
        const rawRegion = data.region || data.city || '';
        const state = normalizeStateName(rawRegion);
        const isRestricted = RESTRICTED_INDIAN_STATES.includes(state as any);
        return {
          state,
          isRestricted,
          method: 'IP_LOOKUP',
          rawLocation: `${data.city ? data.city + ', ' : ''}${data.region || 'India'} (${data.ip || ''})`,
        };
      }
    } catch {
      // Ignore
    }

    // Backup IP API: ipapi.co
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 3000);
      const res = await fetch('https://ipapi.co/json/', { signal: controller.signal });
      clearTimeout(id);
      if (res.ok) {
        const data = await res.json();
        const rawRegion = data.region || data.city || '';
        const state = normalizeStateName(rawRegion);
        const isRestricted = RESTRICTED_INDIAN_STATES.includes(state as any);
        return {
          state,
          isRestricted,
          method: 'IP_LOOKUP',
          rawLocation: `${data.city ? data.city + ', ' : ''}${data.region || 'India'}`,
        };
      }
    } catch {
      // Ignore
    }

    return null;
  }

  public getCachedResult(): GeolocationResult | null {
    return this.cachedResult;
  }
}

export const geolocationService = new GeolocationService();
