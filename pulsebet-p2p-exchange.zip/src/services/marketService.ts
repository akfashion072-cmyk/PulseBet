import { BetSide, Market, MarketBet } from '../types';

export interface MultiplierCalculationResult {
  multiplier: number;
  effectiveFeeTotal: number;
  houseFeePercent: number;
  royaltyPercent: number;
  isProtected: boolean;
  netDistributable: number;
  isUnmatched: boolean;
}

export interface ParimutuelQuoteResult extends MultiplierCalculationResult {
  side: BetSide;
  betAmount: number;
  estimatedWinPayout: number;
  yesProbability: number;
  noProbability: number;
  isUserRoom: boolean;
}

export interface MarketSettlementResult {
  marketId: string;
  winningSide: BetSide;
  multiplier: number;
  totalVolume: number;
  winningPool: number;
  losingPool: number;
  creatorRoyalty: number;
  platformFee: number;
  netDistributable: number;
  isUnmatched: boolean;
  payouts: Array<{
    betId: string;
    userId: string;
    stake: number;
    multiplier: number;
    payoutAmount: number;
    status: 'WON' | 'LOST' | 'UNMATCHED_REFUND';
  }>;
}

export class MarketService {
  private readonly defaultGuaranteeMultiplier = 1.01;
  private readonly defaultHouseFee = 10;
  private readonly defaultCreatorRoyalty = 15;

  /**
   * Precise floating-point multiplier calculation for dynamic opponent pool ratios.
   * Capped dynamically with 1.01x minimum guarantee to prevent winning payouts from falling below principal.
   */
  public calculateMultiplier(
    chosenPool: number,
    losingPool: number,
    isUserRoom: boolean,
    customHouseFee?: number,
    customCreatorRoyalty?: number,
    minGuarantee = this.defaultGuaranteeMultiplier
  ): MultiplierCalculationResult {
    // If no stake on chosen side yet
    if (chosenPool <= 0) {
      return {
        multiplier: 1.0,
        effectiveFeeTotal: 0,
        houseFeePercent: 0,
        royaltyPercent: 0,
        isProtected: false,
        netDistributable: 0,
        isUnmatched: losingPool <= 0,
      };
    }

    // Unmatched liquidity condition: 0 opposition on losing side
    if (losingPool <= 0) {
      return {
        multiplier: 1.0,
        effectiveFeeTotal: 0,
        houseFeePercent: 0,
        royaltyPercent: 0,
        isProtected: false,
        netDistributable: chosenPool,
        isUnmatched: true,
      };
    }

    const houseFeePercent = customHouseFee !== undefined ? customHouseFee : (isUserRoom ? 5 : this.defaultHouseFee);
    const royaltyPercent = isUserRoom ? (customCreatorRoyalty !== undefined ? customCreatorRoyalty : this.defaultCreatorRoyalty) : 0;
    const totalBaseFeeRate = (houseFeePercent + royaltyPercent) / 100;

    const totalPool = chosenPool + losingPool;
    const standardTotalFee = totalPool * totalBaseFeeRate;

    // Principal Return Protection: Fee is capped at 50% of opposing losing pool
    const maxFeeCapOnLosingPool = losingPool * 0.5;
    let effectiveFee = Math.min(standardTotalFee, maxFeeCapOnLosingPool);
    let netDistributable = totalPool - effectiveFee;
    let rawMultiplier = netDistributable / chosenPool;

    // Strict 1.01x minimum return guard
    let isProtected = effectiveFee < standardTotalFee;
    if (rawMultiplier < minGuarantee) {
      rawMultiplier = minGuarantee;
      effectiveFee = Math.max(0, totalPool - chosenPool * minGuarantee);
      netDistributable = totalPool - effectiveFee;
      isProtected = true;
    }

    // Precise 2-decimal floating point rounding (e.g., 1.87, 1.70)
    const multiplier = Number(rawMultiplier.toFixed(2));

    return {
      multiplier,
      effectiveFeeTotal: Math.round(effectiveFee),
      houseFeePercent,
      royaltyPercent,
      isProtected,
      netDistributable: Math.round(netDistributable * 100) / 100,
      isUnmatched: false,
    };
  }

  /**
   * Calculates exact payout from principal investment and multiplier.
   * Guarantee: Payout equals Principal Investment * Multiplier.
   */
  public calculatePayout(principalAmount: number, multiplier: number): number {
    return Number((principalAmount * multiplier).toFixed(2));
  }

  /**
   * Parimutuel Quote for prospective trades
   */
  public getParimutuelQuote(market: Market, side: BetSide, betAmount: number): ParimutuelQuoteResult {
    const isUserRoom = !market.isOfficialAdmin;
    const projectedYesPool = side === 'YES' ? market.yesPool + betAmount : market.yesPool;
    const projectedNoPool = side === 'NO' ? market.noPool + betAmount : market.noPool;
    const projectedTotalVolume = projectedYesPool + projectedNoPool;

    const chosenPool = side === 'YES' ? projectedYesPool : projectedNoPool;
    const losingPool = side === 'YES' ? projectedNoPool : projectedYesPool;

    const calc = this.calculateMultiplier(
      chosenPool,
      losingPool,
      isUserRoom,
      market.customHouseFee,
      market.customCreatorRoyalty
    );

    // Guaranteed payout = Principal * Multiplier
    const estimatedWinPayout = this.calculatePayout(betAmount, calc.multiplier);

    const yesProb = projectedTotalVolume > 0 ? (projectedYesPool / projectedTotalVolume) * 100 : 50;
    const noProb = 100 - yesProb;

    return {
      ...calc,
      side,
      betAmount,
      estimatedWinPayout,
      yesProbability: Math.round(yesProb),
      noProbability: Math.round(noProb),
      isUserRoom,
    };
  }

  /**
   * Settles market bets with 100% precision:
   * Payout = Principal Investment * Multiplier.
   * If opposing pool has 0 wagers, handles unmatched refunds cleanly.
   */
  public settleMarket(
    market: Market,
    winningSide: BetSide,
    bets: MarketBet[]
  ): MarketSettlementResult {
    const isUserRoom = !market.isOfficialAdmin;
    const activeBets = bets.filter((b) => b.marketId === market.id && b.status === 'ACTIVE');

    const winningBets = activeBets.filter((b) => b.side === winningSide);
    const losingBets = activeBets.filter((b) => b.side !== winningSide);

    const winningPool = winningBets.reduce((sum, b) => sum + b.amount, 0) || (winningSide === 'YES' ? market.yesPool : market.noPool);
    const losingPool = losingBets.reduce((sum, b) => sum + b.amount, 0) || (winningSide === 'YES' ? market.noPool : market.yesPool);
    const totalVolume = winningPool + losingPool;

    // Unmatched condition: opposing pool is 0
    if (losingBets.length === 0 || losingPool <= 0) {
      const payouts = activeBets.map((b) => ({
        betId: b.id,
        userId: b.userId,
        stake: b.amount,
        multiplier: 1.0,
        payoutAmount: b.amount, // 100% principal returned
        status: 'UNMATCHED_REFUND' as const,
      }));

      return {
        marketId: market.id,
        winningSide,
        multiplier: 1.0,
        totalVolume,
        winningPool,
        losingPool: 0,
        creatorRoyalty: 0,
        platformFee: 0,
        netDistributable: winningPool,
        isUnmatched: true,
        payouts,
      };
    }

    const calc = this.calculateMultiplier(
      winningPool,
      losingPool,
      isUserRoom,
      market.customHouseFee,
      market.customCreatorRoyalty
    );

    // Creator royalty allocation (15%)
    let creatorRoyalty = 0;
    if (isUserRoom) {
      const royaltyPercent = market.customCreatorRoyalty !== undefined ? market.customCreatorRoyalty : this.defaultCreatorRoyalty;
      creatorRoyalty = Math.round((totalVolume * royaltyPercent) / 100);
    }

    const platformFee = Math.max(0, calc.effectiveFeeTotal - creatorRoyalty);

    // Winning user payouts: strictly (Principal Investment * Multiplier)
    const payouts = activeBets.map((b) => {
      if (b.side === winningSide) {
        const payoutAmount = this.calculatePayout(b.amount, calc.multiplier);
        return {
          betId: b.id,
          userId: b.userId,
          stake: b.amount,
          multiplier: calc.multiplier,
          payoutAmount,
          status: 'WON' as const,
        };
      } else {
        return {
          betId: b.id,
          userId: b.userId,
          stake: b.amount,
          multiplier: 0,
          payoutAmount: 0,
          status: 'LOST' as const,
        };
      }
    });

    return {
      marketId: market.id,
      winningSide,
      multiplier: calc.multiplier,
      totalVolume,
      winningPool,
      losingPool,
      creatorRoyalty,
      platformFee,
      netDistributable: calc.netDistributable,
      isUnmatched: false,
      payouts,
    };
  }
}

export const marketService = new MarketService();
