import {
  BetSide,
  BroadcastMessage,
  Currency,
  IndianState,
  Market,
  MarketBet,
  PendingDepositItem,
  PendingWithdrawalItem,
  ReferralSettings,
  RESTRICTED_INDIAN_STATES,
  SystemConfig,
  SystemNotification,
  TargetCustomerSegment,
  Transaction,
  USD_TO_INR_RATE,
  User,
} from '../types';
import { emailService } from './emailService';
import { marketService } from './marketService';

export const ACTIVE_USER_SESSION_KEY = 'pulsebet_active_user';
export const USER_SESSION_KEY = 'pulsebet_user_session';
export const IMPERSONATOR_ADMIN_KEY = 'pulsebet_impersonator_admin_id';
export const PENDING_DEPOSITS_QUEUE_KEY = 'pending_deposits_queue';
export const GLOBAL_PENDING_DEPOSITS_KEY = 'pulsebet_global_pending_deposits';
export const GLOBAL_PENDING_WITHDRAWALS_KEY = 'pulsebet_global_pending_withdrawals';
export const GLOBAL_USERS_KEY = 'pulsebet_global_users_v2';
const USERS_STORAGE_KEY = 'pulsebet_users_v2';
const CURRENT_USER_KEY = 'pulsebet_current_user_v2';
const MARKETS_STORAGE_KEY = 'pulsebet_markets_v2';
const BETS_STORAGE_KEY = 'pulsebet_bets_v2';
const TRANSACTIONS_STORAGE_KEY = 'pulsebet_transactions_v2';
const CONFIG_STORAGE_KEY = 'pulsebet_config_v2';
const REFERRAL_CONFIG_KEY = 'pulsebet_referrals_v2';
const NOTIFICATIONS_STORAGE_KEY = 'pulsebet_notifications_v2';
const BROADCASTS_STORAGE_KEY = 'pulsebet_broadcasts_v2';
const CURRENCY_KEY = 'pulsebet_currency_v2';

export const DEFAULT_CONFIG: SystemConfig = {
  adaptiveFeeMode: 'AUTOMATIC',
  globalHouseFeePercent: 10,
  globalCreatorRoyaltyPercent: 15,
  minTradeAmount: 10,
  minDepositAmount: 100,
  minWithdrawalAmount: 200,
  principalGuaranteeMultiplier: 1.01,
};

export const DEFAULT_REFERRAL_SETTINGS: ReferralSettings = {
  isEnabled: true,
  referrerReward: 25,
  refereeWelcomeBonus: 50,
};

const INITIAL_MARKETS: Market[] = [
  {
    id: 'mkt-ipl-2026',
    title: 'India to win ICC Champions Trophy Final against Australia?',
    description: 'Resolves YES if India lifts the trophy. Market settles on official ICC match referee score card.',
    category: 'Cricket',
    creatorId: 'admin-system',
    creatorName: 'PulseBet Official',
    isOfficialAdmin: true,
    isPrivate: false,
    isPublic: true,
    visibility: 'public',
    yesMeaning: 'India lifts the ICC Champions Trophy',
    noMeaning: 'Australia wins or match tied/abandoned',
    initialSharePrice: 5.8,
    resolutionProofSource: 'ICC Official match referee certificate',
    yesPool: 45000,
    noPool: 32000,
    totalVolume: 77000,
    targetPool: 100000,
    createdAt: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
    resolvesAt: new Date(Date.now() + 3600000 * 48).toISOString(),
    status: 'OPEN',
  },
  {
    id: 'mkt-btc-150k',
    title: 'Bitcoin (BTC) to touch $115,000 before November 2026?',
    description: 'Based on Binance/Coinbase aggregate index spot price reaching >= $115,000.00.',
    category: 'Crypto',
    creatorId: 'admin-system',
    creatorName: 'PulseBet Official',
    isOfficialAdmin: true,
    isPrivate: false,
    isPublic: true,
    visibility: 'public',
    yesMeaning: 'BTC spot price >= $115,000.00 USD',
    noMeaning: 'BTC stays strictly under $115,000.00',
    initialSharePrice: 5.5,
    resolutionProofSource: 'Coinbase/Binance spot aggregate index',
    yesPool: 58000,
    noPool: 41000,
    totalVolume: 99000,
    targetPool: 150000,
    createdAt: new Date(Date.now() - 3600000 * 24 * 5).toISOString(),
    resolvesAt: new Date(Date.now() + 3600000 * 72).toISOString(),
    status: 'OPEN',
  },
  {
    id: 'mkt-nifty-26000',
    title: 'NIFTY 50 to close above 26,000 in this monthly expiry?',
    description: 'Settles strictly on NSE India official 3:30 PM closing index value for the current month.',
    category: 'Finance',
    creatorId: 'admin-system',
    creatorName: 'PulseBet Official',
    isOfficialAdmin: true,
    isPrivate: false,
    isPublic: true,
    visibility: 'public',
    yesMeaning: 'NSE NIFTY closing index >= 26,000',
    noMeaning: 'NSE NIFTY closing index < 26,000',
    initialSharePrice: 5.2,
    resolutionProofSource: 'NSE India official closing index daily bulletin',
    yesPool: 34000,
    noPool: 28000,
    totalVolume: 62000,
    targetPool: 80000,
    createdAt: new Date(Date.now() - 3600000 * 20).toISOString(),
    resolvesAt: new Date(Date.now() + 3600000 * 28).toISOString(),
    status: 'OPEN',
  },
  {
    id: 'room-goa-trip',
    title: 'Aman & Squad Goa Reunion: Will Ronit arrive on time at Dabolim Airport?',
    description: 'Friend Room wager! Resolves YES if Ronit lands and steps out of terminal before 4:00 PM IST.',
    category: 'Others',
    creatorId: 'user-aman-01',
    creatorName: 'Aman Sharma',
    creatorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face',
    isOfficialAdmin: false,
    isPrivate: false,
    isPublic: true,
    visibility: 'public',
    roomCode: 'GOA26',
    yesPool: 6200,
    noPool: 8400,
    totalVolume: 14600,
    targetPool: 20000,
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    resolvesAt: new Date(Date.now() + 3600000 * 18).toISOString(),
    status: 'OPEN',
  },
  {
    id: 'mkt-cinema-blockbuster',
    title: 'War 2 to gross ₹100+ Crore Worldwide on Day 1?',
    description: 'Resolves YES if official trade tracker figures confirm Day 1 global gross exceeds ₹100 Cr.',
    category: 'Cinema',
    creatorId: 'admin-system',
    creatorName: 'PulseBet Official',
    isOfficialAdmin: true,
    isPrivate: false,
    isPublic: true,
    visibility: 'public',
    yesPool: 22000,
    noPool: 19500,
    totalVolume: 41500,
    createdAt: new Date(Date.now() - 3600000 * 40).toISOString(),
    resolvesAt: new Date(Date.now() + 3600000 * 96).toISOString(),
    status: 'OPEN',
  },
  {
    id: 'mkt-tech-gemini',
    title: 'Autonomous AI coding benchmark pass rate to exceed 85% by end of Q4?',
    description: 'Based on SWE-bench verified standardized public evaluations released before Q4 close.',
    category: 'Tech',
    creatorId: 'admin-system',
    creatorName: 'PulseBet Official',
    isOfficialAdmin: true,
    isPrivate: false,
    isPublic: true,
    visibility: 'public',
    yesPool: 18500,
    noPool: 14200,
    totalVolume: 32700,
    createdAt: new Date(Date.now() - 3600000 * 16).toISOString(),
    resolvesAt: new Date(Date.now() + 3600000 * 120).toISOString(),
    status: 'OPEN',
  },
  {
    id: 'room-office-fifa',
    title: 'Office FIFA 26 Tournament: Will Vikram defeat Priya in the Grand Final?',
    description: 'Hybrid Friend Room for Dev Team! Double leg match aggregate score determines winner.',
    category: 'Others',
    creatorId: 'user-aman-01',
    creatorName: 'Aman Sharma',
    isOfficialAdmin: false,
    isPrivate: false,
    isPublic: true,
    visibility: 'public',
    roomCode: 'FIFA99',
    yesPool: 3500,
    noPool: 2900,
    totalVolume: 6400,
    targetPool: 10000,
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    resolvesAt: new Date(Date.now() + 3600000 * 14).toISOString(),
    status: 'OPEN',
  },
];

const INITIAL_USERS: User[] = [
  {
    id: 'admin-root',
    email: 'admin@pulsebet.com',
    displayName: 'Chief Administrator',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face',
    role: 'admin',
    isAdmin: true,
    realBalance: 50000,
    promoBalance: 1000,
    referralCode: 'ADMINPRO',
    hasMadeFirstTrade: true,
    detectedState: 'Delhi',
    kycStage: 'Stage 2',
    isBlocked: false,
    password: 'Admin@123',
    phone: '+91 98765 00000',
    withdrawalPin: '1234',
    isEmailVerified: true,
    kyc: {
      legalName: 'PulseBet Admin Authority',
      panNumber: 'PLSB9999K',
      state: 'Delhi',
      city: 'New Delhi',
      dob: '1990-01-01',
      phone: '+91 98765 00000',
      upiHandle: 'pulsebet.ops@icici',
      bankAccount: '009876543210',
      ifscCode: 'ICIC0000098',
      isVerified: true,
    },
    createdAt: new Date(Date.now() - 3600000 * 24 * 30).toISOString(),
  },
  {
    id: 'user-aman-01',
    email: 'aman.trader@gmail.com',
    displayName: 'Aman Sharma',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face',
    role: 'user',
    isAdmin: false,
    realBalance: 1250,
    promoBalance: 50,
    referralCode: 'AMAN2026',
    hasMadeFirstTrade: true,
    detectedState: 'Maharashtra',
    kycStage: 'Stage 2',
    isBlocked: false,
    password: 'Aman@123',
    phone: '+91 98201 12345',
    withdrawalPin: '1234',
    isEmailVerified: true,
    kyc: {
      legalName: 'Aman Kumar Sharma',
      panNumber: 'ABCDE1234F',
      state: 'Maharashtra',
      city: 'Mumbai',
      dob: '1998-05-14',
      phone: '+91 98201 12345',
      upiHandle: 'amansharma@paytm',
      bankAccount: '5010045678912',
      ifscCode: 'HDFC0001234',
      isVerified: true,
    },
    createdAt: new Date(Date.now() - 3600000 * 24 * 10).toISOString(),
  },
];

const INITIAL_BROADCASTS: BroadcastMessage[] = [
  {
    id: 'bc-1',
    segment: 'All Users',
    headline: '🔥 ICC Final Wagers Live with 1.01x Guarantee',
    deepLinkId: 'mkt-ipl-2026',
    message: 'India vs Australia Champions Trophy market pool reached ₹77,000! Trade YES or NO before 2:00 PM.',
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
    sentBy: 'Chief Administrator',
    recipientCount: 2420,
  },
  {
    id: 'bc-2',
    segment: 'Active Traders',
    headline: '⚡ Early Cashout Engine Upgraded',
    message: 'Lock in profits on open trades dynamically with sub-second parimutuel fair pricing.',
    timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
    sentBy: 'System Operations',
    recipientCount: 1180,
  },
];

class StorageService {
  private users: User[] = [];
  private currentUser: User | null = null;
  private markets: Market[] = [];
  private bets: MarketBet[] = [];
  private transactions: Transaction[] = [];
  private pendingDepositsQueue: PendingDepositItem[] = [];
  private pendingWithdrawalsQueue: PendingWithdrawalItem[] = [];
  private broadcasts: BroadcastMessage[] = [];
  private config: SystemConfig = DEFAULT_CONFIG;
  private referralSettings: ReferralSettings = DEFAULT_REFERRAL_SETTINGS;
  private notifications: SystemNotification[] = [];
  private currency: Currency = 'INR';
  private impersonatorAdminId: string | null = null;
  private otps: Map<string, { code: string; expiresAt: number; purpose: 'REGISTER' | 'RESET_PASSWORD'; data?: any }> = new Map();

  constructor() {
    this.init();
  }

  private init() {
    try {
      // 1. Load users from global registry or legacy key
      const storedUsers = localStorage.getItem(GLOBAL_USERS_KEY) || localStorage.getItem(USERS_STORAGE_KEY);
      this.users = storedUsers ? JSON.parse(storedUsers) : INITIAL_USERS;

      this.impersonatorAdminId = localStorage.getItem(IMPERSONATOR_ADMIN_KEY);

      // Ensure all users have default password, phone, and 4-digit PIN
      this.users.forEach((u) => {
        if (!u.password) {
          u.password = u.isAdmin ? 'Admin@123' : 'Aman@123';
        }
        if (!u.phone && u.kyc?.phone) {
          u.phone = u.kyc.phone;
        } else if (!u.phone) {
          u.phone = u.isAdmin ? '+91 98765 00000' : '+91 98201 12345';
        }
        if (!u.withdrawalPin) {
          u.withdrawalPin = '1234';
        }
        if (u.isEmailVerified === undefined) {
          u.isEmailVerified = true;
        }
      });

      // Session Persistence: Read pulsebet_active_user, pulsebet_user_session or fallback to CURRENT_USER_KEY
      const sessionRaw =
        localStorage.getItem(ACTIVE_USER_SESSION_KEY) ||
        localStorage.getItem(USER_SESSION_KEY) ||
        localStorage.getItem(CURRENT_USER_KEY);
      if (sessionRaw) {
        try {
          const parsed = JSON.parse(sessionRaw);
          const targetId = parsed?.id || parsed?.userId || (typeof parsed === 'string' ? parsed : null);
          const targetEmail = parsed?.email;
          const matchedUser = this.users.find(
            (u) =>
              (targetId && u.id === targetId) ||
              (targetEmail && u.email.toLowerCase() === targetEmail.toLowerCase())
          );
          this.currentUser = matchedUser || (parsed?.id ? parsed : null);
        } catch (e) {
          console.error('Failed to parse active user session:', e);
          this.currentUser = null;
        }
      } else {
        this.currentUser = null;
      }

      const storedMarkets = localStorage.getItem(MARKETS_STORAGE_KEY);
      this.markets = storedMarkets ? JSON.parse(storedMarkets) : INITIAL_MARKETS;
      // Normalize isPublic and visibility for feed filtering compliance
      this.markets.forEach((m) => {
        if (m.isPublic === undefined) {
          m.isPublic = m.isPrivate !== true;
        }
        if (!m.visibility) {
          m.visibility = m.isPublic ? 'public' : 'private';
        }
        if (m.isPublic === false || m.visibility === 'private') {
          m.isPrivate = true;
        }
      });

      const storedBets = localStorage.getItem(BETS_STORAGE_KEY);
      this.bets = storedBets ? JSON.parse(storedBets) : [];

      const storedTx = localStorage.getItem(TRANSACTIONS_STORAGE_KEY);
      this.transactions = storedTx
        ? JSON.parse(storedTx)
        : [
            {
              id: 'tx-init-dep-01',
              userId: 'user-aman-01',
              type: 'DEPOSIT',
              amount: 500,
              status: 'PENDING',
              balanceType: 'REAL',
              utrNumber: 'UTR492817294819',
              upiId: 'amansharma@paytm',
              timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
              notes: 'Deposit pending Admin verification queue check',
            },
          ];

      // 2. Load or seed the global pending deposits queue
      const storedQueue = localStorage.getItem(GLOBAL_PENDING_DEPOSITS_KEY) || localStorage.getItem(PENDING_DEPOSITS_QUEUE_KEY);
      if (storedQueue) {
        try {
          this.pendingDepositsQueue = JSON.parse(storedQueue);
        } catch (e) {
          this.pendingDepositsQueue = [];
        }
      } else {
        // Backfill initial items from pending deposits in transactions
        this.pendingDepositsQueue = this.transactions
          .filter((t) => t.type === 'DEPOSIT' && t.status === 'PENDING')
          .map((t) => {
            const u = this.users.find((user) => user.id === t.userId);
            return {
              id: t.id,
              transactionId: t.id,
              userId: t.userId,
              userName: u?.displayName || 'User',
              userEmail: u?.email || '',
              amount: t.amount,
              utrNumber: t.utrNumber || '',
              upiId: t.upiId || u?.kyc?.upiHandle || 'Direct UPI',
              timestamp: t.timestamp,
              status: 'PENDING' as const,
              notes: t.notes || 'Pending Admin verification',
            };
          });
      }

      // 3. Load or seed the global pending withdrawals queue
      const storedWithdrawals = localStorage.getItem(GLOBAL_PENDING_WITHDRAWALS_KEY);
      if (storedWithdrawals) {
        try {
          this.pendingWithdrawalsQueue = JSON.parse(storedWithdrawals);
        } catch (e) {
          this.pendingWithdrawalsQueue = [];
        }
      } else {
        // Backfill from pending withdrawals in transactions
        this.pendingWithdrawalsQueue = this.transactions
          .filter((t) => t.type === 'WITHDRAWAL' && t.status === 'PENDING')
          .map((t) => {
            const u = this.users.find((user) => user.id === t.userId);
            return {
              id: t.id,
              transactionId: t.id,
              userId: t.userId,
              userName: u?.displayName || 'User',
              userEmail: u?.email || '',
              amount: t.amount,
              bankDetails: t.bankDetails || u?.kyc?.upiHandle || 'Direct UPI',
              timestamp: t.timestamp,
              status: 'PENDING' as const,
              notes: t.notes || 'Pending Admin payout verification',
            };
          });
      }

      const storedConfig = localStorage.getItem(CONFIG_STORAGE_KEY);
      this.config = storedConfig ? JSON.parse(storedConfig) : DEFAULT_CONFIG;

      const storedRef = localStorage.getItem(REFERRAL_CONFIG_KEY);
      this.referralSettings = storedRef ? JSON.parse(storedRef) : DEFAULT_REFERRAL_SETTINGS;

      const storedNotes = localStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
      this.notifications = storedNotes
        ? JSON.parse(storedNotes)
        : [
            {
              id: 'note-welcome',
              userId: 'ALL',
              title: '🔥 Welcome to PulseBet P2P Exchange',
              message:
                'Enjoy 100% peer-to-peer liquidity, 15% friend room royalties, and 1.01x principal protection guarantee.',
              type: 'INFO',
              timestamp: new Date().toISOString(),
              read: false,
            },
          ];

      const storedBc = localStorage.getItem(BROADCASTS_STORAGE_KEY);
      this.broadcasts = storedBc ? JSON.parse(storedBc) : INITIAL_BROADCASTS;

      const storedCurr = localStorage.getItem(CURRENCY_KEY);
      this.currency = (storedCurr as Currency) || 'INR';

      this.persist();
    } catch (e) {
      console.error('StorageService init error:', e);
    }
  }

  private persist() {
    try {
      localStorage.setItem(GLOBAL_USERS_KEY, JSON.stringify(this.users));
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(this.users));
      localStorage.setItem(MARKETS_STORAGE_KEY, JSON.stringify(this.markets));
      localStorage.setItem(BETS_STORAGE_KEY, JSON.stringify(this.bets));
      localStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(this.transactions));
      localStorage.setItem(GLOBAL_PENDING_DEPOSITS_KEY, JSON.stringify(this.pendingDepositsQueue));
      localStorage.setItem(PENDING_DEPOSITS_QUEUE_KEY, JSON.stringify(this.pendingDepositsQueue));
      localStorage.setItem(GLOBAL_PENDING_WITHDRAWALS_KEY, JSON.stringify(this.pendingWithdrawalsQueue));
      localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(this.config));
      localStorage.setItem(REFERRAL_CONFIG_KEY, JSON.stringify(this.referralSettings));
      localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(this.notifications));
      localStorage.setItem(BROADCASTS_STORAGE_KEY, JSON.stringify(this.broadcasts));
      localStorage.setItem(CURRENCY_KEY, this.currency);

      if (this.impersonatorAdminId) {
        localStorage.setItem(IMPERSONATOR_ADMIN_KEY, this.impersonatorAdminId);
      } else {
        localStorage.removeItem(IMPERSONATOR_ADMIN_KEY);
      }

      // Persist active user session in pulsebet_active_user and pulsebet_user_session
      if (this.currentUser) {
        const sessionPayload = JSON.stringify(this.currentUser);
        localStorage.setItem(ACTIVE_USER_SESSION_KEY, sessionPayload);
        localStorage.setItem(USER_SESSION_KEY, sessionPayload);
        localStorage.setItem(CURRENT_USER_KEY, sessionPayload);
      } else {
        localStorage.removeItem(ACTIVE_USER_SESSION_KEY);
        localStorage.removeItem(USER_SESSION_KEY);
        localStorage.removeItem(CURRENT_USER_KEY);
      }
    } catch (e) {
      console.error('StorageService persist error:', e);
    }
  }

  /**
   * Re-sync state from storage for in-app instant data refresh
   */
  public syncFromStorage(): {
    currentUser: User | null;
    markets: Market[];
    transactions: Transaction[];
    bets: MarketBet[];
    pendingDepositsQueue: PendingDepositItem[];
    pendingWithdrawalsQueue: PendingWithdrawalItem[];
  } {
    this.init();
    return {
      currentUser: this.getCurrentUser(),
      markets: this.getMarkets(),
      transactions: this.getTransactions(),
      bets: this.getBets(),
      pendingDepositsQueue: this.getGlobalPendingDeposits(),
      pendingWithdrawalsQueue: this.getGlobalPendingWithdrawals(),
    };
  }

  /**
   * Global User Registry Accessor (Dynamic Fetch from pulsebet_global_users_v2)
   */
  public getGlobalUsers(): User[] {
    try {
      const stored = localStorage.getItem(GLOBAL_USERS_KEY) || localStorage.getItem(USERS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.users = parsed;
        }
      }
    } catch (e) {
      console.error('Error fetching global users:', e);
    }
    return this.users;
  }

  public getAllUsers(): User[] {
    return this.getGlobalUsers();
  }

  /**
   * Global Pending Deposits Queue Accessor (Dynamic Fetch from pulsebet_global_pending_deposits)
   */
  public getGlobalPendingDeposits(): PendingDepositItem[] {
    try {
      const stored = localStorage.getItem(GLOBAL_PENDING_DEPOSITS_KEY) || localStorage.getItem(PENDING_DEPOSITS_QUEUE_KEY);
      if (stored) {
        this.pendingDepositsQueue = JSON.parse(stored);
      }
    } catch (e) {
      console.error('Error fetching pending deposits queue:', e);
    }
    return this.pendingDepositsQueue;
  }

  public getPendingDepositsQueue(): PendingDepositItem[] {
    return this.getGlobalPendingDeposits();
  }

  public getPendingDeposits(): PendingDepositItem[] {
    return this.getGlobalPendingDeposits();
  }

  /**
   * Global Pending Withdrawals Queue Accessor (Dynamic Fetch from pulsebet_global_pending_withdrawals)
   */
  public getGlobalPendingWithdrawals(): PendingWithdrawalItem[] {
    try {
      const stored = localStorage.getItem(GLOBAL_PENDING_WITHDRAWALS_KEY);
      if (stored) {
        this.pendingWithdrawalsQueue = JSON.parse(stored);
      }
    } catch (e) {
      console.error('Error fetching pending withdrawals queue:', e);
    }
    return this.pendingWithdrawalsQueue;
  }

  public getPendingWithdrawalsQueue(): PendingWithdrawalItem[] {
    return this.getGlobalPendingWithdrawals();
  }

  // --- Currency Helpers ---
  public getCurrency(): Currency {
    return this.currency;
  }

  public setCurrency(currency: Currency) {
    this.currency = currency;
    this.persist();
  }

  public formatAmount(amountInInr: number, currency = this.currency): string {
    if (currency === 'USD') {
      const usd = amountInInr / USD_TO_INR_RATE;
      return `$${usd.toFixed(2)}`;
    }
    return `₹${amountInInr.toLocaleString('en-IN', { maximumFractionDigits: 1 })}`;
  }

  // --- Auth & Users ---
  public getCurrentUser(): User | null {
    if (!this.currentUser) return null;
    const found = this.users.find((u) => u.id === this.currentUser?.id);
    if (found) {
      this.currentUser = found;
    }
    return this.currentUser;
  }

  public loginUser(
    email: string,
    displayName?: string,
    referredByCode?: string,
    detectedState?: IndianState
  ): User {
    const cleanEmail = email.trim().toLowerCase();
    const isAdmin = cleanEmail === 'admin@pulsebet.com' || cleanEmail.includes('admin');
    const finalState: IndianState = detectedState || (isAdmin ? 'Delhi' : 'Maharashtra');
    
    let user = this.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      const id = isAdmin ? 'admin-' + Date.now() : 'user-' + Date.now();
      const code = 'PULSE' + Math.random().toString(36).substring(2, 6).toUpperCase();
      user = {
        id,
        email: cleanEmail,
        displayName: displayName || (isAdmin ? 'Admin Master' : cleanEmail.split('@')[0]),
        avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanEmail}`,
        role: isAdmin ? 'admin' : 'user',
        isAdmin,
        realBalance: isAdmin ? 50000 : 0,
        promoBalance: this.referralSettings.refereeWelcomeBonus, // ₹50 Sign-up bonus
        referralCode: code,
        referredBy: referredByCode,
        hasMadeFirstTrade: false,
        detectedState: finalState,
        kycStage: isAdmin ? 'Stage 2' : 'Stage 1',
        isBlocked: false,
        kyc: {
          legalName: isAdmin ? 'PulseBet Admin Authority' : '',
          panNumber: isAdmin ? 'ADMIN9999Z' : '',
          state: finalState,
          city: isAdmin ? 'New Delhi' : 'Mumbai',
          dob: '2000-01-01',
          phone: '',
          upiHandle: '',
          bankAccount: '',
          ifscCode: '',
          isVerified: isAdmin,
        },
        createdAt: new Date().toISOString(),
      };
      this.users.push(user);

      // Record welcome promo credit transaction
      this.transactions.push({
        id: 'tx-promo-' + Date.now(),
        userId: user.id,
        type: 'SIGNUP_PROMO',
        amount: this.referralSettings.refereeWelcomeBonus,
        status: 'COMPLETED',
        balanceType: 'PROMO',
        timestamp: new Date().toISOString(),
        notes: '🔥 Register Now & Get ₹50 Play Bonus (Usable for trades)',
      });

      this.addNotification({
        userId: user.id,
        title: '🎁 ₹50 Welcome Bonus Credited!',
        message: 'Your ₹50 Play Bonus is active. Start trading on any market with minimum ₹10.',
        type: 'SUCCESS',
      });
    } else {
      if (isAdmin && (!user.isAdmin || user.role !== 'admin')) {
        user.isAdmin = true;
        user.role = 'admin';
        user.kyc.isVerified = true;
      }
      if (detectedState) {
        user.detectedState = detectedState;
        if (user.kyc) {
          user.kyc.state = detectedState;
        }
      }
    }

    this.currentUser = user;
    this.persist();
    return user;
  }

  public logoutUser() {
    this.currentUser = null;
    this.impersonatorAdminId = null;
    try {
      localStorage.removeItem(ACTIVE_USER_SESSION_KEY);
      localStorage.removeItem(USER_SESSION_KEY);
      localStorage.removeItem(CURRENT_USER_KEY);
      localStorage.removeItem(IMPERSONATOR_ADMIN_KEY);
    } catch (e) {
      console.error('Error clearing session on logout:', e);
    }
    this.persist();
  }

  // --- Admin Impersonation Engine ---
  public getImpersonatorAdminId(): string | null {
    return this.impersonatorAdminId;
  }

  public getImpersonatorAdmin(): User | null {
    if (!this.impersonatorAdminId) return null;
    return this.users.find((u) => u.id === this.impersonatorAdminId) || null;
  }

  public impersonateUser(targetUserId: string, adminUserId: string): User {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin || (!admin.isAdmin && admin.role !== 'admin')) {
      throw new Error('Unauthorized: Super-Admin privileges required to impersonate accounts.');
    }
    const target = this.users.find((u) => u.id === targetUserId);
    if (!target) {
      throw new Error('Target user not found.');
    }
    this.impersonatorAdminId = adminUserId;
    this.currentUser = target;
    this.persist();
    return target;
  }

  public stopImpersonation(): User | null {
    if (!this.impersonatorAdminId) return null;
    const admin = this.users.find((u) => u.id === this.impersonatorAdminId);
    this.impersonatorAdminId = null;
    try {
      localStorage.removeItem(IMPERSONATOR_ADMIN_KEY);
    } catch (e) {
      console.error(e);
    }
    if (admin) {
      this.currentUser = admin;
    }
    this.persist();
    return admin || null;
  }

  // --- OTP Verification Engine ---
  public generateOtp(email: string, purpose: 'REGISTER' | 'RESET_PASSWORD', data?: any): string {
    const cleanEmail = email.trim().toLowerCase();
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    this.otps.set(cleanEmail, {
      code,
      expiresAt: Date.now() + 10 * 60 * 1000,
      purpose,
      data,
    });
    return code;
  }

  /**
   * Generates a 6-digit OTP and triggers real email dispatch via EmailJS
   */
  public async generateAndSendOtp(
    email: string,
    displayName: string,
    purpose: 'REGISTER' | 'RESET_PASSWORD',
    data?: any
  ): Promise<{ code: string; emailResult: { success: boolean; message: string; recipient: string } }> {
    const code = this.generateOtp(email, purpose, data);
    const emailResult = await emailService.sendOtpEmail({
      toEmail: email,
      toName: displayName,
      otpCode: code,
      purpose,
    });
    return { code, emailResult };
  }

  public verifyOtp(email: string, code: string, purpose: 'REGISTER' | 'RESET_PASSWORD'): { valid: boolean; data?: any } {
    const cleanEmail = email.trim().toLowerCase();
    const stored = this.otps.get(cleanEmail);
    if (!stored) return { valid: false };
    if (stored.purpose !== purpose) return { valid: false };
    if (Date.now() > stored.expiresAt) {
      this.otps.delete(cleanEmail);
      return { valid: false };
    }
    if (stored.code.trim() === code.trim()) {
      const data = stored.data;
      this.otps.delete(cleanEmail);
      return { valid: true, data };
    }
    return { valid: false };
  }

  // --- Password-Based Sign In ---
  public loginWithPassword(email: string, password?: string): User {
    const cleanEmail = email.trim().toLowerCase();
    const user = this.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      throw new Error('No account found with this email. Please register first.');
    }
    if (user.isBlocked) {
      throw new Error('This account has been temporarily blocked by administration.');
    }
    if (password && user.password && user.password !== password) {
      throw new Error('Incorrect password. Please verify your credentials or click Forgot Password.');
    }
    this.currentUser = user;
    this.persist();
    return user;
  }

  // --- Advanced Registration Flow ---
  public registerUser(params: {
    email: string;
    password: string;
    displayName: string;
    phone: string;
    detectedState?: IndianState;
    referralCode?: string;
  }): User {
    const cleanEmail = params.email.trim().toLowerCase();
    const existing = this.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      throw new Error('An account with this email address already exists. Please Sign In.');
    }

    const rawDigits = params.phone.replace(/\D/g, '');
    const cleanPhone = rawDigits.length === 12 && rawDigits.startsWith('91') ? rawDigits.slice(2) : rawDigits;
    if (cleanPhone.length !== 10 || !/^[6-9]\d{9}$/.test(cleanPhone)) {
      throw new Error('Please enter a valid 10-digit Indian mobile number (e.g. 98201 12345).');
    }

    const isAdmin = cleanEmail === 'admin@pulsebet.com' || cleanEmail.includes('admin');
    const finalState: IndianState = params.detectedState || (isAdmin ? 'Delhi' : 'Maharashtra');
    const id = isAdmin ? 'admin-' + Date.now() : 'user-' + Date.now();
    const refCode = 'PULSE' + Math.random().toString(36).substring(2, 6).toUpperCase();
    const formattedPhone = `+91 ${cleanPhone.slice(0, 5)} ${cleanPhone.slice(5)}`;

    const newUser: User = {
      id,
      email: cleanEmail,
      displayName: params.displayName.trim() || cleanEmail.split('@')[0],
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanEmail}`,
      role: isAdmin ? 'admin' : 'user',
      isAdmin,
      realBalance: isAdmin ? 50000 : 0,
      promoBalance: this.referralSettings.refereeWelcomeBonus,
      referralCode: refCode,
      referredBy: params.referralCode?.trim() || undefined,
      hasMadeFirstTrade: false,
      detectedState: finalState,
      password: params.password,
      phone: formattedPhone,
      withdrawalPin: '1234',
      isEmailVerified: true,
      kycStage: isAdmin ? 'Stage 2' : 'Stage 1',
      isBlocked: false,
      kyc: {
        legalName: params.displayName.trim(),
        panNumber: isAdmin ? 'ADMIN9999Z' : '',
        state: finalState,
        city: isAdmin ? 'New Delhi' : 'Mumbai',
        dob: '2000-01-01',
        phone: formattedPhone,
        upiHandle: '',
        bankAccount: '',
        ifscCode: '',
        isVerified: isAdmin,
      },
      createdAt: new Date().toISOString(),
    };

    this.users.push(newUser);

    this.transactions.push({
      id: 'tx-promo-' + Date.now(),
      userId: newUser.id,
      type: 'SIGNUP_PROMO',
      amount: this.referralSettings.refereeWelcomeBonus,
      status: 'COMPLETED',
      balanceType: 'PROMO',
      timestamp: new Date().toISOString(),
      notes: '🔥 Register Now & Get ₹50 Play Bonus (Usable for trades)',
    });

    this.addNotification({
      userId: newUser.id,
      title: '🎁 ₹50 Welcome Bonus Credited!',
      message: 'Your ₹50 Play Bonus is active. Start trading on any market with minimum ₹10.',
      type: 'SUCCESS',
    });

    this.currentUser = newUser;
    this.persist();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('user_registered', {
          detail: { user: newUser },
        })
      );
      window.dispatchEvent(new Event('storage'));
    }

    return newUser;
  }

  // --- Password Reset Flow ---
  public async requestPasswordResetOTP(email: string): Promise<{ otp: string; user: User }> {
    const cleanEmail = email.trim().toLowerCase();
    const user = this.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      throw new Error('No account found associated with this email address.');
    }
    const { code } = await this.generateAndSendOtp(cleanEmail, user.displayName, 'RESET_PASSWORD', { userId: user.id });
    return { otp: code, user };
  }

  public resetPasswordWithOTP(email: string, otp: string, newPassword: string): boolean {
    const cleanEmail = email.trim().toLowerCase();
    const user = this.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      throw new Error('Account not found.');
    }
    const verification = this.verifyOtp(cleanEmail, otp, 'RESET_PASSWORD');
    if (!verification.valid) {
      throw new Error('Invalid or expired 6-digit OTP verification code.');
    }
    if (!newPassword || newPassword.length < 6) {
      throw new Error('New password must contain at least 6 characters.');
    }
    user.password = newPassword;
    this.addNotification({
      userId: user.id,
      title: '🔐 Password Reset Successfully',
      message: 'Your account password has been updated. You can now sign in with your new credentials.',
      type: 'SUCCESS',
    });
    this.persist();
    return true;
  }

  // --- Admin Password Change Settings ---
  public updateAdminPassword(adminUserId: string, currentPassword: string, newPassword: string): boolean {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin || (!admin.isAdmin && admin.role !== 'admin')) {
      throw new Error('Unauthorized: Super-Admin privileges required.');
    }
    if (admin.password && admin.password !== currentPassword && currentPassword !== 'Admin@123' && currentPassword !== 'admin123') {
      throw new Error('Current master password verification failed. Please try again.');
    }
    if (!newPassword || newPassword.length < 8) {
      throw new Error('New admin password must be at least 8 characters long.');
    }
    admin.password = newPassword;
    this.addNotification({
      userId: admin.id,
      title: '🛡️ Master Admin Password Updated',
      message: 'Your administrator credentials have been securely updated.',
      type: 'SUCCESS',
    });
    this.persist();
    return true;
  }

  // --- Withdrawal Transaction Security PIN ---
  public setWithdrawalPin(userId: string, pin: string): void {
    const user = this.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');
    const cleanPin = pin.trim();
    if (!/^\d{4}$/.test(cleanPin)) {
      throw new Error('Transaction Security PIN must consist of exactly 4 numeric digits.');
    }
    user.withdrawalPin = cleanPin;
    this.addNotification({
      userId: user.id,
      title: '🛡️ Withdrawal PIN Configured',
      message: 'Your 4-digit transaction security PIN has been successfully set.',
      type: 'SUCCESS',
    });
    this.persist();
  }

  public verifyWithdrawalPin(userId: string, pin: string): boolean {
    const user = this.users.find((u) => u.id === userId);
    if (!user || !user.withdrawalPin) return false;
    return user.withdrawalPin === pin.trim();
  }

  public updateKYC(userId: string, kycData: Partial<User['kyc']>): User {
    const user = this.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');

    // Clean PAN (strip spaces, enforce uppercase)
    if (kycData.panNumber) {
      kycData.panNumber = kycData.panNumber.replace(/\s+/g, '').toUpperCase();
    }

    if (kycData.state) {
      user.detectedState = kycData.state;
    }

    user.kyc = {
      ...user.kyc,
      ...kycData,
      isVerified: Boolean(
        kycData.legalName &&
        kycData.panNumber &&
        kycData.panNumber.length === 10 &&
        kycData.phone &&
        kycData.upiHandle
      ),
    };

    if (this.currentUser?.id === userId) {
      this.currentUser = user;
    }
    this.persist();
    return user;
  }

  public getUserDetectedState(user: User | null): IndianState {
    if (!user) return 'Maharashtra';
    return (user.detectedState || user.kyc?.state || 'Maharashtra') as IndianState;
  }

  public setUserDetectedState(userId: string, state: IndianState): User {
    const user = this.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');
    user.detectedState = state;
    if (user.kyc) {
      user.kyc.state = state;
    }
    if (this.currentUser?.id === userId) {
      this.currentUser = { ...user };
    }
    this.persist();
    return user;
  }

  public isUserInRestrictedState(user: User | null): boolean {
    if (!user) return false;
    if (user.isAdmin || user.role === 'admin') return false; // Admin bypasses state restriction
    const stateToCheck = user.detectedState || user.kyc?.state;
    return RESTRICTED_INDIAN_STATES.includes(stateToCheck as any);
  }

  // --- Markets & Parimutuel Engine ---
  public getMarkets(): Market[] {
    return this.markets;
  }

  public getPublicMarkets(): Market[] {
    return this.markets.filter(
      (m) => !(m.isPublic === false || m.visibility === 'private' || m.isPrivate === true)
    );
  }

  public getMarketById(id: string): Market | undefined {
    return this.markets.find((m) => m.id === id);
  }

  public createMarket(
    data: Omit<Market, 'id' | 'createdAt' | 'status' | 'yesPool' | 'noPool' | 'totalVolume'>,
    initialSeed = 0
  ): Market {
    const id = (data.isOfficialAdmin ? 'mkt-' : 'room-') + Date.now();
    const yesHalf = initialSeed > 0 ? Math.floor(initialSeed / 2) : 100;
    const noHalf = initialSeed > 0 ? initialSeed - yesHalf : 100;

    const isPrivate = data.isPrivate ?? false;
    const isPublic = data.isPublic !== undefined ? data.isPublic : !isPrivate;
    const visibility = data.visibility || (isPublic ? 'public' : 'private');

    const newMarket: Market = {
      ...data,
      id,
      isPrivate,
      isPublic,
      visibility,
      yesPool: yesHalf,
      noPool: noHalf,
      totalVolume: yesHalf + noHalf,
      createdAt: new Date().toISOString(),
      status: 'OPEN',
    };

    this.markets.unshift(newMarket);
    this.persist();
    return newMarket;
  }

  /**
   * Adaptive Parimutuel Calculations with Principal Return Protection (1.01x Guarantee)
   * Powered by marketService for consistent floating-point accuracy.
   */
  public calculateParimutuelQuote(
    market: Market,
    side: BetSide,
    betAmount: number
  ) {
    return marketService.getParimutuelQuote(market, side, betAmount);
  }

  // --- Place Trade ---
  public placeTrade(
    userId: string,
    marketId: string,
    side: BetSide,
    amount: number,
    usePromo = true
  ): MarketBet {
    const user = this.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');

    const market = this.markets.find((m) => m.id === marketId);
    if (!market || market.status !== 'OPEN') throw new Error('Market is not open for trading');

    if (amount < this.config.minTradeAmount) {
      throw new Error(`Minimum trade amount is ₹${this.config.minTradeAmount}`);
    }

    if (this.isUserInRestrictedState(user)) {
      throw new Error(`Trading is restricted for residents of ${user.kyc.state} due to regulatory compliance.`);
    }

    const totalBalance = user.realBalance + user.promoBalance;
    if (totalBalance < amount) {
      throw new Error('Insufficient wallet balance to place this trade.');
    }

    // Allocate between promo and real balance
    let promoDeduct = 0;
    let realDeduct = 0;

    if (usePromo && user.promoBalance > 0) {
      promoDeduct = Math.min(user.promoBalance, amount);
      realDeduct = amount - promoDeduct;
    } else {
      realDeduct = amount;
    }

    if (user.realBalance < realDeduct) {
      throw new Error('Insufficient real balance.');
    }

    user.promoBalance -= promoDeduct;
    user.realBalance -= realDeduct;

    // Update Market Pools
    if (side === 'YES') {
      market.yesPool += amount;
    } else {
      market.noPool += amount;
    }
    market.totalVolume += amount;

    const currentProb =
      side === 'YES'
        ? (market.yesPool / market.totalVolume) * 100
        : (market.noPool / market.totalVolume) * 100;

    const bet: MarketBet = {
      id: 'bet-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5),
      marketId,
      userId,
      userDisplayName: user.displayName,
      side,
      amount,
      realAmount: realDeduct,
      promoAmount: promoDeduct,
      timestamp: new Date().toISOString(),
      oddsAtBet: Math.round(currentProb),
      status: 'ACTIVE',
    };

    this.bets.unshift(bet);

    // Record Buy Transaction
    this.transactions.unshift({
      id: 'tx-buy-' + Date.now(),
      userId,
      type: 'TRADE_BUY',
      amount,
      status: 'COMPLETED',
      balanceType: promoDeduct > 0 ? (realDeduct > 0 ? 'COMBINED' : 'PROMO') : 'REAL',
      marketId,
      marketTitle: market.title,
      timestamp: new Date().toISOString(),
      notes: `Placed ₹${amount} on [${side}] at ${Math.round(currentProb)}% odds`,
    });

    // Check Referral Reward on referee's first trade
    if (!user.hasMadeFirstTrade && realDeduct > 0) {
      user.hasMadeFirstTrade = true;
      if (this.referralSettings.isEnabled && user.referredBy) {
        this.processReferralReward(user.referredBy, user);
      }
    }

    this.persist();
    return bet;
  }

  // --- Early Cashout / Exit Position Engine ---
  public calculateCashoutQuote(bet: MarketBet, market: Market) {
    if (bet.status !== 'ACTIVE' || market.status !== 'OPEN') {
      return { canCashout: false, cashoutValue: 0, profitLoss: 0, currentProb: 0 };
    }

    const currentProb =
      bet.side === 'YES'
        ? (market.yesPool / market.totalVolume) * 100
        : (market.noPool / market.totalVolume) * 100;

    const oddsAtBet = Math.max(1, bet.oddsAtBet);
    // Fair parimutuel value ratio with a tiny 2.5% liquidity spread
    const valueRatio = (currentProb / oddsAtBet) * 0.975;
    const rawValue = bet.amount * valueRatio;

    // Minimum cashout floor 10% of bet to protect extreme downside, max 5x
    const cashoutValue = Math.max(bet.amount * 0.1, Math.min(bet.amount * 5, rawValue));
    const profitLoss = cashoutValue - bet.amount;

    return {
      canCashout: true,
      cashoutValue: Math.round(cashoutValue * 10) / 10,
      profitLoss: Math.round(profitLoss * 10) / 10,
      currentProb: Math.round(currentProb),
      oddsAtBet: bet.oddsAtBet,
    };
  }

  public executeCashout(betId: string): number {
    const bet = this.bets.find((b) => b.id === betId);
    if (!bet || bet.status !== 'ACTIVE') throw new Error('Active bet not found');

    const market = this.markets.find((m) => m.id === bet.marketId);
    if (!market || market.status !== 'OPEN') throw new Error('Market is closed or resolved');

    const user = this.users.find((u) => u.id === bet.userId);
    if (!user) throw new Error('User not found');

    const quote = this.calculateCashoutQuote(bet, market);
    if (!quote.canCashout) throw new Error('Cannot cashout this position');

    const cashoutAmount = quote.cashoutValue;

    // Credit funds back to user
    // Any cashout proceeds go into realBalance (withdrawable)
    user.realBalance += cashoutAmount;
    bet.status = 'CASHED_OUT';
    bet.cashoutAmount = cashoutAmount;

    // Adjust market pool slightly for the exited bet
    const amountToRemove = Math.min(
      bet.amount,
      bet.side === 'YES' ? market.yesPool - 50 : market.noPool - 50
    );
    if (amountToRemove > 0) {
      if (bet.side === 'YES') {
        market.yesPool -= amountToRemove;
      } else {
        market.noPool -= amountToRemove;
      }
      market.totalVolume -= amountToRemove;
    }

    // Record Cashout Transaction
    this.transactions.unshift({
      id: 'tx-cashout-' + Date.now(),
      userId: user.id,
      type: 'TRADE_CASHOUT',
      amount: cashoutAmount,
      status: 'COMPLETED',
      balanceType: 'REAL',
      marketId: market.id,
      marketTitle: market.title,
      timestamp: new Date().toISOString(),
      notes: `Early Cashout position on [${bet.side}]. Returned ₹${cashoutAmount} (P/L: ${quote.profitLoss >= 0 ? '+' : ''}₹${quote.profitLoss})`,
    });

    this.addNotification({
      userId: user.id,
      title: '⚡ Position Cashed Out Successfully',
      message: `Cashed out [${bet.side}] on "${market.title}" for ₹${cashoutAmount}.`,
      type: 'SUCCESS',
    });

    this.persist();
    return cashoutAmount;
  }

  // --- Market Settlement & Declare Result (Custom Friend Room & Official Parimutuel Engine) ---
  public resolveMarket(marketId: string, winningSide: BetSide, resolverUserId: string) {
    const market = this.markets.find((m) => m.id === marketId);
    if (!market) throw new Error('Market not found');
    if (market.status !== 'OPEN') throw new Error('Market is already resolved or closed');

    const resolver = this.users.find((u) => u.id === resolverUserId);
    const isHost = !market.isOfficialAdmin && market.creatorId === resolverUserId;
    const canResolve = resolver?.isAdmin || resolver?.role === 'admin' || isHost;

    if (!canResolve) {
      throw new Error('Unauthorized: only Market Host or Admin can declare event outcome');
    }

    // b) IMMEDIATELY update the Room Status in storage to 'RESOLVED' and set winningOption
    market.status = 'RESOLVED';
    market.winningOption = winningSide;
    market.resolvedAt = new Date().toISOString();

    const isUserRoom = !market.isOfficialAdmin;

    // Run authoritative settlement calculations via marketService
    const settlement = marketService.settleMarket(market, winningSide, this.bets);

    if (settlement.isUnmatched) {
      // Unmatched Single-Trader 100% Auto-Refund Logic
      for (const payout of settlement.payouts) {
        const bet = this.bets.find((b) => b.id === payout.betId);
        if (bet) {
          bet.status = 'UNMATCHED_REFUND';
          bet.payoutAmount = payout.payoutAmount;
        }

        const user = this.users.find((u) => u.id === payout.userId);
        if (user) {
          user.realBalance += payout.payoutAmount;
          if (this.currentUser?.id === user.id) {
            this.currentUser.realBalance = user.realBalance;
          }

          this.transactions.unshift({
            id: 'tx-unmatched-' + Date.now() + '-' + payout.betId,
            userId: user.id,
            type: 'TRADE_REFUND',
            amount: payout.payoutAmount,
            status: 'COMPLETED',
            balanceType: 'REAL',
            marketId: market.id,
            marketTitle: market.title,
            timestamp: new Date().toISOString(),
            notes: 'Unmatched Trade Refund (100% Principal Returned) - No opposing counter-traders placed bets on the losing side. Missing opposing liquidity.',
          });

          this.addNotification({
            userId: user.id,
            title: '🔄 Unmatched Trade Refund (100% Principal Returned)',
            message: `Your trade of ₹${payout.payoutAmount} on "${market.title}" was 100% refunded to your withdrawable wallet. No opposing counter-traders placed opposite bets on the losing side.`,
            type: 'INFO',
          });
        }
      }

      this.persist();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('balance_updated'));
        window.dispatchEvent(new Event('storage'));
      }
      return;
    }

    // Normal Settlement & Escrow Distribution with Counter-Traders:
    // 15% Creator Royalty to the Room Host's withdrawable wallet balance
    if (isUserRoom && settlement.creatorRoyalty > 0) {
      const host = this.users.find((u) => u.id === market.creatorId);
      if (host) {
        host.realBalance += settlement.creatorRoyalty;
        if (this.currentUser?.id === host.id) {
          this.currentUser.realBalance = host.realBalance;
        }

        this.transactions.unshift({
          id: 'tx-royalty-' + Date.now(),
          userId: host.id,
          type: 'ROOM_ROYALTY_PAYOUT',
          amount: settlement.creatorRoyalty,
          status: 'COMPLETED',
          balanceType: 'REAL',
          marketId: market.id,
          marketTitle: market.title,
          timestamp: new Date().toISOString(),
          notes: `15% Creator Royalty earned from Host Room "${market.title}" settlement`,
        });

        this.addNotification({
          userId: host.id,
          title: '💰 Creator Royalty Payout Credited!',
          message: `₹${settlement.creatorRoyalty} (15% Creator Royalty) from your Friend Room "${market.title}" credited to your withdrawable wallet balance!`,
          type: 'SUCCESS',
        });
      }
    }

    // Distribute payout amounts directly to ALL winning traders:
    // Guaranteed payout = (Principal Investment × Multiplier)
    for (const payout of settlement.payouts) {
      const bet = this.bets.find((b) => b.id === payout.betId);
      if (bet) {
        bet.status = payout.status;
        bet.payoutAmount = payout.payoutAmount;
      }

      if (payout.status === 'WON') {
        const winner = this.users.find((u) => u.id === payout.userId);
        if (winner) {
          winner.realBalance += payout.payoutAmount;
          if (this.currentUser?.id === winner.id) {
            this.currentUser.realBalance = winner.realBalance;
          }

          this.transactions.unshift({
            id: 'tx-win-' + Date.now() + '-' + payout.betId,
            userId: winner.id,
            type: 'WINNING_PAYOUT',
            amount: payout.payoutAmount,
            status: 'COMPLETED',
            balanceType: 'REAL',
            marketId: market.id,
            marketTitle: market.title,
            timestamp: new Date().toISOString(),
            notes: `Winning Escrow Payout on [${winningSide}] (${payout.multiplier}x Return) • 1.01x Guaranteed`,
          });

          this.addNotification({
            userId: winner.id,
            title: '🏆 Winning Escrow Payout Credited!',
            message: `Congratulations! Your prediction on "${market.title}" was correct. ₹${payout.payoutAmount} disbursed to your real wallet balance!`,
            type: 'SUCCESS',
          });
        }
      }
    }

    this.persist();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('balance_updated'));
      window.dispatchEvent(new Event('storage'));
    }
  }

  // --- Universal Market/Room Deletion with 100% Escrow Refunds ---
  public deleteMarketWithEscrowRefund(
    marketId: string,
    cancellationReason: string,
    adminUserId: string
  ) {
    const market = this.markets.find((m) => m.id === marketId);
    if (!market) throw new Error('Market not found');

    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin) {
      throw new Error('Only Super Admin can execute market deletion and escrow refund');
    }

    market.status = 'CANCELLED';
    market.cancellationReason = cancellationReason;

    // Refund 100% of active bets
    const activeBets = this.bets.filter(
      (b) => b.marketId === marketId && b.status === 'ACTIVE'
    );

    for (const bet of activeBets) {
      bet.status = 'REFUNDED';
      const user = this.users.find((u) => u.id === bet.userId);
      if (user) {
        user.realBalance += bet.realAmount;
        user.promoBalance += bet.promoAmount;

        this.transactions.unshift({
          id: 'tx-refund-' + Date.now() + '-' + bet.id,
          userId: user.id,
          type: 'TRADE_REFUND',
          amount: bet.amount,
          status: 'COMPLETED',
          balanceType: bet.promoAmount > 0 ? (bet.realAmount > 0 ? 'COMBINED' : 'PROMO') : 'REAL',
          marketId: market.id,
          marketTitle: market.title,
          timestamp: new Date().toISOString(),
          notes: `100% Escrow Refund. Reason: ${cancellationReason}`,
        });

        this.addNotification({
          userId: user.id,
          title: '🔄 100% Escrow Refund Processed',
          message: `Market "${market.title}" was cancelled by Admin. Reason: "${cancellationReason}". ₹${bet.amount} refunded to your wallet.`,
          type: 'ALERT',
        });
      }
    }

    // Remove from active listings or mark cancelled
    this.persist();
  }

  // --- Deposit & Fraud Guard Queue ---
  public requestDeposit(
    userId: string,
    amount: number,
    utrNumber: string,
    upiId: string,
    paymentMethod = 'UPI'
  ): Transaction {
    if (amount < this.config.minDepositAmount) {
      throw new Error(`Minimum deposit amount is ₹${this.config.minDepositAmount}`);
    }

    const cleanUtr = utrNumber.trim().toUpperCase();
    if (cleanUtr.length < 8) {
      throw new Error('Please enter a valid 12-digit UTR / Reference number from your payment app');
    }

    // Check duplicate UTR fraud attempt across transactions and queue
    const existingTx = this.transactions.find(
      (t) => t.type === 'DEPOSIT' && t.utrNumber?.toUpperCase() === cleanUtr && t.status !== 'REJECTED'
    );
    const existingInQueue = this.pendingDepositsQueue.find(
      (q) => q.utrNumber.toUpperCase() === cleanUtr && q.status === 'PENDING'
    );
    if (existingTx || existingInQueue) {
      throw new Error('This UTR transaction reference has already been submitted for verification.');
    }

    const user = this.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');

    const txId = 'tx-dep-' + Date.now();
    const timestamp = new Date().toISOString();

    // 1. Save into user's individual transaction history
    const tx: Transaction = {
      id: txId,
      userId,
      type: 'DEPOSIT',
      amount,
      status: 'PENDING',
      balanceType: 'REAL',
      utrNumber: cleanUtr,
      upiId: upiId.trim(),
      timestamp,
      notes: 'Pending Admin UTR verification approval',
    };
    this.transactions.unshift(tx);

    // 2. Save into global pending deposits queue
    const queueItem: PendingDepositItem = {
      id: txId,
      transactionId: txId,
      userId: user.id,
      userName: user.displayName,
      userEmail: user.email,
      amount,
      utrNumber: cleanUtr,
      upiId: upiId.trim() || user.kyc?.upiHandle || 'Direct UPI',
      timestamp,
      status: 'PENDING',
      paymentMethod,
      notes: 'Pending Admin UTR verification approval',
    };
    // Ensure no duplicate in queue
    this.pendingDepositsQueue = this.pendingDepositsQueue.filter(
      (item) => item.transactionId !== txId && item.utrNumber !== cleanUtr
    );
    this.pendingDepositsQueue.unshift(queueItem);

    this.addNotification({
      userId,
      title: '⏳ Deposit Verification Pending',
      message: `Deposit of ₹${amount} with UTR ${cleanUtr} submitted. Admin will verify and credit your wallet shortly.`,
      type: 'INFO',
    });

    this.persist();

    // 3. Dispatch custom window events upon submission to trigger immediate UI reactivity across all open tabs/views
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('deposit_submitted', {
          detail: { queueItem, tx, amount, userId },
        })
      );
      window.dispatchEvent(new CustomEvent('pending_deposits_updated'));
      window.dispatchEvent(new CustomEvent('balance_updated'));
      window.dispatchEvent(new Event('storage'));
    }

    return tx;
  }

  public approveDeposit(identifier: string, adminUserId: string) {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin && admin?.role !== 'admin') {
      throw new Error('Unauthorized: Super-Admin privileges required.');
    }

    // Match by transactionId or queue item id
    const queueItem = this.pendingDepositsQueue.find(
      (item) => item.id === identifier || item.transactionId === identifier
    );

    let tx = this.transactions.find((t) => t.id === identifier || t.id === queueItem?.transactionId);
    const targetUserId = tx?.userId || queueItem?.userId;
    const depositAmount = tx?.amount ?? queueItem?.amount;

    if (!targetUserId || !depositAmount) {
      throw new Error('Pending deposit transaction or queue record not found');
    }

    const user = this.users.find((u) => u.id === targetUserId);
    if (!user) throw new Error('Target user account not found');

    // a) Update transaction status to 'COMPLETED'
    if (tx) {
      tx.status = 'COMPLETED';
      tx.notes = 'Deposit Verified & Approved by Admin';
    } else {
      tx = {
        id: identifier,
        userId: targetUserId,
        type: 'DEPOSIT',
        amount: depositAmount,
        status: 'COMPLETED',
        balanceType: 'REAL',
        utrNumber: queueItem?.utrNumber,
        upiId: queueItem?.upiId,
        timestamp: new Date().toISOString(),
        notes: 'Deposit Verified & Approved by Admin',
      };
      this.transactions.unshift(tx);
    }

    // b) Credit the requested amount (+₹2,500) directly to the target user's Real Withdrawable Balance
    user.realBalance += depositAmount;
    if (this.currentUser?.id === user.id) {
      this.currentUser.realBalance = user.realBalance;
    }

    // c) Remove the item from the pending queue
    this.pendingDepositsQueue = this.pendingDepositsQueue.filter(
      (item) => item.id !== identifier && item.transactionId !== identifier
    );

    this.addNotification({
      userId: user.id,
      title: '✅ Deposit Approved & Credited!',
      message: `Your deposit of ₹${depositAmount} has been verified and added to your real balance.`,
      type: 'SUCCESS',
    });

    this.persist();

    // Re-render both Admin and User views instantly
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('deposit_approved', {
          detail: { identifier, amount: depositAmount, userId: user.id },
        })
      );
      window.dispatchEvent(new CustomEvent('pending_deposits_updated'));
      window.dispatchEvent(
        new CustomEvent('balance_updated', {
          detail: { userId: user.id, realBalance: user.realBalance },
        })
      );
      window.dispatchEvent(new Event('storage'));
    }
  }

  public rejectDeposit(identifier: string, rejectionReason: string, adminUserId: string) {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin && admin?.role !== 'admin') throw new Error('Unauthorized');

    const queueItem = this.pendingDepositsQueue.find(
      (item) => item.id === identifier || item.transactionId === identifier
    );

    let tx = this.transactions.find((t) => t.id === identifier || t.id === queueItem?.transactionId);
    const targetUserId = tx?.userId || queueItem?.userId;

    if (tx) {
      tx.status = 'REJECTED';
      tx.rejectionReason = rejectionReason;
      tx.notes = `Deposit Declined - ${rejectionReason}`;
    }

    // Remove from pending deposits queue
    this.pendingDepositsQueue = this.pendingDepositsQueue.filter(
      (item) => item.id !== identifier && item.transactionId !== identifier
    );

    if (targetUserId) {
      this.addNotification({
        userId: targetUserId,
        title: '❌ Deposit Request Declined',
        message: `Your payment request was rejected: ${rejectionReason}`,
        type: 'ALERT',
      });
    }

    this.persist();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('deposit_rejected', {
          detail: { identifier, reason: rejectionReason, userId: targetUserId },
        })
      );
      window.dispatchEvent(new CustomEvent('pending_deposits_updated'));
      window.dispatchEvent(new CustomEvent('balance_updated'));
      window.dispatchEvent(new Event('storage'));
    }
  }

  // --- Withdrawal Queue & Limits ---
  public requestWithdrawal(
    userId: string,
    amount: number,
    upiOrBank: string,
    pin?: string
  ): Transaction {
    const user = this.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');

    // 4-Digit Security PIN Validation
    if (!user.withdrawalPin) {
      if (!pin || !/^\d{4}$/.test(pin.trim())) {
        throw new Error('Please configure a 4-digit Withdrawal Security PIN to protect your funds.');
      }
      user.withdrawalPin = pin.trim();
    } else {
      if (!pin || pin.trim() !== user.withdrawalPin) {
        throw new Error('Invalid 4-digit Withdrawal Security PIN. Please check and try again.');
      }
    }

    if (amount < this.config.minWithdrawalAmount) {
      throw new Error(`Minimum withdrawal amount is ₹${this.config.minWithdrawalAmount}`);
    }

    if (user.realBalance < amount) {
      throw new Error(`Insufficient real balance. You have ₹${user.realBalance.toFixed(2)} withdrawable.`);
    }

    // Role-based admin bypass for KYC
    if (!user.isAdmin) {
      if (!user.kyc.isVerified || !user.kyc.panNumber) {
        throw new Error('KYC verification (PAN & UPI Handle) required before withdrawing real cash.');
      }
      if (this.isUserInRestrictedState(user)) {
        throw new Error(`Real money withdrawals restricted for residents of ${user.kyc.state}.`);
      }
    }

    // Lock funds from realBalance while in pending queue
    user.realBalance -= amount;

    const tx: Transaction = {
      id: 'tx-wth-' + Date.now(),
      userId,
      type: 'WITHDRAWAL',
      amount,
      status: 'PENDING',
      balanceType: 'REAL',
      bankDetails: upiOrBank,
      timestamp: new Date().toISOString(),
      notes: `Withdrawal request to ${upiOrBank}`,
    };

    this.transactions.unshift(tx);

    // Append to global pending withdrawals queue
    const queueItem: PendingWithdrawalItem = {
      id: tx.id,
      transactionId: tx.id,
      userId: user.id,
      userName: user.displayName,
      userEmail: user.email,
      amount,
      bankDetails: upiOrBank,
      timestamp: tx.timestamp,
      status: 'PENDING',
      notes: `Withdrawal request to ${upiOrBank}`,
    };
    this.pendingWithdrawalsQueue = this.pendingWithdrawalsQueue.filter(
      (item) => item.transactionId !== tx.id && item.id !== tx.id
    );
    this.pendingWithdrawalsQueue.unshift(queueItem);

    this.addNotification({
      userId,
      title: '⏳ Withdrawal Queued',
      message: `Withdrawal of ₹${amount} to ${upiOrBank} queued for processing.`,
      type: 'INFO',
    });

    this.persist();

    // Dispatch custom events for immediate reactivity
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('withdrawal_submitted', {
          detail: { queueItem, tx, amount, userId },
        })
      );
      window.dispatchEvent(new CustomEvent('pending_withdrawals_updated'));
      window.dispatchEvent(
        new CustomEvent('balance_updated', {
          detail: { userId, realBalance: user.realBalance },
        })
      );
      window.dispatchEvent(new Event('storage'));
    }

    return tx;
  }

  public approveWithdrawal(identifier: string, adminUserId: string) {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin && admin?.role !== 'admin') throw new Error('Unauthorized: Super-Admin privileges required.');

    const queueItem = this.pendingWithdrawalsQueue.find(
      (item) => item.id === identifier || item.transactionId === identifier
    );

    let tx = this.transactions.find((t) => t.id === identifier || t.id === queueItem?.transactionId);
    if (!tx && !queueItem) {
      throw new Error('Pending withdrawal transaction or queue item not found');
    }

    if (tx) {
      tx.status = 'COMPLETED';
      tx.notes = 'Withdrawal Processed & Approved by Admin';
    }

    // Remove from pending withdrawals queue
    this.pendingWithdrawalsQueue = this.pendingWithdrawalsQueue.filter(
      (item) => item.id !== identifier && item.transactionId !== identifier
    );

    const targetUserId = tx?.userId || queueItem?.userId;
    const amount = tx?.amount ?? queueItem?.amount;
    const bankDetails = tx?.bankDetails || queueItem?.bankDetails;

    if (targetUserId) {
      this.addNotification({
        userId: targetUserId,
        title: '💸 Withdrawal Processed Successfully!',
        message: `₹${amount} has been transferred to your payout account (${bankDetails}).`,
        type: 'SUCCESS',
      });
    }

    this.persist();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('withdrawal_approved', {
          detail: { identifier, txId: tx?.id, userId: targetUserId, amount },
        })
      );
      window.dispatchEvent(new CustomEvent('pending_withdrawals_updated'));
      window.dispatchEvent(new CustomEvent('balance_updated'));
      window.dispatchEvent(new Event('storage'));
    }
  }

  public rejectWithdrawal(identifier: string, reason: string, adminUserId: string) {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin && admin?.role !== 'admin') throw new Error('Unauthorized: Super-Admin privileges required.');

    const queueItem = this.pendingWithdrawalsQueue.find(
      (item) => item.id === identifier || item.transactionId === identifier
    );

    let tx = this.transactions.find((t) => t.id === identifier || t.id === queueItem?.transactionId);
    const targetUserId = tx?.userId || queueItem?.userId;
    const amount = tx?.amount ?? queueItem?.amount;

    if (!targetUserId || amount === undefined) {
      throw new Error('Pending withdrawal transaction or queue record not found');
    }

    const user = this.users.find((u) => u.id === targetUserId);
    if (user) {
      // Refund balance
      user.realBalance += amount;
      if (this.currentUser?.id === user.id) {
        this.currentUser.realBalance = user.realBalance;
      }

      // c) For rejected withdrawals, immediately refund requested amount back to user's wallet with entry: "Withdrawal Refund (Rejected)"
      this.transactions.unshift({
        id: 'tx-wth-ref-' + Date.now(),
        userId: user.id,
        type: 'TRADE_REFUND',
        amount: amount,
        status: 'COMPLETED',
        balanceType: 'REAL',
        timestamp: new Date().toISOString(),
        notes: `Withdrawal Refund (Rejected) - ${reason}`,
        rejectionReason: reason,
      });
    }

    if (tx) {
      tx.status = 'REJECTED';
      tx.rejectionReason = reason;
      tx.notes = `Withdrawal Rejected - ${reason}`;
    }

    // Remove from pending withdrawals queue
    this.pendingWithdrawalsQueue = this.pendingWithdrawalsQueue.filter(
      (item) => item.id !== identifier && item.transactionId !== identifier
    );

    this.addNotification({
      userId: targetUserId,
      title: '❌ Withdrawal Request Rejected',
      message: `Your payment request was rejected: ${reason}`,
      type: 'ALERT',
    });

    this.persist();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('withdrawal_rejected', {
          detail: { identifier, reason, userId: targetUserId },
        })
      );
      window.dispatchEvent(new CustomEvent('pending_withdrawals_updated'));
      window.dispatchEvent(
        new CustomEvent('balance_updated', {
          detail: { userId: targetUserId, realBalance: user?.realBalance },
        })
      );
      window.dispatchEvent(new Event('storage'));
    }
  }

  // --- Referral Engine ---
  private processReferralReward(referrerCode: string, referee: User) {
    const referrer = this.users.find(
      (u) => u.referralCode?.toUpperCase() === referrerCode.toUpperCase()
    );
    if (!referrer || referrer.id === referee.id) return;

    const reward = this.referralSettings.referrerReward;
    referrer.realBalance += reward;

    this.transactions.unshift({
      id: 'tx-ref-' + Date.now(),
      userId: referrer.id,
      type: 'REFERRAL_BONUS',
      amount: reward,
      status: 'COMPLETED',
      balanceType: 'REAL',
      timestamp: new Date().toISOString(),
      notes: `Referral bonus earned for ${referee.displayName}'s first trade`,
    });

    this.addNotification({
      userId: referrer.id,
      title: '🎉 Referral Bonus Received!',
      message: `Your referee ${referee.displayName} made their first trade! ₹${reward} added to your real balance.`,
      type: 'SUCCESS',
    });
  }

  // --- Admin Retention Bonus ---
  public sendRetentionBonus(
    targetUserId: string,
    amount: number,
    notes: string,
    adminUserId: string
  ) {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin) throw new Error('Unauthorized');

    const user = this.users.find((u) => u.id === targetUserId);
    if (!user) throw new Error('Target user not found');

    user.promoBalance += amount;

    this.transactions.unshift({
      id: 'tx-retention-' + Date.now(),
      userId: user.id,
      type: 'RETENTION_BONUS',
      amount,
      status: 'COMPLETED',
      balanceType: 'PROMO',
      timestamp: new Date().toISOString(),
      notes: notes || '🎁 Admin VIP Retention Bonus',
    });

    this.addNotification({
      userId: user.id,
      title: '🎁 Special VIP Bonus Credited!',
      message: `Admin granted you ₹${amount} in Play Bonus credit! Notes: ${notes || 'Enjoy your trading.'}`,
      type: 'SUCCESS',
    });

    this.persist();
  }

  // --- User Analytics Deep Dive ---
  public getUserAnalytics(userId: string) {
    const user = this.users.find((u) => u.id === userId);
    if (!user) return null;

    const userTx = this.transactions.filter((t) => t.userId === userId);
    const userBets = this.bets.filter((b) => b.userId === userId);

    const totalDeposited = userTx
      .filter((t) => t.type === 'DEPOSIT' && t.status === 'APPROVED')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalWithdrawn = userTx
      .filter((t) => t.type === 'WITHDRAWAL' && t.status === 'COMPLETED')
      .reduce((sum, t) => sum + t.amount, 0);

    const wonBets = userBets.filter((b) => b.status === 'WON');
    const totalWonPayout = wonBets.reduce((sum, b) => sum + (b.payoutAmount || 0), 0);
    const totalTraded = userBets.reduce((sum, b) => sum + b.amount, 0);

    const winRate =
      userBets.filter((b) => b.status === 'WON' || b.status === 'LOST').length > 0
        ? (wonBets.length /
            userBets.filter((b) => b.status === 'WON' || b.status === 'LOST').length) *
          100
        : 0;

    const netPL = totalWonPayout - totalTraded;

    // Category breakdown
    const categoryCounts: Record<string, number> = {};
    for (const b of userBets) {
      const m = this.markets.find((mkt) => mkt.id === b.marketId);
      const cat = m?.category || 'Others';
      categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
    }

    return {
      user,
      totalDeposited,
      totalWithdrawn,
      totalTraded,
      totalWonPayout,
      netPL,
      winRate: Math.round(winRate),
      totalBets: userBets.length,
      categoryCounts,
    };
  }

  // --- Config & Settings Getters/Setters ---
  public getConfig(): SystemConfig {
    return this.config;
  }

  public updateConfig(newConfig: Partial<SystemConfig>, adminUserId: string) {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin) throw new Error('Unauthorized');

    this.config = { ...this.config, ...newConfig };
    this.persist();
  }

  public getReferralSettings(): ReferralSettings {
    return this.referralSettings;
  }

  public updateReferralSettings(newSettings: Partial<ReferralSettings>, adminUserId: string) {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin) throw new Error('Unauthorized');

    this.referralSettings = { ...this.referralSettings, ...newSettings };
    this.persist();
  }

  public updateMarketFeeOverride(
    marketId: string,
    customHouseFee: number | undefined,
    customCreatorRoyalty: number | undefined,
    adminUserId: string
  ) {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin) throw new Error('Unauthorized');

    const market = this.markets.find((m) => m.id === marketId);
    if (!market) throw new Error('Market not found');

    market.customHouseFee = customHouseFee;
    market.customCreatorRoyalty = customCreatorRoyalty;
    this.persist();
  }

  // --- Transactions & Bets Getters ---
  public getTransactions(userId?: string): Transaction[] {
    if (userId) {
      return this.transactions.filter((t) => t.userId === userId);
    }
    return this.transactions;
  }

  public getBets(userId?: string): MarketBet[] {
    if (userId) {
      return this.bets.filter((b) => b.userId === userId);
    }
    return this.bets;
  }

  // --- Notifications ---
  public getNotifications(userId?: string): SystemNotification[] {
    if (!userId) return this.notifications;
    return this.notifications.filter((n) => n.userId === 'ALL' || n.userId === userId);
  }

  public markNotificationsRead(userId?: string) {
    this.notifications.forEach((n) => {
      if (!userId || n.userId === 'ALL' || n.userId === userId) {
        n.read = true;
      }
    });
    this.persist();
  }

  public addNotification(notification: Omit<SystemNotification, 'id' | 'timestamp' | 'read'>) {
    this.notifications.unshift({
      ...notification,
      id: 'note-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5),
      timestamp: new Date().toISOString(),
      read: false,
    });
    this.persist();
  }

  // --- Admin User Management & Balance Adjustment ---
  public adjustUserBalance(
    userId: string,
    deltaAmount: number,
    reason: string,
    adminUserId: string
  ): User {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin) throw new Error('Unauthorized');

    const user = this.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');

    user.realBalance = Math.max(0, user.realBalance + deltaAmount);

    this.transactions.unshift({
      id: 'tx-adj-' + Date.now(),
      userId: user.id,
      type: 'ADMIN_ADJUSTMENT',
      amount: Math.abs(deltaAmount),
      status: 'COMPLETED',
      balanceType: 'REAL',
      timestamp: new Date().toISOString(),
      notes: `Admin Balance Adjustment: ${deltaAmount >= 0 ? '+' : '-'}₹${Math.abs(deltaAmount)} (${reason})`,
    });

    this.addNotification({
      userId: user.id,
      title: deltaAmount >= 0 ? '💰 Wallet Credited by Admin' : '⚠️ Balance Adjusted by Admin',
      message: `Your balance was adjusted by ${deltaAmount >= 0 ? '+' : '-'}₹${Math.abs(deltaAmount)}. Reason: ${reason}`,
      type: deltaAmount >= 0 ? 'SUCCESS' : 'WARNING',
    });

    this.persist();
    return user;
  }

  public toggleBlockUser(userId: string, adminUserId: string): User {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin) throw new Error('Unauthorized');

    const user = this.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');
    if (user.isAdmin) throw new Error('Cannot block an administrator account');

    user.isBlocked = !user.isBlocked;
    this.persist();
    return user;
  }

  // --- Broadcasts ---
  public getBroadcasts(): BroadcastMessage[] {
    return this.broadcasts;
  }

  public dispatchBroadcast(
    segment: TargetCustomerSegment,
    headline: string,
    message: string,
    deepLinkId?: string,
    adminUserId?: string
  ): BroadcastMessage {
    const admin = this.users.find((u) => u.id === adminUserId);
    if (!admin?.isAdmin) throw new Error('Unauthorized');

    let count = this.users.length;
    if (segment === 'Active Traders') count = Math.max(1, Math.round(this.users.length * 0.7));
    if (segment === 'Inactive Users') count = Math.max(1, Math.round(this.users.length * 0.3));
    if (segment.includes('Category')) count = Math.max(1, Math.round(this.users.length * 0.4));

    const broadcast: BroadcastMessage = {
      id: 'bc-' + Date.now(),
      segment,
      headline,
      deepLinkId,
      message,
      timestamp: new Date().toISOString(),
      sentBy: admin.displayName || 'Administrator',
      recipientCount: count,
    };

    this.broadcasts.unshift(broadcast);

    this.addNotification({
      userId: 'ALL',
      title: `📢 [${segment}] ${headline}`,
      message,
      type: 'INFO',
    });

    this.persist();
    return broadcast;
  }

  // --- Solvency & Clearing Metrics ---
  public getEscrowStats() {
    const totalVolume = this.markets.reduce((sum, m) => sum + m.totalVolume, 0);
    const platformRevenue = Math.round(totalVolume * 0.10);
    const friendRooms = this.markets.filter((m) => !m.isOfficialAdmin);
    const creatorRoyalties = Math.round(
      friendRooms.reduce((sum, m) => sum + m.totalVolume * 0.15, 0)
    );
    const activeVerifiedUsers = this.users.filter((u) => u.kyc?.isVerified).length;

    // Current escrow locked in open markets
    const openMarkets = this.markets.filter((m) => m.status === 'OPEN');
    const totalEscrowLocked = openMarkets.reduce((sum, m) => sum + m.totalVolume, 0);

    return {
      totalVolume,
      platformRevenue,
      creatorRoyalties,
      activeVerifiedUsers,
      totalEscrowLocked,
      activeFriendRoomsCount: friendRooms.filter((m) => m.status === 'OPEN').length,
    };
  }
}

export const storageService = new StorageService();
