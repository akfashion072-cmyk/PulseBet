import { useState, useEffect, useMemo } from 'react';
import {
  PlusCircle,
  Sparkles,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  UserCheck,
  LogOut,
} from 'lucide-react';
import { BetSide, Currency, Market, MarketBet, MarketCategory, User } from './types';
import { storageService } from './services/storageService';
import { Navbar } from './components/Navbar';
import { StickyHeroBanner } from './components/StickyHeroBanner';
import { MarketPills } from './components/MarketPills';
import { LiveEventCard } from './components/LiveEventCard';
import { TradeModal } from './components/TradeModal';
import { CashoutModal } from './components/CashoutModal';
import { DepositModal } from './components/DepositModal';
import { WithdrawModal } from './components/WithdrawModal';
import { CreateFriendRoomModal } from './components/CreateFriendRoomModal';
import { UserProfileModal } from './components/UserProfileModal';
import { SuperAdminDashboard } from './components/SuperAdminDashboard';
import { AuthModal } from './components/AuthModal';
import { NotificationDrawer } from './components/NotificationDrawer';
import { OfflineIndicator } from './components/OfflineIndicator';
import { Footer } from './components/Footer';

export default function App() {
  // Global State
  const [currentUser, setCurrentUser] = useState<User | null>(() => storageService.getCurrentUser());
  const [currency, setCurrency] = useState<Currency>(() => storageService.getCurrency());
  const [activeTab, setActiveTab] = useState<'markets' | 'create-room' | 'wallet' | 'admin'>('markets');
  const [markets, setMarkets] = useState<Market[]>(() => storageService.getMarkets());
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Filters
  const [selectedCategory, setSelectedCategory] = useState<MarketCategory>('All');
  const [showFriendRoomsOnly, setShowFriendRoomsOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // State Compliance Guard
  const isRestricted = storageService.isUserInRestrictedState(currentUser);
  const userDetectedState = storageService.getUserDetectedState(currentUser);

  // Admin Impersonation Context
  const impersonatorAdmin = useMemo(() => {
    return storageService.getImpersonatorAdmin();
  }, [currentUser, refreshTrigger]);

  // Active Modals State
  const [tradeModalMarket, setTradeModalMarket] = useState<Market | null>(null);
  const [tradeModalSide, setTradeModalSide] = useState<BetSide>('YES');
  const [cashoutBet, setCashoutBet] = useState<MarketBet | null>(null);
  const [cashoutMarket, setCashoutMarket] = useState<Market | null>(null);

  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [showCreateRoomModal, setShowCreateRoomModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  // Toast / Status Alerts
  const [toastMessage, setToastMessage] = useState<{ text: string; isError?: boolean } | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // On application mount: Read saved session from localStorage (pulsebet_user_session)
  useEffect(() => {
    const sessionUser = storageService.getCurrentUser();
    if (sessionUser) {
      setCurrentUser(sessionUser);
    }
  }, []);

  // Direct Link Detection for Private Markets (?market=ID, ?room=CODE, or #HASH)
  // Private markets remain strictly hidden from public feeds and accessible only via direct link or user profile modal
  const [directMarket, setDirectMarket] = useState<Market | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const targetMarketId = params.get('market') || params.get('id');
    const targetRoomCode = params.get('room') || params.get('code') || window.location.hash.replace('#', '');

    if (targetMarketId) {
      const found = storageService.getMarketById(targetMarketId);
      if (found) {
        setDirectMarket(found);
      }
    } else if (targetRoomCode) {
      const all = storageService.getMarkets();
      const found = all.find((m) => m.roomCode && m.roomCode.toLowerCase() === targetRoomCode.toLowerCase());
      if (found) {
        setDirectMarket(found);
      }
    }
  }, [markets]);

  // Listen to deposit submission, approval, balance updates, and cross-tab storage events
  useEffect(() => {
    const handleReactivity = () => {
      const freshUser = storageService.getCurrentUser();
      setCurrentUser(freshUser);
      setMarkets([...storageService.getMarkets()]);
      setRefreshTrigger((prev) => prev + 1);
    };

    window.addEventListener('deposit_submitted', handleReactivity);
    window.addEventListener('deposit_approved', handleReactivity);
    window.addEventListener('deposit_rejected', handleReactivity);
    window.addEventListener('pending_deposits_updated', handleReactivity);
    window.addEventListener('balance_updated', handleReactivity);
    window.addEventListener('storage', handleReactivity);

    return () => {
      window.removeEventListener('deposit_submitted', handleReactivity);
      window.removeEventListener('deposit_approved', handleReactivity);
      window.removeEventListener('deposit_rejected', handleReactivity);
      window.removeEventListener('pending_deposits_updated', handleReactivity);
      window.removeEventListener('balance_updated', handleReactivity);
      window.removeEventListener('storage', handleReactivity);
    };
  }, []);

  // Monitor transactions for newly rejected deposit/withdrawal to trigger rejection toast notification
  useEffect(() => {
    if (!currentUser) return;
    const txs = storageService.getTransactions(currentUser.id);
    const unnotifiedRejected = txs.find(
      (t) => t.status === 'REJECTED' && t.rejectionReason && !sessionStorage.getItem('notified_rejected_tx_' + t.id)
    );
    if (unnotifiedRejected) {
      sessionStorage.setItem('notified_rejected_tx_' + unnotifiedRejected.id, 'true');
      showToast(`Your payment request was rejected: ${unnotifiedRejected.rejectionReason}`, true);
    }
  }, [currentUser, refreshTrigger]);

  const refreshData = () => {
    const freshUser = storageService.getCurrentUser();
    setCurrentUser(freshUser);
    setMarkets([...storageService.getMarkets()]);
    setRefreshTrigger((prev) => prev + 1);
  };

  const handleInAppRefresh = () => {
    setIsRefreshing(true);
    // Background data re-sync from storage
    const synced = storageService.syncFromStorage();
    setCurrentUser(synced.currentUser);
    setMarkets([...synced.markets]);
    setRefreshTrigger((prev) => prev + 1);

    showToast('Live Data & Balances Updated', false);

    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  const handleLogout = () => {
    storageService.logoutUser();
    setCurrentUser(null);
    setActiveTab('markets');
    showToast('Logged out successfully', false);
  };

  const handleExitImpersonation = () => {
    try {
      const admin = storageService.stopImpersonation();
      setCurrentUser(admin);
      setActiveTab('admin');
      showToast('Exited Impersonation Mode. Restored Super-Admin account.', false);
    } catch (e: any) {
      showToast(e.message, true);
    }
  };

  const showToast = (text: string, isError = false) => {
    setToastMessage({ text, isError });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Currency Toggle
  const handleCurrencyToggle = () => {
    const next = currency === 'INR' ? 'USD' : 'INR';
    storageService.setCurrency(next);
    setCurrency(next);
  };

  // Admin Route Protection Guard
  const handleTabChange = (tab: 'markets' | 'create-room' | 'wallet' | 'admin') => {
    if (tab === 'admin') {
      if (!currentUser || (!currentUser.isAdmin && currentUser.role !== 'admin')) {
        showToast('Access Denied: Admin Privileges Required', true);
        setActiveTab('markets');
        return;
      }
    }
    setActiveTab(tab);
  };

  // Helper to identify private markets
  // Strictly omit markets where isPublic === false or visibility === 'private'
  const isPrivateMarket = (m: Market) => {
    return m.isPublic === false || m.visibility === 'private' || m.isPrivate === true;
  };

  // Only public markets for feeds
  const publicMarkets = useMemo(() => {
    return markets.filter((m) => !isPrivateMarket(m));
  }, [markets]);

  // Category counts computation strictly for public feed
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { All: publicMarkets.length };
    for (const m of publicMarkets) {
      counts[m.category] = (counts[m.category] || 0) + 1;
    }
    return counts;
  }, [publicMarkets]);

  // Filtered Markets for Main Feeds (Home, Explore, Category Views)
  // Strictly omit markets where isPublic === false or visibility === 'private'
  const filteredMarkets = useMemo(() => {
    return markets.filter((m) => {
      // Private markets must remain hidden from public feeds!
      if (isPrivateMarket(m)) {
        return false;
      }

      // Friend rooms toggle
      if (showFriendRoomsOnly && m.isOfficialAdmin) return false;

      // Category filter
      if (selectedCategory !== 'All' && !showFriendRoomsOnly && m.category !== selectedCategory) {
        return false;
      }

      // Search query (matches title, description, or roomCode)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTitle = m.title.toLowerCase().includes(q);
        const matchesDesc = m.description.toLowerCase().includes(q);
        const matchesCode = m.roomCode?.toLowerCase().includes(q.replace('#', ''));
        if (!matchesTitle && !matchesDesc && !matchesCode) return false;
      }

      return true;
    });
  }, [markets, selectedCategory, showFriendRoomsOnly, searchQuery]);

  // Unread notifications count
  const unreadCount = useMemo(() => {
    return storageService
      .getNotifications(currentUser?.id)
      .filter((n) => !n.read).length;
  }, [currentUser, refreshTrigger]);

  const handleOpenTrade = (market: Market, side: BetSide) => {
    setTradeModalMarket(market);
    setTradeModalSide(side);
  };

  const handleOpenCashout = (bet: MarketBet, market: Market) => {
    setCashoutBet(bet);
    setCashoutMarket(market);
    setShowProfileModal(false);
  };

  const handleResolveMarket = (marketId: string, side: 'YES' | 'NO') => {
    try {
      storageService.resolveMarket(marketId, side, currentUser?.id || '');
      showToast(`Market resolved as [${side}]! 15% Host Royalty credited and escrow distributed with 1.01x guarantee.`, false);
      refreshData();
    } catch (e: any) {
      showToast(e.message, true);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex flex-col selection:bg-[#00F2FE]/25 selection:text-[#00F2FE]">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-20 right-4 z-50 max-w-sm p-4 rounded-2xl bg-[#0F172A] border text-white shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-200 ${
            toastMessage.isError
              ? 'border-red-500/50 shadow-[0_0_25px_rgba(239,68,68,0.25)]'
              : 'border-[#10B981]/50 shadow-[0_0_25px_rgba(16,185,129,0.25)]'
          }`}
        >
          {toastMessage.isError ? (
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
          ) : (
            <div className="w-5 h-5 rounded-full bg-[#10B981]/20 text-[#10B981] flex items-center justify-center shrink-0">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          )}
          <span className="text-xs font-bold leading-snug">{toastMessage.text}</span>
        </div>
      )}

      {/* Sticky Impersonation Banner */}
      {impersonatorAdmin && currentUser && (
        <div className="bg-gradient-to-r from-purple-950 via-indigo-950 to-purple-900 border-b border-purple-500/50 px-4 py-2.5 text-xs text-white flex items-center justify-between sticky top-0 z-50 shadow-2xl backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-ping shrink-0" />
            <div className="flex flex-wrap items-center gap-1 sm:gap-2">
              <span className="font-extrabold text-purple-200">
                Admin Impersonation Mode:
              </span>
              <span>
                Viewing as <strong className="text-white underline">{currentUser.displayName}</strong> ({currentUser.email})
              </span>
              <span className="hidden md:inline text-purple-300 text-[11px]">
                • Logged in via Admin: {impersonatorAdmin.displayName}
              </span>
            </div>
          </div>

          <button
            onClick={handleExitImpersonation}
            className="px-3.5 py-1.5 rounded-xl bg-purple-500 hover:bg-purple-400 text-black font-black text-xs transition shadow-lg flex items-center gap-1.5 shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Exit Impersonation</span>
          </button>
        </div>
      )}

      {/* Navbar with Guest vs Logged-In, Admin Guard, Refresh & Currency Switcher */}
      <Navbar
        currentUser={currentUser}
        currency={currency}
        onCurrencyToggle={handleCurrencyToggle}
        onRefreshData={handleInAppRefresh}
        isRefreshing={isRefreshing}
        onLogout={handleLogout}
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onOpenAuth={() => setShowAuthModal(true)}
        onOpenProfile={() => setShowProfileModal(true)}
        onOpenDeposit={() => setShowDepositModal(true)}
        onOpenNotifications={() => setShowNotifications(true)}
        unreadNotificationsCount={unreadCount}
      />

      {/* Main App Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-4">
        {/* TAB 1: P2P MARKETS FEED */}
        {activeTab === 'markets' && (
          <div className="space-y-4">
            {/* Direct Link Access Banner for Private Market */}
            {directMarket && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/40 via-[#0F172A] to-indigo-950/40 border border-[#00F2FE]/50 text-xs text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-[0_0_25px_rgba(0,242,254,0.2)] animate-in fade-in">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#00F2FE]/20 text-[#00F2FE] flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-white text-sm">
                        Direct Link Room Access #{directMarket.roomCode || directMarket.id}
                      </span>
                      {isPrivateMarket(directMarket) && (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                          Private Room
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                      {directMarket.title}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleOpenTrade(directMarket, 'YES')}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-extrabold text-xs transition shadow-md cursor-pointer"
                  >
                    Open & Trade
                  </button>
                  <button
                    onClick={() => setDirectMarket(null)}
                    className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-400 hover:text-white transition cursor-pointer"
                    title="Dismiss"
                  >
                    ✕
                  </button>
                </div>
              </div>
            )}
            {/* Restricted State Compliance Banner */}
            {isRestricted && (
              <div className="p-4 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-xs text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-[0_0_25px_rgba(245,158,11,0.15)] animate-in fade-in">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                  <div>
                    <span className="font-extrabold text-white text-sm">
                      ⚠️ Real-Money Trading Restricted in {userDetectedState}
                    </span>
                    <p className="text-[11px] text-slate-300 mt-0.5">
                      In compliance with state regulations, trading buttons are disabled. You may browse live markets in View-Only mode.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowProfileModal(true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-black font-extrabold text-xs transition border border-amber-500/40 shrink-0"
                >
                  📍 Manage State & KYC
                </button>
              </div>
            )}

            {/* Sticky High-Converting Neon Hero Banner */}
            <StickyHeroBanner
              currentUser={currentUser}
              currency={currency}
              onOpenAuth={() => setShowAuthModal(true)}
              onCreateRoom={() => setShowCreateRoomModal(true)}
            />

            {/* 8 Category Pills & Search Filter */}
            <MarketPills
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => setSelectedCategory(cat)}
              showFriendRoomsOnly={showFriendRoomsOnly}
              onToggleFriendRooms={() => setShowFriendRoomsOnly(!showFriendRoomsOnly)}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              categoryCounts={categoryCounts}
            />

            {/* Markets Grid */}
            {filteredMarkets.length === 0 ? (
              <div className="py-16 text-center rounded-3xl bg-[#0F172A]/50 border border-white/5 space-y-3">
                <p className="text-sm text-slate-400">
                  No prediction markets match your filter criteria.
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('All');
                    setShowFriendRoomsOnly(false);
                    setSearchQuery('');
                  }}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-white transition"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredMarkets.map((market) => (
                  <LiveEventCard
                    key={market.id}
                    market={market}
                    currentUser={currentUser}
                    currency={currency}
                    onTradeClick={handleOpenTrade}
                    onAdminDeleteClick={() => {
                      if (currentUser?.isAdmin) {
                        handleTabChange('admin');
                      }
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CREATE FRIEND ROOM BUILDER */}
        {activeTab === 'create-room' && (
          <div className="max-w-xl mx-auto py-6">
            <div className="text-center mb-6">
              <span className="text-[10px] bg-[#10B981]/20 text-[#10B981] px-3 py-1 rounded-full font-extrabold border border-[#10B981]/30 uppercase tracking-widest inline-block mb-2">
                Hybrid Social Betting
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                Build Your Custom Friend Room
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                Host public or private wagers, share instant links on WhatsApp/Telegram, and earn a guaranteed 15% Creator Royalty.
              </p>
            </div>

            <button
              onClick={() => setShowCreateRoomModal(true)}
              className="w-full py-4 rounded-3xl bg-gradient-to-r from-[#10B981] via-[#00F2FE] to-[#10B981] text-black font-black text-sm shadow-[0_0_30px_rgba(16,185,129,0.3)] hover:opacity-95 transition flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-5 h-5" />
              <span>Launch New Friend Room Now</span>
            </button>

            {/* Explainer highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-8">
              <div className="p-4 rounded-2xl bg-[#0F172A] border border-white/5 space-y-1">
                <span className="text-xs font-bold text-[#10B981]">15% Creator Royalty</span>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Earn passive profit credited to your withdrawable wallet from the total settled pool.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#0F172A] border border-white/5 space-y-1">
                <span className="text-xs font-bold text-[#00F2FE]">Hybrid Public Feed</span>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Your room automatically appears in the main feed for maximum liquidity, or toggle private for close squad bets.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#0F172A] border border-white/5 space-y-1">
                <span className="text-xs font-bold text-[#F59E0B]">Direct Share Code</span>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Each room gets a unique room code (#GOA26) and 1-tap WhatsApp/Telegram link.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: WALLET & LEDGER */}
        {activeTab === 'wallet' && (
          <div className="max-w-3xl mx-auto py-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-white">Wallet & Ledger</h2>
                <p className="text-xs text-slate-400">
                  Manage real balances, deposits, withdrawals & transparent audit logs
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setShowDepositModal(true)}
                  className="px-4 py-2 rounded-xl bg-[#10B981] hover:bg-[#059669] text-black font-extrabold text-xs transition shadow-md"
                >
                  + Add Funds (Min ₹100)
                </button>
                <button
                  onClick={() => setShowWithdrawModal(true)}
                  className="px-4 py-2 rounded-xl bg-[#F59E0B] hover:bg-[#d97706] text-black font-extrabold text-xs transition shadow-md"
                >
                  Withdraw (Min ₹200)
                </button>
              </div>
            </div>

            {/* Balances Card */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-5 rounded-3xl bg-[#0F172A] border border-[#10B981]/30 space-y-1">
                <span className="text-[10px] uppercase font-bold text-[#10B981] tracking-wider block">
                  Real Withdrawable Balance
                </span>
                <div className="text-2xl font-black text-white">
                  {currentUser ? storageService.formatAmount(currentUser.realBalance, currency) : '₹0'}
                </div>
                <p className="text-[10px] text-slate-400">
                  Available for instant withdrawal to UPI / Bank
                </p>
              </div>

              <div className="p-5 rounded-3xl bg-[#0F172A] border border-[#00F2FE]/30 space-y-1">
                <span className="text-[10px] uppercase font-bold text-[#00F2FE] tracking-wider block">
                  Promo Play Bonus (Virtual Credit)
                </span>
                <div className="text-2xl font-black text-[#00F2FE]">
                  {currentUser ? storageService.formatAmount(currentUser.promoBalance, currency) : '₹0'}
                </div>
                <p className="text-[10px] text-slate-400">
                  Usable strictly for prediction trades (turnover rules apply)
                </p>
              </div>

              <div className="p-5 rounded-3xl bg-[#0F172A] border border-white/10 space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                  Total Trading Liquidity
                </span>
                <div className="text-2xl font-black text-white">
                  {currentUser
                    ? storageService.formatAmount(
                        currentUser.realBalance + currentUser.promoBalance,
                        currency
                      )
                    : '₹0'}
                </div>
                <p className="text-[10px] text-slate-400">
                  Combined power for placing bets across markets
                </p>
              </div>
            </div>

            {/* Operating Limits Notice */}
            <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#10B981]" />
                <span className="text-slate-300 font-semibold">
                  Operating Rails: Min Trade ₹10 • Min Deposit ₹100 • Min Withdrawal ₹200
                </span>
              </div>
              <span className="text-[11px] text-[#00F2FE] font-mono">100% Escrow Protected</span>
            </div>

            {/* Full Transaction Audit Logs */}
            <div className="space-y-3">
              <h3 className="text-sm font-extrabold text-white">Recent Transactions & Queue Status</h3>
              {storageService.getTransactions(currentUser?.id).length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-500 rounded-2xl bg-[#0F172A]/40 border border-white/5">
                  No transaction history found.
                </div>
              ) : (
                <div className="space-y-2">
                  {storageService.getTransactions(currentUser?.id).map((tx) => (
                    <div
                      key={tx.id}
                      className={`p-3.5 rounded-2xl border transition ${
                        tx.status === 'REJECTED'
                          ? 'bg-red-950/20 border-red-500/30'
                          : 'bg-[#0F172A] border-white/5'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <strong className="text-white">{tx.type.replace(/_/g, ' ')}</strong>
                            <span
                              className={`text-[9px] px-2 py-0.5 rounded font-bold ${
                                tx.status === 'COMPLETED' || tx.status === 'APPROVED'
                                  ? 'bg-[#10B981]/20 text-[#10B981]'
                                  : tx.status === 'PENDING'
                                  ? 'bg-[#F59E0B]/20 text-[#F59E0B]'
                                  : 'bg-red-500/20 text-red-400 border border-red-500/40'
                              }`}
                            >
                              {tx.status}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400">
                            {tx.notes || (tx.utrNumber ? `UTR: ${tx.utrNumber}` : tx.timestamp)}
                          </p>
                        </div>

                        <div className="text-right shrink-0">
                          <div
                            className={`font-black text-sm ${
                              tx.type === 'DEPOSIT' ||
                              tx.type === 'TRADE_WIN' ||
                              tx.type === 'WINNING_PAYOUT' ||
                              tx.type === 'TRADE_CASHOUT' ||
                              tx.type === 'TRADE_REFUND' ||
                              tx.type === 'UNMATCHED_REFUND' ||
                              tx.type === 'CREATOR_ROYALTY' ||
                              tx.type === 'ROOM_ROYALTY_PAYOUT' ||
                              tx.type === 'REFERRAL_BONUS' ||
                              tx.type === 'RETENTION_BONUS' ||
                              tx.type === 'SIGNUP_PROMO'
                                ? 'text-[#10B981]'
                                : 'text-slate-200'
                            }`}
                          >
                            {tx.type === 'DEPOSIT' ||
                            tx.type === 'TRADE_WIN' ||
                            tx.type === 'WINNING_PAYOUT' ||
                            tx.type === 'TRADE_CASHOUT' ||
                            tx.type === 'TRADE_REFUND' ||
                            tx.type === 'UNMATCHED_REFUND' ||
                            tx.type === 'CREATOR_ROYALTY' ||
                            tx.type === 'ROOM_ROYALTY_PAYOUT' ||
                            tx.type === 'REFERRAL_BONUS' ||
                            tx.type === 'RETENTION_BONUS' ||
                            tx.type === 'SIGNUP_PROMO'
                              ? '+'
                              : '-'}
                            {storageService.formatAmount(tx.amount, currency)}
                          </div>
                          <span className="text-[9px] text-slate-500 block">
                            {new Date(tx.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                      </div>

                      {/* Prominent Rejection Reason Display */}
                      {tx.status === 'REJECTED' && tx.rejectionReason && (
                        <div className="mt-2.5 p-2.5 rounded-xl bg-red-500/15 border border-red-500/40 text-xs text-red-200 flex items-start gap-2 shadow-[0_0_15px_rgba(239,68,68,0.15)]">
                          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-extrabold text-white text-xs block">
                              Payment Request Rejected
                            </span>
                            <p className="text-[11px] text-red-300 mt-0.5 leading-snug">
                              <strong>Admin Remarks: </strong>"{tx.rejectionReason}"
                            </p>
                            {tx.type === 'WITHDRAWAL' && (
                              <span className="text-[10px] text-emerald-400 font-bold mt-1 block">
                                ✓ Requested amount has been immediately refunded to your withdrawable wallet.
                              </span>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Unmatched Trade Refund Badge */}
                      {(tx.notes?.includes('Unmatched Trade Refund') || tx.type === 'UNMATCHED_REFUND') && (
                        <div className="mt-1.5 p-2 rounded-xl bg-[#00F2FE]/10 border border-[#00F2FE]/30 text-[10px] text-[#00F2FE] flex items-center gap-1.5 font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#00F2FE] shrink-0" />
                          <span>Unmatched Trade Refund (100% Principal Returned) • Missing opposing liquidity</span>
                        </div>
                      )}

                      {/* Withdrawal Refund Badge */}
                      {tx.notes?.includes('Withdrawal Refund (Rejected)') && (
                        <div className="mt-1.5 p-2 rounded-xl bg-[#10B981]/10 border border-[#10B981]/30 text-[10px] text-[#10B981] flex items-center gap-1.5 font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981] shrink-0" />
                          <span>Withdrawal Refund (Rejected) • Funds returned to wallet</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: SUPER ADMIN HUB */}
        {activeTab === 'admin' && (
          <SuperAdminDashboard
            currentUser={currentUser}
            currency={currency}
            onClose={() => setActiveTab('markets')}
            onRefresh={refreshData}
          />
        )}
      </main>

      {/* High-Trust Footer */}
      <Footer />

      {/* --- ALL MODALS --- */}
      {/* Trade Modal */}
      {tradeModalMarket && (
        <TradeModal
          market={tradeModalMarket}
          initialSide={tradeModalSide}
          currentUser={currentUser}
          currency={currency}
          onClose={() => setTradeModalMarket(null)}
          onOpenAuth={() => setShowAuthModal(true)}
          onOpenDeposit={() => {
            setTradeModalMarket(null);
            setShowDepositModal(true);
          }}
          onTradeSuccess={() => {
            refreshData();
            showToast('Trade placed successfully!');
          }}
        />
      )}

      {/* Cashout Modal */}
      {cashoutBet && cashoutMarket && (
        <CashoutModal
          bet={cashoutBet}
          market={cashoutMarket}
          onClose={() => {
            setCashoutBet(null);
            setCashoutMarket(null);
          }}
          onCashoutSuccess={() => {
            refreshData();
            showToast('Position cashed out successfully!');
          }}
        />
      )}

      {/* Deposit Modal */}
      {showDepositModal && (
        <DepositModal
          currentUser={currentUser}
          currency={currency}
          onClose={() => setShowDepositModal(false)}
          onDepositSubmitted={() => {
            refreshData();
            showToast('Deposit submitted to Admin Verification Queue');
          }}
        />
      )}

      {/* Withdraw Modal */}
      {showWithdrawModal && (
        <WithdrawModal
          currentUser={currentUser}
          currency={currency}
          onClose={() => setShowWithdrawModal(false)}
          onWithdrawalSubmitted={() => {
            refreshData();
            showToast('Withdrawal queued for processing');
          }}
          onOpenKYC={() => setShowProfileModal(true)}
        />
      )}

      {/* Create Friend Room Modal */}
      {showCreateRoomModal && (
        <CreateFriendRoomModal
          currentUser={currentUser}
          currency={currency}
          onClose={() => setShowCreateRoomModal(false)}
          onRoomCreated={(_newId) => {
            setShowCreateRoomModal(false);
            refreshData();
            showToast('Friend Room created and live on P2P feed!');
            setActiveTab('markets');
          }}
          onOpenAuth={() => {
            setShowCreateRoomModal(false);
            setShowAuthModal(true);
          }}
        />
      )}

      {/* User Profile & KYC Modal */}
      {showProfileModal && (
        <UserProfileModal
          currentUser={currentUser}
          currency={currency}
          onClose={() => setShowProfileModal(false)}
          onOpenCashout={handleOpenCashout}
          onResolveMarket={handleResolveMarket}
          onOpenDeposit={() => setShowDepositModal(true)}
          onOpenWithdraw={() => setShowWithdrawModal(true)}
        />
      )}

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onLoginSuccess={() => {
            refreshData();
            showToast('Welcome to PulseBet!');
          }}
        />
      )}

      {/* Notifications Drawer */}
      {showNotifications && (
        <NotificationDrawer
          userId={currentUser?.id}
          onClose={() => setShowNotifications(false)}
          onRefresh={refreshData}
        />
      )}

      {/* PWA Offline Indicator */}
      <OfflineIndicator />
    </div>
  );
}
