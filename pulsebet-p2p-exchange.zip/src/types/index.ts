export type Currency = 'INR' | 'USD';

export const USD_TO_INR_RATE = 85;

export const RESTRICTED_INDIAN_STATES = [
  'Assam',
  'Telangana',
  'Odisha',
  'Nagaland',
  'Sikkim',
  'Andhra Pradesh',
] as const;

export type IndianState =
  | 'Maharashtra'
  | 'Delhi'
  | 'Karnataka'
  | 'Tamil Nadu'
  | 'Uttar Pradesh'
  | 'Gujarat'
  | 'West Bengal'
  | 'Rajasthan'
  | 'Punjab'
  | 'Haryana'
  | 'Kerala'
  | 'Goa'
  | 'Madhya Pradesh'
  | 'Bihar'
  | 'Assam'
  | 'Telangana'
  | 'Odisha'
  | 'Nagaland'
  | 'Sikkim'
  | 'Andhra Pradesh'
  | 'Other';

export type MarketCategory =
  | 'All'
  | 'Cricket'
  | 'Politics'
  | 'News'
  | 'Crypto'
  | 'Tech'
  | 'Cinema'
  | 'Finance'
  | 'Others';

export type UserRole = 'user' | 'admin';

export interface UserKYC {
  legalName: string;
  panNumber: string;
  state: IndianState;
  city: string;
  dob: string;
  phone: string;
  upiHandle: string;
  bankAccount: string;
  ifscCode: string;
  isVerified: boolean;
}

export interface User {
  id: string;
  email: string;
  displayName: string;
  avatarUrl: string;
  role: UserRole;
  isAdmin: boolean;
  realBalance: number; // Deposit & winnings balance (withdrawable)
  promoBalance: number; // ₹50 Sign-up bonus / Virtual promo credit (tradeable only)
  referralCode: string;
  referredBy?: string;
  hasMadeFirstTrade?: boolean;
  isBlocked?: boolean;
  kycStage?: 'Stage 1' | 'Stage 2';
  detectedState?: IndianState; // Auto-detected or verified resident Indian State
  password?: string; // Encrypted/hashed password
  phone?: string; // Registered mobile number
  withdrawalPin?: string; // 4-digit security PIN for withdrawals
  isEmailVerified?: boolean; // Simulated Gmail OTP verified
  kyc: UserKYC;
  createdAt: string;
}

export type BetSide = 'YES' | 'NO';

export interface MarketBet {
  id: string;
  marketId: string;
  userId: string;
  userDisplayName: string;
  side: BetSide;
  amount: number;
  realAmount: number;
  promoAmount: number;
  timestamp: string;
  oddsAtBet: number; // Probability percentage at bet time
  status: 'ACTIVE' | 'WON' | 'LOST' | 'CASHED_OUT' | 'REFUNDED' | 'UNMATCHED_REFUND';
  cashoutAmount?: number;
  payoutAmount?: number;
}

export interface Market {
  id: string;
  title: string;
  description: string;
  category: MarketCategory;
  creatorId: string;
  creatorName: string;
  creatorAvatar?: string;
  isOfficialAdmin: boolean; // true = Official Admin Market, false = Created by User
  isPrivate: boolean; // true = invite link / room code only
  isPublic?: boolean; // false = private market, omitted from public feeds
  visibility?: 'public' | 'private'; // 'private' = strictly omitted from public feeds
  roomCode?: string; // e.g. GOA26
  
  // Option Meanings
  yesMeaning?: string; // Under BUY YES button
  noMeaning?: string; // Under BUY NO button
  initialSharePrice?: number; // e.g. 5.0 (out of 10)
  resolutionProofSource?: string; // e.g. official proof link/source

  // Parimutuel Pools
  yesPool: number;
  noPool: number;
  totalVolume: number;
  targetPool?: number;
  
  // Overrides & Custom Fees
  customHouseFee?: number; // Optional override %
  customCreatorRoyalty?: number; // Optional override %
  
  // Dates & Status
  createdAt: string;
  resolvesAt: string;
  status: 'OPEN' | 'CLOSED' | 'RESOLVED_YES' | 'RESOLVED_NO' | 'RESOLVED' | 'CANCELLED';
  winningOption?: 'YES' | 'NO';
  resolvedAt?: string;
  cancellationReason?: string;
}

export type TransactionType =
  | 'DEPOSIT'
  | 'WITHDRAWAL'
  | 'TRADE_BUY'
  | 'TRADE_WIN'
  | 'TRADE_CASHOUT'
  | 'TRADE_REFUND'
  | 'UNMATCHED_REFUND'
  | 'CREATOR_ROYALTY'
  | 'ROOM_ROYALTY_PAYOUT'
  | 'WINNING_PAYOUT'
  | 'REFERRAL_BONUS'
  | 'RETENTION_BONUS'
  | 'SIGNUP_PROMO'
  | 'ADMIN_ADJUSTMENT';

export type TransactionStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  status: TransactionStatus;
  balanceType: 'REAL' | 'PROMO' | 'COMBINED';
  marketId?: string;
  marketTitle?: string;
  utrNumber?: string;
  upiId?: string;
  bankDetails?: string;
  rejectionReason?: string;
  timestamp: string;
  notes?: string;
}

export interface PendingDepositItem {
  id: string;
  transactionId: string;
  userId: string;
  userName: string;
  userEmail: string;
  amount: number;
  utrNumber: string;
  upiId?: string;
  timestamp: string;
  status: 'PENDING' | 'COMPLETED' | 'APPROVED' | 'REJECTED';
  paymentMethod?: string;
  notes?: string;
}

export interface PendingWithdrawalItem {
  id: string;
  transactionId: string;
  userId: string;
  userName: string;
  userEmail: string;
  amount: number;
  bankDetails: string;
  timestamp: string;
  status: 'PENDING' | 'COMPLETED' | 'APPROVED' | 'REJECTED';
  rejectionReason?: string;
  notes?: string;
}

export interface SystemConfig {
  adaptiveFeeMode: 'AUTOMATIC' | 'MANUAL';
  globalHouseFeePercent: number; // default 10%
  globalCreatorRoyaltyPercent: number; // default 15%
  minTradeAmount: number; // 10
  minDepositAmount: number; // 100
  minWithdrawalAmount: number; // 200
  principalGuaranteeMultiplier: number; // 1.01
}

export interface ReferralSettings {
  isEnabled: boolean;
  referrerReward: number; // default 25
  refereeWelcomeBonus: number; // default 50 Promo Cash
}

export interface SystemNotification {
  id: string;
  userId: string; // 'ALL' or specific user ID
  title: string;
  message: string;
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ALERT';
  timestamp: string;
  read: boolean;
}

export type TargetCustomerSegment =
  | 'All Users'
  | 'Active Traders'
  | 'Inactive Users'
  | 'Cricket Category'
  | 'Politics Category'
  | 'Crypto Category';

export interface BroadcastMessage {
  id: string;
  segment: TargetCustomerSegment;
  headline: string;
  deepLinkId?: string;
  message: string;
  timestamp: string;
  sentBy: string;
  recipientCount: number;
}
