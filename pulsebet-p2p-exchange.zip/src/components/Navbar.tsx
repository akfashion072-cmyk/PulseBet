import React, { useState } from 'react';
import {
  TrendingUp,
  PlusCircle,
  Wallet,
  ShieldAlert,
  LogOut,
  User as UserIcon,
  Bell,
  ChevronDown,
  DollarSign,
  IndianRupee,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { Currency, User } from '../types';
import { storageService } from '../services/storageService';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  currentUser: User | null;
  currency: Currency;
  onCurrencyToggle: () => void;
  onRefreshData: () => void;
  isRefreshing?: boolean;
  onLogout: () => void;
  activeTab: 'markets' | 'create-room' | 'wallet' | 'admin';
  onTabChange: (tab: 'markets' | 'create-room' | 'wallet' | 'admin') => void;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenDeposit: () => void;
  onOpenNotifications: () => void;
  unreadNotificationsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  currency,
  onCurrencyToggle,
  onRefreshData,
  isRefreshing = false,
  onLogout,
  activeTab,
  onTabChange,
  onOpenAuth,
  onOpenProfile,
  onOpenDeposit,
  onOpenNotifications,
  unreadNotificationsCount,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const handleLogout = () => {
    storageService.logoutUser();
    setDropdownOpen(false);
    onLogout();
  };

  const totalBalance = currentUser ? currentUser.realBalance + currentUser.promoBalance : 0;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#0B0F17]/85 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
        {/* Brand / Logo */}
        <div
          onClick={() => onTabChange('markets')}
          className="flex items-center gap-2.5 cursor-pointer group shrink-0"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#00F2FE] to-[#10B981] p-0.5 shadow-[0_0_20px_rgba(0,242,254,0.4)] group-hover:shadow-[0_0_25px_rgba(0,242,254,0.6)] transition">
            <div className="w-full h-full bg-[#0B0F17] rounded-[10px] flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-[#00F2FE]" />
            </div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1">
              <span className="font-black text-lg tracking-wider text-white">
                PULSE<span className="text-[#00F2FE]">BET</span>
              </span>
              <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-[#10B981]/20 text-[#10B981] font-bold tracking-wider border border-[#10B981]/30">
                P2P
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-medium hidden sm:inline">
              Adaptive Prediction Exchange
            </span>
          </div>
        </div>

        {/* 3 Core Customer Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1 bg-[#111827]/80 p-1 rounded-xl border border-white/5">
          <button
            onClick={() => onTabChange('markets')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'markets'
                ? 'bg-gradient-to-r from-[#00F2FE]/20 to-[#00F2FE]/10 text-[#00F2FE] border border-[#00F2FE]/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>P2P Markets</span>
          </button>

          <button
            onClick={() => onTabChange('create-room')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'create-room'
                ? 'bg-gradient-to-r from-[#10B981]/20 to-[#10B981]/10 text-[#10B981] border border-[#10B981]/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create Friend Room</span>
            <span className="text-[9px] bg-[#F59E0B]/20 text-[#F59E0B] px-1 rounded font-bold">
              15% Royalty
            </span>
          </button>

          <button
            onClick={() => onTabChange('wallet')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'wallet'
                ? 'bg-gradient-to-r from-[#F59E0B]/20 to-[#F59E0B]/10 text-[#F59E0B] border border-[#F59E0B]/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>Wallet & Ledger</span>
          </button>

          {/* Role-Based Admin Guard: Render ONLY when currentUser.isAdmin === true or role === 'admin' */}
          {currentUser && (currentUser.isAdmin || currentUser.role === 'admin') && (
            <button
              onClick={() => onTabChange('admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeTab === 'admin'
                  ? 'bg-red-500/25 text-red-400 border border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.4)]'
                  : 'text-red-400/80 hover:text-red-300 hover:bg-red-500/10 border border-red-500/20'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
              <span>Admin Hub</span>
            </button>
          )}
        </nav>

        {/* Right Section: In-App Refresh, Currency Toggle, PWA, Notifications, User Auth */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Global In-App Refresh Button */}
          <button
            onClick={onRefreshData}
            disabled={isRefreshing}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#111827] border border-white/10 text-xs font-semibold text-slate-300 hover:text-white hover:border-[#00F2FE]/40 transition disabled:opacity-80 active:scale-95 group shadow-sm"
            title="Refresh Live Markets & Wallet Balances"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 text-[#00F2FE] group-hover:text-white transition-colors ${
                isRefreshing ? 'animate-spin' : ''
              }`}
            />
            <span className="hidden sm:inline font-bold">Refresh</span>
          </button>

          {/* Multi-Currency Toggle */}
          <button
            onClick={onCurrencyToggle}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#111827] border border-white/10 text-xs font-semibold text-slate-300 hover:text-white hover:border-[#00F2FE]/40 transition"
            title={`Switch Currency (Current: ${currency})`}
          >
            {currency === 'INR' ? (
              <>
                <IndianRupee className="w-3.5 h-3.5 text-[#10B981]" />
                <span>INR</span>
              </>
            ) : (
              <>
                <DollarSign className="w-3.5 h-3.5 text-[#00F2FE]" />
                <span>USD</span>
              </>
            )}
          </button>

          {/* PWA Install Button */}
          <PWAInstallButton />

          {/* Notifications Button */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-lg bg-[#111827] border border-white/10 text-slate-300 hover:text-white transition"
            title="Notifications & Activity"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Guest Mode: Prominent [Sign In / Register] */}
          {!currentUser ? (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-extrabold text-xs shadow-[0_0_20px_rgba(0,242,254,0.3)] hover:shadow-[0_0_25px_rgba(0,242,254,0.5)] transition transform hover:scale-[1.02] active:scale-[0.98]"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Sign In / Register</span>
            </button>
          ) : (
            /* Logged-In Mode: Avatar, Live Balance, Dropdown */
            <div className="relative">
              <div className="flex items-center gap-2">
                {/* Balance Pill with Quick Deposit */}
                <div
                  onClick={() => onTabChange('wallet')}
                  className="cursor-pointer group flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#111827] border border-white/10 hover:border-[#10B981]/50 transition"
                  title={`Real: ${storageService.formatAmount(currentUser.realBalance, currency)} | Promo: ${storageService.formatAmount(currentUser.promoBalance, currency)}`}
                >
                  <div className="w-2 h-2 rounded-full bg-[#10B981] animate-ping" />
                  <div className="flex flex-col text-right">
                    <span className="text-[10px] text-slate-400 font-medium leading-none">Wallet</span>
                    <span className="text-xs font-bold text-white group-hover:text-[#10B981] transition leading-tight">
                      {storageService.formatAmount(totalBalance, currency)}
                    </span>
                  </div>
                </div>

                <button
                  onClick={onOpenDeposit}
                  className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#10B981]/20 border border-[#10B981]/40 text-[#10B981] hover:bg-[#10B981]/30 transition text-xs font-bold"
                  title="Add Funds (Min ₹100)"
                >
                  <span>+ Add</span>
                </button>

                {/* User Menu Trigger */}
                <button
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                  className="flex items-center gap-1.5 p-1 rounded-xl bg-[#111827] border border-white/10 hover:border-white/20 transition"
                >
                  <img
                    src={currentUser.avatarUrl}
                    alt={currentUser.displayName}
                    className="w-7 h-7 rounded-lg object-cover border border-white/10"
                  />
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>
              </div>

              {/* User Dropdown Menu */}
              {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-[#0F172A] border border-white/15 p-2 shadow-2xl backdrop-blur-2xl z-50">
                  <div className="p-3 border-b border-white/5">
                    <div className="flex items-center gap-2">
                      <img
                        src={currentUser.avatarUrl}
                        alt={currentUser.displayName}
                        className="w-8 h-8 rounded-lg"
                      />
                      <div className="overflow-hidden">
                        <p className="text-xs font-bold text-white truncate">
                          {currentUser.displayName}
                        </p>
                        <p className="text-[10px] text-slate-400 truncate">{currentUser.email}</p>
                      </div>
                    </div>
                    {currentUser.isAdmin && (
                      <div className="mt-2 inline-flex items-center gap-1 px-2 py-0.5 rounded bg-red-500/20 text-red-400 text-[10px] font-bold border border-red-500/30">
                        <ShieldAlert className="w-3 h-3" />
                        <span>Administrator Privileges</span>
                      </div>
                    )}
                  </div>

                  {/* Balance Breakdown */}
                  <div className="p-2.5 my-1 bg-[#0B0F17] rounded-xl border border-white/5 space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-400">Real Cash (Withdrawable):</span>
                      <span className="font-bold text-white">
                        {storageService.formatAmount(currentUser.realBalance, currency)}
                      </span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="text-[#00F2FE]">Promo Bonus (Trade-Only):</span>
                      <span className="font-bold text-[#00F2FE]">
                        {storageService.formatAmount(currentUser.promoBalance, currency)}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1 pt-1">
                    <button
                      onClick={() => {
                        onOpenProfile();
                        setDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-slate-200 hover:bg-white/5 transition"
                    >
                      <UserIcon className="w-4 h-4 text-[#00F2FE]" />
                      <span>My Profile & Trades</span>
                    </button>

                    <button
                      onClick={() => {
                        onTabChange('wallet');
                        setDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-slate-200 hover:bg-white/5 transition"
                    >
                      <Wallet className="w-4 h-4 text-[#10B981]" />
                      <span>Wallet & Ledger</span>
                    </button>

                    {currentUser.isAdmin && (
                      <button
                        onClick={() => {
                          onTabChange('admin');
                          setDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold text-red-400 hover:bg-red-500/10 transition"
                      >
                        <ShieldAlert className="w-4 h-4 text-red-400" />
                        <span>Admin Dashboard</span>
                      </button>
                    )}

                    <div className="border-t border-white/5 pt-1 mt-1">
                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold text-rose-400 hover:bg-rose-500/10 transition"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Log Out</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Mobile Tab Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-white/5 bg-[#0B0F17] py-2 px-2">
        <button
          onClick={() => onTabChange('markets')}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${
            activeTab === 'markets' ? 'text-[#00F2FE]' : 'text-slate-400'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Markets</span>
        </button>

        <button
          onClick={() => onTabChange('create-room')}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${
            activeTab === 'create-room' ? 'text-[#10B981]' : 'text-slate-400'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          <span>Friend Room</span>
        </button>

        <button
          onClick={() => onTabChange('wallet')}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${
            activeTab === 'wallet' ? 'text-[#F59E0B]' : 'text-slate-400'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Wallet</span>
        </button>

        {currentUser?.isAdmin && (
          <button
            onClick={() => onTabChange('admin')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
              activeTab === 'admin' ? 'text-red-400' : 'text-red-400/70'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Admin</span>
          </button>
        )}
      </div>
    </header>
  );
};
