import React, { useState, useMemo, useEffect } from 'react';
import {
  ShieldAlert,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Trash2,
  Gift,
  DollarSign,
  PlusCircle,
  Search,
  Send,
  Radio,
  UserCheck,
  KeyRound,
  Lock,
} from 'lucide-react';
import {
  Currency,
  Market,
  MarketCategory,
  PendingDepositItem,
  PendingWithdrawalItem,
  TargetCustomerSegment,
  Transaction,
  User,
} from '../types';
import { storageService } from '../services/storageService';

interface SuperAdminDashboardProps {
  currentUser: User | null;
  currency: Currency;
  onClose: () => void;
  onRefresh: () => void;
}

export const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({
  currentUser,
  currency,
  onClose,
  onRefresh,
}) => {
  // 6 Operational Hubs State
  const [activeHub, setActiveHub] = useState<
    'overview' | 'markets' | 'financials' | 'users' | 'broadcast' | 'settings'
  >('overview');

  // Deletion Modal State
  const [deletingMarket, setDeletingMarket] = useState<Market | null>(null);
  const [deletionReason, setDeletionReason] = useState(
    'Regulatory administrative cancellation & 100% full escrow refund.'
  );

  // User Balance Adjustment Modal State (Hub 4)
  const [adjustingUser, setAdjustingUser] = useState<User | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<number>(100);
  const [adjustType, setAdjustType] = useState<'CREDIT' | 'DEBIT'>('CREDIT');
  const [adjustReason, setAdjustReason] = useState('Promotional courtesy credit');

  // Admin Market Creation Protocol Modal State (Hub 2)
  const [showCreateMarketModal, setShowCreateMarketModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<MarketCategory>('Cricket');
  const [newYesMeaning, setNewYesMeaning] = useState('');
  const [newNoMeaning, setNewNoMeaning] = useState('');
  const [newSharePrice, setNewSharePrice] = useState<number>(5.0);
  const [newTargetPool, setNewTargetPool] = useState<number>(50000);
  const [newProofSource, setNewProofSource] = useState('');

  // Targeted Broadcast Engine State (Hub 5)
  const [selectedSegment, setSelectedSegment] = useState<TargetCustomerSegment>('All Users');
  const [broadcastHeadline, setBroadcastHeadline] = useState('');
  const [broadcastDeepLinkId, setBroadcastDeepLinkId] = useState('');
  const [broadcastBody, setBroadcastBody] = useState('');

  // Rejection Remarks Modal State (Mandatory Remarks Flow)
  const [rejectingTx, setRejectingTx] = useState<Transaction | null>(null);
  const [rejectionRemark, setRejectionRemark] = useState('');
  const [rejectionError, setRejectionError] = useState<string | null>(null);

  // Hub 4: User Search & Filter
  const [userSearchQuery, setUserSearchQuery] = useState('');

  // Referral Settings State
  const [referralReward, setReferralReward] = useState<number>(
    storageService.getReferralSettings().referrerReward
  );

  // Status Alerts
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Admin Password Change State (Hub 6)
  const [currentAdminPassword, setCurrentAdminPassword] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [confirmAdminPassword, setConfirmAdminPassword] = useState('');
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState<string | null>(null);
  const [passwordChangeError, setPasswordChangeError] = useState<string | null>(null);

  if (!currentUser?.isAdmin) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4">
        <div className="p-6 rounded-3xl bg-[#0F172A] border border-red-500/50 text-center max-w-sm">
          <ShieldAlert className="w-12 h-12 text-red-500 mx-auto mb-3" />
          <h3 className="text-lg font-black text-white">Access Denied</h3>
          <p className="text-xs text-slate-400 mt-2 mb-4">
            Admin Privileges Required to view the Super-Admin Command Center.
          </p>
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-white/10 text-white font-bold text-xs"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  const [pendingDepositsQueue, setPendingDepositsQueue] = useState<PendingDepositItem[]>(() =>
    storageService.getGlobalPendingDeposits()
  );
  const [pendingWithdrawalsQueue, setPendingWithdrawalsQueue] = useState<PendingWithdrawalItem[]>(() =>
    storageService.getGlobalPendingWithdrawals()
  );
  const [globalUsers, setGlobalUsers] = useState<User[]>(() =>
    storageService.getGlobalUsers()
  );

  // Dynamic real-time synchronization with global queue, users, and balances
  useEffect(() => {
    const handleSync = () => {
      setPendingDepositsQueue([...storageService.getGlobalPendingDeposits()]);
      setPendingWithdrawalsQueue([...storageService.getGlobalPendingWithdrawals()]);
      setGlobalUsers([...storageService.getGlobalUsers()]);
      onRefresh();
    };

    window.addEventListener('deposit_submitted', handleSync);
    window.addEventListener('pending_deposits_updated', handleSync);
    window.addEventListener('deposit_approved', handleSync);
    window.addEventListener('deposit_rejected', handleSync);
    window.addEventListener('withdrawal_submitted', handleSync);
    window.addEventListener('pending_withdrawals_updated', handleSync);
    window.addEventListener('withdrawal_approved', handleSync);
    window.addEventListener('withdrawal_rejected', handleSync);
    window.addEventListener('user_registered', handleSync);
    window.addEventListener('balance_updated', handleSync);
    window.addEventListener('storage', handleSync);

    return () => {
      window.removeEventListener('deposit_submitted', handleSync);
      window.removeEventListener('pending_deposits_updated', handleSync);
      window.removeEventListener('deposit_approved', handleSync);
      window.removeEventListener('deposit_rejected', handleSync);
      window.removeEventListener('withdrawal_submitted', handleSync);
      window.removeEventListener('pending_withdrawals_updated', handleSync);
      window.removeEventListener('withdrawal_approved', handleSync);
      window.removeEventListener('withdrawal_rejected', handleSync);
      window.removeEventListener('user_registered', handleSync);
      window.removeEventListener('balance_updated', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, [onRefresh]);

  const allTx = storageService.getTransactions();
  const pendingDeposits = pendingDepositsQueue;
  const pendingWithdrawals = pendingWithdrawalsQueue;
  const totalFinancialQueueCount = pendingDepositsQueue.length + pendingWithdrawalsQueue.length;

  const allMarkets = storageService.getMarkets();
  const allUsers = globalUsers;
  const broadcasts = storageService.getBroadcasts();
  const escrowStats = storageService.getEscrowStats();

  const notify = (msg: string) => {
    setActionSuccess(msg);
    setActionError(null);
    setTimeout(() => setActionSuccess(null), 3000);
    onRefresh();
  };

  const notifyError = (msg: string) => {
    setActionError(msg);
    setActionSuccess(null);
    setTimeout(() => setActionError(null), 4000);
  };

  // --- Handlers ---
  const handleApproveDeposit = (identifier: string) => {
    try {
      storageService.approveDeposit(identifier, currentUser.id);
      setPendingDepositsQueue([...storageService.getGlobalPendingDeposits()]);
      notify('Deposit verified & wallet credited successfully!');
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleOpenRejectModal = (tx: Transaction) => {
    setRejectingTx(tx);
    setRejectionRemark(
      tx.type === 'DEPOSIT'
        ? 'Invalid UTR reference / transaction not found in bank ledger'
        : 'Bank account details mismatch KYC name'
    );
    setRejectionError(null);
  };

  const handleOpenRejectDepositItem = (item: PendingDepositItem) => {
    setRejectingTx({
      id: item.id || item.transactionId,
      userId: item.userId,
      type: 'DEPOSIT',
      amount: item.amount,
      status: 'PENDING',
      balanceType: 'REAL',
      utrNumber: item.utrNumber,
      upiId: item.upiId,
      timestamp: item.timestamp,
      notes: item.notes,
    });
    setRejectionRemark('Invalid UTR reference / transaction not found in bank ledger');
    setRejectionError(null);
  };

  const handleOpenRejectWithdrawalItem = (item: PendingWithdrawalItem) => {
    setRejectingTx({
      id: item.id || item.transactionId,
      userId: item.userId,
      type: 'WITHDRAWAL',
      amount: item.amount,
      status: 'PENDING',
      balanceType: 'REAL',
      bankDetails: item.bankDetails,
      timestamp: item.timestamp,
      notes: item.notes,
    });
    setRejectionRemark('Bank account details mismatch KYC name');
    setRejectionError(null);
  };

  const handleConfirmRejection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectingTx) return;
    const cleanRemark = rejectionRemark.trim();
    if (!cleanRemark) {
      setRejectionError('Rejection reason / remarks string is mandatory before proceeding.');
      return;
    }
    try {
      if (rejectingTx.type === 'DEPOSIT') {
        storageService.rejectDeposit(rejectingTx.id, cleanRemark, currentUser.id);
        setPendingDepositsQueue([...storageService.getGlobalPendingDeposits()]);
        notify(`Deposit declined. Remark recorded: "${cleanRemark}"`);
      } else {
        storageService.rejectWithdrawal(rejectingTx.id, cleanRemark, currentUser.id);
        setPendingWithdrawalsQueue([...storageService.getGlobalPendingWithdrawals()]);
        notify(`Withdrawal rejected. Funds refunded to customer with remark: "${cleanRemark}"`);
      }
      setRejectingTx(null);
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleApproveWithdrawal = (identifier: string) => {
    try {
      storageService.approveWithdrawal(identifier, currentUser.id);
      setPendingWithdrawalsQueue([...storageService.getGlobalPendingWithdrawals()]);
      notify('Withdrawal approved and cleared to recipient!');
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleSettle = (marketId: string, side: 'YES' | 'NO') => {
    if (confirm(`Confirm settlement as [${side}]? Payouts execute immediately with 1.01x guarantee.`)) {
      try {
        storageService.resolveMarket(marketId, side, currentUser.id);
        notify(`Market settled as ${side}! Escrow disbursed.`);
      } catch (e: any) {
        notifyError(e.message);
      }
    }
  };

  const handleCancelAndRefund = (market: Market) => {
    setDeletingMarket(market);
  };

  const handleExecuteDeleteAndRefund = () => {
    if (!deletingMarket) return;
    try {
      storageService.deleteMarketWithEscrowRefund(
        deletingMarket.id,
        deletionReason,
        currentUser.id
      );
      setDeletingMarket(null);
      notify('Event cancelled and 100% escrow refunded to customer wallets!');
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleCreateOfficialMarket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    try {
      const initialSeedTotal = 5000;
      storageService.createMarket(
        {
          title: newTitle.trim(),
          description: `Official PulseBet Parimutuel Market. Target Pool: ₹${newTargetPool.toLocaleString('en-IN')}. Proof source: ${newProofSource || 'Official Sports / Regulatory bulletin'}.`,
          category: newCategory,
          creatorId: currentUser.id,
          creatorName: 'PulseBet Official',
          isOfficialAdmin: true,
          isPrivate: false,
          yesMeaning: newYesMeaning.trim() || 'YES Outcome Verified',
          noMeaning: newNoMeaning.trim() || 'NO Outcome / Opposite',
          initialSharePrice: newSharePrice,
          targetPool: newTargetPool,
          resolutionProofSource: newProofSource.trim() || 'Official certified public record',
          resolvesAt: new Date(Date.now() + 3 * 24 * 3600 * 1000).toISOString(),
        },
        initialSeedTotal
      );

      setShowCreateMarketModal(false);
      setNewTitle('');
      setNewYesMeaning('');
      setNewNoMeaning('');
      notify('Official market published to public feed!');
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleSaveReferralBonus = () => {
    try {
      storageService.updateReferralSettings({ referrerReward: referralReward }, currentUser.id);
      notify(`Referral bonus updated to ₹${referralReward}!`);
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleExecuteBalanceAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingUser) return;
    try {
      const delta = adjustType === 'CREDIT' ? adjustAmount : -adjustAmount;
      storageService.adjustUserBalance(adjustingUser.id, delta, adjustReason, currentUser.id);
      setAdjustingUser(null);
      notify(`Wallet balance updated for @${adjustingUser.displayName}!`);
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleToggleBlock = (user: User) => {
    try {
      storageService.toggleBlockUser(user.id, currentUser.id);
      notify(`User @${user.displayName} is now ${user.isBlocked ? 'Unblocked' : 'Blocked'}!`);
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleDispatchBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastHeadline.trim() || !broadcastBody.trim()) {
      notifyError('Please enter both headline and message body');
      return;
    }
    try {
      storageService.dispatchBroadcast(
        selectedSegment,
        broadcastHeadline.trim(),
        broadcastBody.trim(),
        broadcastDeepLinkId.trim() || undefined,
        currentUser.id
      );
      setBroadcastHeadline('');
      setBroadcastBody('');
      setBroadcastDeepLinkId('');
      notify(`Targeted Broadcast dispatched to [${selectedSegment}]!`);
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleImpersonateUser = (targetUser: User) => {
    if (!currentUser) return;
    try {
      storageService.impersonateUser(targetUser.id, currentUser.id);
      notify(`Switched context to @${targetUser.displayName}. Viewing portal as user.`);
      onRefresh();
      onClose();
    } catch (e: any) {
      notifyError(e.message);
    }
  };

  const handleChangeAdminPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordChangeSuccess(null);
    setPasswordChangeError(null);
    if (!currentUser) return;

    if (!newAdminPassword || newAdminPassword.length < 8) {
      setPasswordChangeError('New master password must be at least 8 characters long.');
      return;
    }

    if (newAdminPassword !== confirmAdminPassword) {
      setPasswordChangeError('New password confirmation does not match.');
      return;
    }

    try {
      storageService.updateAdminPassword(currentUser.id, currentAdminPassword, newAdminPassword);
      setPasswordChangeSuccess('Master Admin password successfully updated!');
      setCurrentAdminPassword('');
      setNewAdminPassword('');
      setConfirmAdminPassword('');
      notify('Master Admin password updated successfully!');
      setTimeout(() => setPasswordChangeSuccess(null), 4000);
    } catch (err: any) {
      setPasswordChangeError(err.message || 'Failed to update admin password.');
    }
  };

  // Filtered Users for Hub 4
  const filteredUsers = useMemo(() => {
    if (!userSearchQuery.trim()) return allUsers;
    const q = userSearchQuery.toLowerCase();
    return allUsers.filter(
      (u) =>
        u.displayName.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.kyc?.upiHandle?.toLowerCase().includes(q) ||
        u.kyc?.panNumber?.toLowerCase().includes(q)
    );
  }, [allUsers, userSearchQuery]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-6xl rounded-3xl bg-[#0F172A] border border-red-500/40 shadow-[0_0_60px_rgba(239,68,68,0.25)] p-5 sm:p-7 relative my-auto max-h-[94vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">Super-Admin Command Center</h2>
                <span className="text-[10px] bg-red-500 text-black px-2 py-0.5 rounded font-black uppercase">
                  5-Hub Operational Control
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Solvency Clearing • Market Adjudication • Financial Approvals • Security Suite • Broadcast Engine
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition p-1"
          >
            <XCircle className="w-6 h-6" />
          </button>
        </div>

        {/* Global Feedback Banner */}
        {actionSuccess && (
          <div className="my-2 p-3 rounded-2xl bg-[#10B981]/20 border border-[#10B981] text-xs text-[#10B981] font-bold flex items-center gap-2 animate-pulse">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{actionSuccess}</span>
          </div>
        )}
        {actionError && (
          <div className="my-2 p-3 rounded-2xl bg-red-500/20 border border-red-500 text-xs text-red-400 font-bold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{actionError}</span>
          </div>
        )}

        {/* 5-Hub Top Navigation Bar */}
        <div className="flex items-center gap-2 overflow-x-auto py-3 border-b border-white/10 shrink-0 scrollbar-none text-xs font-bold">
          <button
            onClick={() => setActiveHub('overview')}
            className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeHub === 'overview'
                ? 'bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black shadow-md font-black'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>📊 Overview & Revenue</span>
          </button>

          <button
            onClick={() => setActiveHub('markets')}
            className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeHub === 'markets'
                ? 'bg-[#00F2FE] text-black shadow-md font-black'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🎯 Market Control ({allMarkets.length})</span>
          </button>

          <button
            onClick={() => setActiveHub('financials')}
            className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeHub === 'financials'
                ? 'bg-[#F59E0B] text-black shadow-md font-black'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>💵 Financials & Bank Approvals</span>
            {totalFinancialQueueCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[10px] font-extrabold animate-pulse">
                {totalFinancialQueueCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveHub('users')}
            className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeHub === 'users'
                ? 'bg-purple-500 text-white shadow-md font-black'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>👥 User & Security Suite ({allUsers.length})</span>
          </button>

          <button
            onClick={() => setActiveHub('broadcast')}
            className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeHub === 'broadcast'
                ? 'bg-pink-500 text-white shadow-md font-black'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>📢 Targeted Broadcast Engine</span>
          </button>

          <button
            onClick={() => setActiveHub('settings')}
            className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeHub === 'settings'
                ? 'bg-rose-500 text-white shadow-md font-black'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>🛡️ Master Security & Settings</span>
          </button>
        </div>

        {/* Operational Hub Content Body */}
        <div className="overflow-y-auto py-4 flex-1 pr-1 space-y-4">
          {/* ======================================================== */}
          {/* HUB 1: OVERVIEW & REVENUE                                */}
          {/* ======================================================== */}
          {activeHub === 'overview' && (
            <div className="space-y-5">
              {/* Stat Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                    Total Traded Volume
                  </span>
                  <div className="text-xl sm:text-2xl font-black text-white">
                    {storageService.formatAmount(escrowStats.totalVolume, currency)}
                  </div>
                  <span className="text-[10px] text-[#00F2FE]">Across all public & friend rooms</span>
                </div>

                <div className="p-4 rounded-2xl bg-[#0B0F17] border border-[#10B981]/30 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-[#10B981] tracking-wider block">
                    Net 10% Platform Revenue
                  </span>
                  <div className="text-xl sm:text-2xl font-black text-[#10B981]">
                    {storageService.formatAmount(escrowStats.platformRevenue, currency)}
                  </div>
                  <span className="text-[10px] text-slate-400">10% House rake retained</span>
                </div>

                <div className="p-4 rounded-2xl bg-[#0B0F17] border border-[#F59E0B]/30 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-[#F59E0B] tracking-wider block">
                    15% Creator Royalties Paid
                  </span>
                  <div className="text-xl sm:text-2xl font-black text-[#F59E0B]">
                    {storageService.formatAmount(escrowStats.creatorRoyalties, currency)}
                  </div>
                  <span className="text-[10px] text-slate-400">Paid to viral room creators</span>
                </div>

                <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                    Active Verified Users
                  </span>
                  <div className="text-xl sm:text-2xl font-black text-white">
                    {escrowStats.activeVerifiedUsers} / {allUsers.length}
                  </div>
                  <span className="text-[10px] text-[#10B981]">KYC verified accounts</span>
                </div>
              </div>

              {/* Escrow Solvency & Automated Clearing Box */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-[#0B0F17] via-[#0F172A] to-[#111827] border border-[#10B981]/40 shadow-lg space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#10B981] animate-ping" />
                    <h3 className="text-sm font-black text-white">
                      Escrow Solvency & Automated Clearing Status
                    </h3>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-[#10B981]/20 text-[#10B981] font-bold text-xs border border-[#10B981]/30">
                    🟢 100% Solvency Ratio
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-slate-400 block text-[11px]">Total Current Escrow Locked:</span>
                    <strong className="text-base text-white">
                      {storageService.formatAmount(escrowStats.totalEscrowLocked, currency)}
                    </strong>
                    <p className="text-[10px] text-slate-500 mt-0.5">Segregated customer pool balance</p>
                  </div>

                  <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-slate-400 block text-[11px]">Active Viral Friend Rooms:</span>
                    <strong className="text-base text-[#00F2FE]">
                      {escrowStats.activeFriendRoomsCount} Rooms Live
                    </strong>
                    <p className="text-[10px] text-slate-500 mt-0.5">15% Creator Royalty active</p>
                  </div>

                  <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                    <span className="text-slate-400 block text-[11px]">Dynamic Referral Bonus Config:</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-white font-bold">₹</span>
                      <input
                        type="number"
                        value={referralReward}
                        onChange={(e) => setReferralReward(Number(e.target.value))}
                        className="w-20 bg-[#111827] border border-white/20 rounded px-2 py-0.5 text-xs text-white font-bold"
                      />
                      <button
                        onClick={handleSaveReferralBonus}
                        className="px-2 py-0.5 rounded bg-[#10B981] text-black font-bold text-[10px]"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* HUB 2: MARKET CONTROL & ADMIN CREATION PROTOCOL          */}
          {/* ======================================================== */}
          {activeHub === 'markets' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-black text-white">Market Adjudication & Creation Hub</h3>
                  <p className="text-xs text-slate-400">
                    Settle outcomes with instant parimutuel distribution or execute 100% refund cancellations.
                  </p>
                </div>

                <button
                  onClick={() => setShowCreateMarketModal(true)}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-xs flex items-center gap-1.5 shadow-md"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>+ Create New Market</span>
                </button>
              </div>

              {/* Market List Cards */}
              <div className="space-y-3">
                {allMarkets.map((m) => {
                  const isOpen = m.status === 'OPEN';
                  const isCapReached = m.targetPool ? m.totalVolume >= m.targetPool : false;

                  return (
                    <div
                      key={m.id}
                      className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 hover:border-white/20 transition space-y-3"
                    >
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
                        <div className="space-y-1 max-w-xl">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] bg-white/10 text-slate-200 px-2 py-0.5 rounded font-bold">
                              {m.category}
                            </span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                                m.isOfficialAdmin
                                  ? 'bg-[#00F2FE]/20 text-[#00F2FE]'
                                  : 'bg-[#10B981]/20 text-[#10B981]'
                              }`}
                            >
                              {m.isOfficialAdmin ? 'Official Market' : `Room by @${m.creatorName}`}
                            </span>
                            {isCapReached && (
                              <span className="text-[10px] bg-[#F59E0B]/20 text-[#F59E0B] px-2 py-0.5 rounded font-bold">
                                🎯 Pool Cap Reached
                              </span>
                            )}
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                                isOpen
                                  ? 'bg-[#10B981]/20 text-[#10B981]'
                                  : m.status === 'RESOLVED' || m.status.startsWith('RESOLVED')
                                  ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40'
                                  : 'bg-slate-700 text-slate-300'
                              }`}
                            >
                              {m.status === 'RESOLVED'
                                ? `RESOLVED (${m.winningOption || 'SETTLED'})`
                                : m.status}
                            </span>
                          </div>

                          <h4 className="text-sm font-extrabold text-white leading-snug">{m.title}</h4>

                          {/* YES/NO Sub-Meanings */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-[11px]">
                            <div className="bg-[#111827] px-2.5 py-1 rounded-lg border border-white/5">
                              <span className="text-[#00F2FE] font-bold">YES: </span>
                              <span className="text-slate-300">{m.yesMeaning || 'Yes condition met'}</span>
                            </div>
                            <div className="bg-[#111827] px-2.5 py-1 rounded-lg border border-white/5">
                              <span className="text-rose-400 font-bold">NO: </span>
                              <span className="text-slate-300">{m.noMeaning || 'No / Opposite outcome'}</span>
                            </div>
                          </div>
                        </div>

                        {/* Pooled Volume Counters & Target */}
                        <div className="text-right shrink-0">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                            Pooled Volume
                          </span>
                          <span className="text-base font-black text-white">
                            {storageService.formatAmount(m.totalVolume, currency)}
                          </span>
                          {m.targetPool && (
                            <span className="text-[10px] text-slate-500 block">
                              Target: {storageService.formatAmount(m.targetPool, currency)}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Adjudicate Action Buttons */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/5">
                        <div className="text-[11px] text-slate-400">
                          Proof: <span className="text-slate-300">{m.resolutionProofSource || 'Official verified records'}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          {isOpen && (
                            <>
                              <button
                                onClick={() => handleSettle(m.id, 'YES')}
                                className="px-3 py-1.5 rounded-xl bg-[#00F2FE]/20 hover:bg-[#00F2FE] text-[#00F2FE] hover:text-black font-extrabold text-xs transition border border-[#00F2FE]/40"
                              >
                                Settle YES
                              </button>
                              <button
                                onClick={() => handleSettle(m.id, 'NO')}
                                className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500 text-rose-400 hover:text-white font-extrabold text-xs transition border border-rose-500/40"
                              >
                                Settle NO
                              </button>
                              <button
                                onClick={() => handleCancelAndRefund(m)}
                                className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-black font-bold text-xs transition border border-amber-500/40"
                              >
                                Cancel Event & 100% Auto-Refund
                              </button>
                            </>
                          )}

                          {m.status !== 'CANCELLED' && (
                            <button
                              onClick={() => setDeletingMarket(m)}
                              className="p-2 rounded-xl bg-red-500/15 hover:bg-red-500 text-red-400 hover:text-white transition border border-red-500/30 text-xs font-bold flex items-center gap-1"
                              title="Delete Market with Escrow Refund"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Delete</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* HUB 3: FINANCIALS & BANK APPROVALS QUEUE                 */}
          {/* ======================================================== */}
          {activeHub === 'financials' && (
            <div className="space-y-6">
              {/* Pending Withdrawals Queue */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-[#F59E0B]" />
                    <h4 className="text-sm font-black text-white">Pending Customer Withdrawals</h4>
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    {pendingWithdrawals.length} Queued
                  </span>
                </div>

                {pendingWithdrawals.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500 bg-[#0B0F17] rounded-2xl border border-white/5">
                    No withdrawals pending in queue. All accounts settled.
                  </div>
                ) : (
                  pendingWithdrawals.map((item) => {
                    const user = allUsers.find((u) => u.id === item.userId);
                    const displayName = item.userName || user?.displayName || 'User';
                    const userEmail = item.userEmail || user?.email || '';
                    return (
                      <div
                        key={item.id}
                        className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-sm text-[#F59E0B]">
                              {storageService.formatAmount(item.amount, currency)}
                            </span>
                            <span className="text-[10px] bg-[#F59E0B]/20 text-[#F59E0B] px-2 py-0.5 rounded font-bold">
                              WITHDRAWAL_QUEUED
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {new Date(item.timestamp).toLocaleTimeString()}
                            </span>
                          </div>

                          <p className="text-xs text-slate-300">
                            Customer: <strong className="text-white">{displayName}</strong> {userEmail ? `(${userEmail})` : ''}
                          </p>
                          <p className="text-xs text-slate-400">
                            Payout Rail / UPI: <code className="text-[#00F2FE]">{item.bankDetails || user?.kyc.upiHandle || 'Direct UPI'}</code>
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleApproveWithdrawal(item.id || item.transactionId)}
                            className="px-4 py-2 rounded-xl bg-[#10B981] hover:bg-[#059669] text-black font-extrabold text-xs transition"
                          >
                            Approve & Mark Sent
                          </button>
                          <button
                            onClick={() => handleOpenRejectWithdrawalItem(item)}
                            className="px-3 py-2 rounded-xl bg-red-500/20 hover:bg-red-500 text-red-400 hover:text-white font-bold text-xs transition border border-red-500/40"
                          >
                            Reject & Refund
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Manual Deposit Verification Queue */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#10B981]" />
                    <h4 className="text-sm font-black text-white">Manual Deposit Verification Queue</h4>
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    {pendingDepositsQueue.length} Pending
                  </span>
                </div>

                {pendingDepositsQueue.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500 bg-[#0B0F17] rounded-2xl border border-white/5">
                    No manual deposits pending audit. All UTRs verified!
                  </div>
                ) : (
                  pendingDepositsQueue.map((item) => {
                    const user = allUsers.find((u) => u.id === item.userId);
                    const displayName = item.userName || user?.displayName || 'User';
                    const userEmail = item.userEmail || user?.email || '';
                    return (
                      <div
                        key={item.id}
                        className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-sm text-[#10B981]">
                              +{storageService.formatAmount(item.amount, currency)}
                            </span>
                            <span className="text-[10px] bg-[#10B981]/20 text-[#10B981] px-2 py-0.5 rounded font-bold">
                              PENDING_APPROVAL
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {new Date(item.timestamp).toLocaleTimeString()}
                            </span>
                          </div>

                          <p className="text-xs text-slate-300">
                            Depositor: <strong className="text-white">{displayName}</strong> {userEmail ? `(${userEmail})` : ''}
                          </p>
                          <div className="text-xs text-slate-300 flex items-center gap-2">
                            <span>UTR / Ref Number:</span>
                            <code className="bg-[#111827] px-2 py-0.5 rounded text-[#00F2FE] font-bold tracking-wider">
                              {item.utrNumber}
                            </code>
                          </div>
                          {item.paymentMethod && (
                            <p className="text-[11px] text-slate-400">
                              Payment Method: <span className="text-slate-200">{item.paymentMethod}</span>
                            </p>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleApproveDeposit(item.id || item.transactionId)}
                            className="px-4 py-2 rounded-xl bg-[#10B981] hover:bg-[#059669] text-black font-extrabold text-xs transition shadow-sm"
                          >
                            Approve Deposit
                          </button>
                          <button
                            onClick={() => handleOpenRejectDepositItem(item)}
                            className="px-3 py-2 rounded-xl bg-red-500/20 hover:bg-red-500 text-red-400 hover:text-white font-bold text-xs transition border border-red-500/40"
                          >
                            Decline
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* HUB 4: USER & SECURITY SUITE                             */}
          {/* ======================================================== */}
          {activeHub === 'users' && (
            <div className="space-y-4">
              {/* Search Bar & Referral Config Box */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder="Search users by name, email, PAN, or UPI..."
                    className="w-full bg-[#111827] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00F2FE]"
                  />
                </div>

                <div className="flex items-center gap-2 bg-[#0B0F17] p-2 rounded-xl border border-white/10 text-xs">
                  <Gift className="w-3.5 h-3.5 text-[#F59E0B]" />
                  <span className="text-slate-400">Referral Credit:</span>
                  <input
                    type="number"
                    value={referralReward}
                    onChange={(e) => setReferralReward(Number(e.target.value))}
                    className="w-16 bg-[#111827] border border-white/20 rounded px-2 py-0.5 text-xs text-white font-bold"
                  />
                  <button
                    onClick={handleSaveReferralBonus}
                    className="px-2.5 py-1 rounded bg-[#F59E0B] text-black font-bold text-[10px]"
                  >
                    Save
                  </button>
                </div>
              </div>

              {/* User Table */}
              <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#0B0F17]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#111827] text-slate-400 uppercase text-[10px] tracking-wider border-b border-white/5">
                    <tr>
                      <th className="p-3">User Profile</th>
                      <th className="p-3">KYC Status</th>
                      <th className="p-3">Wallet Balances</th>
                      <th className="p-3">Payment Rails</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {filteredUsers.map((u) => {
                      const isKycVerified = u.kyc?.isVerified || u.isAdmin;
                      const kycBadge = isKycVerified ? 'Stage 2 Verified' : 'Stage 1 Unverified';

                      return (
                        <tr key={u.id} className="hover:bg-white/5 transition">
                          <td className="p-3">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={u.avatarUrl}
                                alt={u.displayName}
                                className="w-8 h-8 rounded-lg object-cover"
                              />
                              <div>
                                <div className="flex items-center gap-1.5 font-bold text-white">
                                  <span>{u.displayName}</span>
                                  {u.isBlocked && (
                                    <span className="text-[9px] bg-red-500/20 text-red-400 px-1.5 rounded font-bold">
                                      BLOCKED
                                    </span>
                                  )}
                                  {u.isAdmin && (
                                    <span className="text-[9px] bg-red-500 text-black px-1.5 rounded font-bold">
                                      ADMIN
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-slate-400">{u.email}</span>
                              </div>
                            </div>
                          </td>

                          <td className="p-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                isKycVerified
                                  ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/30'
                                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              }`}
                            >
                              {kycBadge}
                            </span>
                            <span className="block text-[10px] text-slate-500 mt-0.5">
                              State: {u.kyc?.state || 'Not Set'}
                            </span>
                          </td>

                          <td className="p-3">
                            <div className="font-bold text-white">
                              Real: <span className="text-[#10B981]">₹{u.realBalance}</span>
                            </div>
                            <span className="text-[10px] text-[#00F2FE]">
                              Promo: ₹{u.promoBalance}
                            </span>
                          </td>

                          <td className="p-3">
                            <span className="font-mono text-[11px] text-slate-300 block">
                              {u.kyc?.upiHandle || 'No UPI'}
                            </span>
                            <span className="font-mono text-[10px] text-slate-500">
                              PAN: {u.kyc?.panNumber || 'Not submitted'}
                            </span>
                          </td>

                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Adjust Balance Button */}
                              <button
                                onClick={() => setAdjustingUser(u)}
                                className="px-2.5 py-1 rounded-lg bg-[#00F2FE]/15 hover:bg-[#00F2FE] text-[#00F2FE] hover:text-black font-bold text-xs transition"
                              >
                                Adjust ₹
                              </button>

                              {/* Impersonate / Login As User */}
                              {!u.isAdmin && (
                                <button
                                  onClick={() => handleImpersonateUser(u)}
                                  className="px-2.5 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500 text-purple-300 hover:text-black font-bold text-xs transition flex items-center gap-1"
                                  title={`Switch context to view portal as @${u.displayName}`}
                                >
                                  <UserCheck className="w-3 h-3" />
                                  <span>Login As</span>
                                </button>
                              )}

                              {/* Block / Unblock Toggle */}
                              {!u.isAdmin && (
                                <button
                                  onClick={() => handleToggleBlock(u)}
                                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                                    u.isBlocked
                                      ? 'bg-[#10B981]/20 hover:bg-[#10B981] text-[#10B981] hover:text-black'
                                      : 'bg-red-500/20 hover:bg-red-500 text-red-400 hover:text-white'
                                  }`}
                                >
                                  {u.isBlocked ? 'Unblock' : 'Block'}
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* HUB 5: TARGETED BROADCAST ENGINE                         */}
          {/* ======================================================== */}
          {activeHub === 'broadcast' && (
            <div className="space-y-5">
              <div className="p-5 rounded-3xl bg-[#0B0F17] border border-white/10 space-y-4">
                <div className="flex items-center gap-2">
                  <Radio className="w-5 h-5 text-pink-400 animate-pulse" />
                  <div>
                    <h4 className="text-sm font-black text-white">Targeted Broadcast Dispatcher</h4>
                    <p className="text-xs text-slate-400">
                      Push real-time in-app alert notifications to specific customer segments
                    </p>
                  </div>
                </div>

                <form onSubmit={handleDispatchBroadcast} className="space-y-4">
                  {/* Segment Chips */}
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                      Target Customer Segment:
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {(
                        [
                          'All Users',
                          'Active Traders',
                          'Inactive Users',
                          'Cricket Category',
                          'Politics Category',
                          'Crypto Category',
                        ] as TargetCustomerSegment[]
                      ).map((seg) => (
                        <button
                          key={seg}
                          type="button"
                          onClick={() => setSelectedSegment(seg)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
                            selectedSegment === seg
                              ? 'bg-pink-500/20 border-pink-500 text-pink-300'
                              : 'bg-[#111827] border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          {seg}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Headline & Deep-Link */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">
                        Alert Headline / Title:
                      </label>
                      <input
                        type="text"
                        value={broadcastHeadline}
                        onChange={(e) => setBroadcastHeadline(e.target.value)}
                        placeholder="e.g. 🏏 Champions Trophy Final Odds Spiking!"
                        className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-none focus:border-pink-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">
                        Deep-Link Contract ID (Optional):
                      </label>
                      <input
                        type="text"
                        value={broadcastDeepLinkId}
                        onChange={(e) => setBroadcastDeepLinkId(e.target.value)}
                        placeholder="e.g. mkt-ipl-2026 or room-goa-trip"
                        className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs font-mono focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>

                  {/* Message Body */}
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Message Body:
                    </label>
                    <textarea
                      value={broadcastBody}
                      onChange={(e) => setBroadcastBody(e.target.value)}
                      rows={3}
                      placeholder="Enter the alert message delivered directly to the user's notification drawer..."
                      className="w-full bg-[#111827] border border-white/15 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-pink-500"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-500 to-purple-600 text-white font-black text-xs shadow-md hover:opacity-95 transition flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>📢 Dispatch Targeted Broadcast</span>
                  </button>
                </form>
              </div>

              {/* Sent Broadcast History Audit Log */}
              <div className="space-y-3">
                <h5 className="text-xs font-extrabold text-white">Sent Broadcast History Audit Log</h5>
                {broadcasts.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500 bg-[#0B0F17] rounded-2xl border border-white/5">
                    No broadcasts sent yet.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {broadcasts.map((bc) => (
                      <div
                        key={bc.id}
                        className="p-3.5 rounded-2xl bg-[#0B0F17] border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white">{bc.headline}</span>
                            <span className="text-[10px] bg-pink-500/20 text-pink-400 px-2 py-0.5 rounded font-bold">
                              {bc.segment}
                            </span>
                            {bc.deepLinkId && (
                              <span className="text-[10px] bg-white/5 text-slate-300 px-2 py-0.5 rounded font-mono">
                                ➔ #{bc.deepLinkId}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-300">{bc.message}</p>
                        </div>

                        <div className="text-right shrink-0 text-[10px] text-slate-500">
                          <div>Dispatched to ~{bc.recipientCount} users</div>
                          <div>{new Date(bc.timestamp).toLocaleTimeString()}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* HUB 6: MASTER SECURITY & ADMIN SETTINGS                  */}
          {/* ======================================================== */}
          {activeHub === 'settings' && (
            <div className="space-y-6">
              {/* Security & Password Form Card */}
              <div className="p-6 rounded-3xl bg-[#0B0F17] border border-white/10 space-y-5">
                <div className="flex items-center gap-3 pb-3 border-b border-white/10">
                  <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                    <KeyRound className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white">Master Admin Password & Credentials</h4>
                    <p className="text-xs text-slate-400">
                      Update the primary root credentials for the Super-Administrator command authority
                    </p>
                  </div>
                </div>

                {passwordChangeSuccess && (
                  <div className="p-3.5 rounded-2xl bg-[#10B981]/20 border border-[#10B981] text-xs text-[#10B981] flex items-center gap-2 font-bold animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{passwordChangeSuccess}</span>
                  </div>
                )}

                {passwordChangeError && (
                  <div className="p-3.5 rounded-2xl bg-red-500/15 border border-red-500/40 text-xs text-red-400 flex items-center gap-2 font-medium animate-in fade-in">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{passwordChangeError}</span>
                  </div>
                )}

                <form onSubmit={handleChangeAdminPassword} className="space-y-4 max-w-xl">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Current Master Password:
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="password"
                        value={currentAdminPassword}
                        onChange={(e) => {
                          setCurrentAdminPassword(e.target.value);
                          setPasswordChangeError(null);
                        }}
                        placeholder="Enter current password (default: Admin@123)"
                        className="w-full bg-[#111827] border border-white/15 rounded-xl pl-10 pr-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-rose-500/60 transition"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">
                        New Master Password:
                      </label>
                      <input
                        type="password"
                        value={newAdminPassword}
                        onChange={(e) => {
                          setNewAdminPassword(e.target.value);
                          setPasswordChangeError(null);
                        }}
                        placeholder="Min 8 characters"
                        className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-rose-500/60 transition"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">
                        Confirm New Password:
                      </label>
                      <input
                        type="password"
                        value={confirmAdminPassword}
                        onChange={(e) => {
                          setConfirmAdminPassword(e.target.value);
                          setPasswordChangeError(null);
                        }}
                        placeholder="Re-enter new password"
                        className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-rose-500/60 transition"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="py-3 px-6 rounded-2xl bg-gradient-to-r from-rose-500 to-red-600 hover:opacity-95 text-white font-extrabold text-xs shadow-[0_0_20px_rgba(244,63,94,0.3)] transition flex items-center justify-center gap-2"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>Save Master Admin Password</span>
                  </button>
                </form>
              </div>

              {/* Admin Authority Details */}
              <div className="p-6 rounded-3xl bg-[#0B0F17] border border-white/10 space-y-4">
                <h5 className="text-xs font-extrabold text-white uppercase tracking-wider">
                  Active Session Authority & Scope
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-[#111827] border border-white/5 space-y-1">
                    <span className="text-slate-400 text-[10px] uppercase font-bold block">Administrator</span>
                    <span className="font-bold text-white">{currentUser.displayName}</span>
                    <span className="text-[11px] text-slate-500 block">{currentUser.email}</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#111827] border border-white/5 space-y-1">
                    <span className="text-slate-400 text-[10px] uppercase font-bold block">Authority Tier</span>
                    <span className="font-bold text-[#10B981]">Root Super-Administrator</span>
                    <span className="text-[11px] text-slate-500 block">Full Liquidity & Settlement Control</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#111827] border border-white/5 space-y-1">
                    <span className="text-slate-400 text-[10px] uppercase font-bold block">Registered Traders</span>
                    <span className="font-bold text-[#00F2FE]">{allUsers.length} Customer Accounts</span>
                    <span className="text-[11px] text-slate-500 block">Available for Impersonation / Audit</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ======================================================== */}
        {/* MODAL: ADMIN MARKET CREATION PROTOCOL                    */}
        {/* ======================================================== */}
        {showCreateMarketModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 p-4 overflow-y-auto">
            <div className="w-full max-w-lg rounded-3xl bg-[#0F172A] border border-[#00F2FE]/50 p-6 shadow-2xl relative my-auto">
              <button
                onClick={() => setShowCreateMarketModal(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white"
              >
                <XCircle className="w-5 h-5" />
              </button>

              <h3 className="text-base font-black text-white mb-1">Admin Market Creation Protocol</h3>
              <p className="text-xs text-slate-400 mb-4">
                Deploy an official platform market directly to the public prediction feed
              </p>

              <form onSubmit={handleCreateOfficialMarket} className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">Question Title:</label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. Will ISRO launch Chandrayaan-4 before Q4 2027?"
                    className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2 text-white font-bold"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-300 block mb-1 font-semibold">Category:</label>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value as MarketCategory)}
                      className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white font-bold"
                    >
                      {['Cricket', 'Politics', 'News', 'Crypto', 'Tech', 'Cinema', 'Finance', 'Others'].map(
                        (c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        )
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-semibold">Target Pool (₹):</label>
                    <input
                      type="number"
                      value={newTargetPool}
                      onChange={(e) => setNewTargetPool(Number(e.target.value))}
                      className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[#00F2FE] block mb-1 font-bold">YES Sub-Meaning:</label>
                    <input
                      type="text"
                      value={newYesMeaning}
                      onChange={(e) => setNewYesMeaning(e.target.value)}
                      placeholder="e.g. Launch confirmed"
                      className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white"
                    />
                  </div>

                  <div>
                    <label className="text-rose-400 block mb-1 font-bold">NO Sub-Meaning:</label>
                    <input
                      type="text"
                      value={newNoMeaning}
                      onChange={(e) => setNewNoMeaning(e.target.value)}
                      placeholder="e.g. Delayed or scrubbed"
                      className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-slate-300 font-semibold">Initial Share Pricing Slider:</label>
                    <span className="font-mono text-white font-bold">
                      YES: ₹{newSharePrice.toFixed(1)} • NO: ₹{(10 - newSharePrice).toFixed(1)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={1.0}
                    max={9.0}
                    step={0.5}
                    value={newSharePrice}
                    onChange={(e) => setNewSharePrice(Number(e.target.value))}
                    className="w-full accent-[#00F2FE]"
                  />
                </div>

                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">Resolution Proof Source:</label>
                  <input
                    type="text"
                    value={newProofSource}
                    onChange={(e) => setNewProofSource(e.target.value)}
                    placeholder="e.g. Official ISRO press release or Gazette"
                    className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2 text-white"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-xs shadow-md mt-2"
                >
                  Publish Market to Public Feed
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* MODAL: MANUAL BALANCE ADJUSTMENT                         */}
        {/* ======================================================== */}
        {adjustingUser && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 p-4">
            <div className="w-full max-w-sm rounded-3xl bg-[#0F172A] border border-[#00F2FE]/50 p-6 shadow-2xl relative">
              <button
                onClick={() => setAdjustingUser(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white"
              >
                <XCircle className="w-5 h-5" />
              </button>

              <h4 className="text-sm font-black text-white mb-1">Adjust Customer Balance</h4>
              <p className="text-xs text-slate-400 mb-4">
                User: <strong className="text-white">{adjustingUser.displayName}</strong> (Current Real: ₹
                {adjustingUser.realBalance})
              </p>

              <form onSubmit={handleExecuteBalanceAdjustment} className="space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustType('CREDIT')}
                    className={`py-2 rounded-xl font-bold border transition ${
                      adjustType === 'CREDIT'
                        ? 'bg-[#10B981]/20 border-[#10B981] text-[#10B981]'
                        : 'bg-[#111827] border-white/10 text-slate-400'
                    }`}
                  >
                    + Credit Funds
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustType('DEBIT')}
                    className={`py-2 rounded-xl font-bold border transition ${
                      adjustType === 'DEBIT'
                        ? 'bg-rose-500/20 border-rose-500 text-rose-400'
                        : 'bg-[#111827] border-white/10 text-slate-400'
                    }`}
                  >
                    - Debit Funds
                  </button>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Adjustment Amount (₹):</label>
                  <input
                    type="number"
                    min={1}
                    value={adjustAmount}
                    onChange={(e) => setAdjustAmount(Number(e.target.value))}
                    className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Audit Log Reason:</label>
                  <input
                    type="text"
                    value={adjustReason}
                    onChange={(e) => setAdjustReason(e.target.value)}
                    placeholder="Reason for audit ledger..."
                    className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-extrabold text-xs mt-2"
                >
                  Confirm Ledger Adjustment
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* MODAL: UNIVERSAL DELETION REASON WITH 100% ESCROW REFUND */}
        {/* ======================================================== */}
        {deletingMarket && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 p-4">
            <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-red-500 p-6 shadow-2xl relative">
              <button
                onClick={() => setDeletingMarket(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white"
              >
                <XCircle className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 mb-3 text-red-400">
                <Trash2 className="w-6 h-6" />
                <h3 className="text-base font-black">Cancel Event & Escrow Refund</h3>
              </div>

              <p className="text-xs text-white font-bold mb-3">"{deletingMarket.title}"</p>

              <div className="p-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-xs text-red-300 mb-4 leading-relaxed">
                <strong>100% Escrow Refund Guarantee:</strong> All bets placed by users will be credited back in full immediately, and system broadcast alerts will be dispatched.
              </div>

              <div className="space-y-1 mb-4">
                <label className="text-xs font-semibold text-slate-300 block">
                  Broadcast Deletion Reason:
                </label>
                <textarea
                  value={deletionReason}
                  onChange={(e) => setDeletionReason(e.target.value)}
                  rows={3}
                  className="w-full bg-[#111827] border border-white/15 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setDeletingMarket(null)}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 text-white font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={handleExecuteDeleteAndRefund}
                  className="flex-1 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-extrabold text-xs transition"
                >
                  Execute 100% Refund
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* MODAL: MANDATORY REJECTION REMARKS PAYLOAD FLOW           */}
        {/* ======================================================== */}
        {rejectingTx && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 p-4 overflow-y-auto">
            <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-red-500/60 p-6 shadow-2xl relative my-auto animate-in fade-in zoom-in-95 duration-200">
              <button
                onClick={() => setRejectingTx(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white"
              >
                <XCircle className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 mb-2 text-red-400">
                <ShieldAlert className="w-6 h-6 shrink-0" />
                <h3 className="text-base font-black text-white">
                  {rejectingTx.type === 'DEPOSIT' ? 'Decline Manual Deposit' : 'Reject Customer Withdrawal'}
                </h3>
              </div>

              <p className="text-xs text-slate-400 mb-3">
                Mandatory Admin remarks requirement. The reason provided is logged in the permanent audit trail, sent via in-app alert, and displayed prominently in the customer's wallet transaction details.
              </p>

              {/* Transaction Context Callout */}
              <div className="p-3.5 rounded-2xl bg-[#0B0F17] border border-white/10 text-xs space-y-1 mb-3">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Requested Amount:</span>
                  <span className="font-black text-sm text-white">
                    {storageService.formatAmount(rejectingTx.amount, currency)}
                  </span>
                </div>
                {rejectingTx.utrNumber && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">UTR Reference:</span>
                    <span className="font-mono text-[#00F2FE] font-bold">{rejectingTx.utrNumber}</span>
                  </div>
                )}
                {rejectingTx.bankDetails && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Destination:</span>
                    <span className="font-mono text-[#00F2FE] font-bold">{rejectingTx.bankDetails}</span>
                  </div>
                )}
                {rejectingTx.type === 'WITHDRAWAL' && (
                  <div className="pt-1 text-[11px] text-[#10B981] font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span>Instant wallet refund will be disbursed automatically to the customer.</span>
                  </div>
                )}
              </div>

              {/* Quick Preset Remark Chips */}
              <div className="space-y-1.5 mb-3">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                  Select Quick Reason Preset:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(rejectingTx.type === 'DEPOSIT'
                    ? [
                        'Invalid UTR reference / transaction not found in bank ledger',
                        'Duplicate UTR already claimed by another user',
                        'Incorrect deposit amount reported',
                        'Payment failed / reverted at issuing bank',
                      ]
                    : [
                        'Bank account details mismatch KYC legal name',
                        'Invalid UPI ID / handle currently inactive',
                        'Compliance verification required before withdrawal',
                        'Suspected fraudulent activity / KYC re-verification needed',
                      ]
                  ).map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => {
                        setRejectionRemark(preset);
                        setRejectionError(null);
                      }}
                      className={`text-[10px] px-2.5 py-1 rounded-lg border text-left transition font-medium ${
                        rejectionRemark === preset
                          ? 'bg-red-500/20 border-red-500 text-red-200 font-bold'
                          : 'bg-[#111827] border-white/10 text-slate-400 hover:text-white hover:border-white/20'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mandatory Rejection Remarks Textarea */}
              <form onSubmit={handleConfirmRejection} className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Rejection Reason / Remarks <span className="text-red-400">*</span>:
                  </label>
                  <textarea
                    value={rejectionRemark}
                    onChange={(e) => {
                      setRejectionRemark(e.target.value);
                      setRejectionError(null);
                    }}
                    rows={3}
                    placeholder="Enter explicit reason explaining why this payment was declined..."
                    className="w-full bg-[#111827] border border-white/15 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-red-500 transition"
                    required
                  />
                </div>

                {rejectionError && (
                  <div className="p-2 rounded-xl bg-red-500/20 border border-red-500/40 text-xs text-red-300 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{rejectionError}</span>
                  </div>
                )}

                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setRejectingTx(null)}
                    className="flex-1 py-2.5 rounded-xl bg-white/10 text-white font-bold text-xs hover:bg-white/15 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-extrabold text-xs transition shadow-lg flex items-center justify-center gap-1.5"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Confirm & Log Rejection</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
