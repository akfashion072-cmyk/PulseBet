import React from 'react';
import { X, Bell, CheckCircle2, AlertTriangle, Info, ShieldAlert } from 'lucide-react';
import { storageService } from '../services/storageService';

interface NotificationDrawerProps {
  userId: string | undefined;
  onClose: () => void;
  onRefresh: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  userId,
  onClose,
  onRefresh,
}) => {
  const notifications = storageService.getNotifications(userId);

  const handleMarkAllRead = () => {
    if (userId) {
      storageService.markNotificationsRead(userId);
      onRefresh();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md h-full bg-[#0F172A] border-l border-white/10 p-5 flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-[#00F2FE]" />
            <h3 className="text-base font-extrabold text-white">Activity & Alerts</h3>
          </div>

          <div className="flex items-center gap-2">
            {userId && (
              <button
                onClick={handleMarkAllRead}
                className="text-[11px] text-slate-400 hover:text-white"
              >
                Mark Read
              </button>
            )}
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto py-3 space-y-2.5">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-500">
              No notifications yet.
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                className={`p-3.5 rounded-2xl border transition ${
                  n.type === 'SUCCESS'
                    ? 'bg-[#10B981]/10 border-[#10B981]/30 text-slate-200'
                    : n.type === 'ALERT'
                    ? 'bg-red-500/10 border-red-500/30 text-slate-200'
                    : n.type === 'WARNING'
                    ? 'bg-amber-500/10 border-amber-500/30 text-slate-200'
                    : 'bg-[#111827] border-white/10 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {n.type === 'SUCCESS' && <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />}
                  {n.type === 'ALERT' && <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />}
                  {n.type === 'WARNING' && <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />}
                  {n.type === 'INFO' && <Info className="w-4 h-4 text-[#00F2FE] shrink-0" />}
                  <h5 className="text-xs font-bold text-white leading-tight">{n.title}</h5>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed pl-6">{n.message}</p>
                <span className="text-[9px] text-slate-500 pl-6 block mt-1">
                  {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
