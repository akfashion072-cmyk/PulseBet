import React from 'react';
import { MarketCategory } from '../types';
import {
  Flame,
  Search,
  Users,
  Compass,
} from 'lucide-react';

interface MarketPillsProps {
  selectedCategory: MarketCategory;
  onSelectCategory: (cat: MarketCategory) => void;
  showFriendRoomsOnly: boolean;
  onToggleFriendRooms: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  categoryCounts: Record<string, number>;
}

const CATEGORIES: MarketCategory[] = [
  'All',
  'Cricket',
  'Politics',
  'News',
  'Crypto',
  'Tech',
  'Cinema',
  'Finance',
  'Others',
];

export const MarketPills: React.FC<MarketPillsProps> = ({
  selectedCategory,
  onSelectCategory,
  showFriendRoomsOnly,
  onToggleFriendRooms,
  searchQuery,
  onSearchChange,
  categoryCounts,
}) => {
  return (
    <div className="space-y-3 mb-6">
      {/* Search and Filters row */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        {/* Search input */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search prediction markets, room codes (#GOA26)..."
            className="w-full bg-[#111827] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00F2FE]/50 transition"
          />
        </div>

        {/* Friend Rooms Quick Toggle */}
        <button
          onClick={onToggleFriendRooms}
          className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-bold border transition ${
            showFriendRoomsOnly
              ? 'bg-[#10B981]/20 border-[#10B981] text-[#10B981] shadow-[0_0_15px_rgba(16,185,129,0.3)]'
              : 'bg-[#111827] border-white/10 text-slate-300 hover:text-white hover:border-white/20'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Friend Rooms (15% Royalty)</span>
          {showFriendRoomsOnly && (
            <span className="w-2 h-2 rounded-full bg-[#10B981] animate-ping" />
          )}
        </button>
      </div>

      {/* 8 Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat && !showFriendRoomsOnly;
          const count = categoryCounts[cat] || 0;

          return (
            <button
              key={cat}
              onClick={() => {
                if (showFriendRoomsOnly) onToggleFriendRooms();
                onSelectCategory(cat);
              }}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition shrink-0 ${
                isSelected
                  ? 'bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-extrabold shadow-[0_0_15px_rgba(0,242,254,0.4)]'
                  : 'bg-[#111827] text-slate-400 hover:text-white hover:bg-white/5 border border-white/5'
              }`}
            >
              {cat === 'All' ? (
                <Compass className="w-3.5 h-3.5" />
              ) : cat === 'Cricket' || cat === 'Crypto' ? (
                <Flame className="w-3.5 h-3.5" />
              ) : null}
              <span>{cat}</span>
              {count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected ? 'bg-black/20 text-black' : 'bg-white/10 text-slate-400'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
