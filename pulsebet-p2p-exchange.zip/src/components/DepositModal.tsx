import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  ShieldAlert,
  Clock,
  ArrowRight,
  QrCode,
  AlertCircle,
} from 'lucide-react';
import { Currency, User } from '../types';
import { storageService } from '../services/storageService';

interface DepositModalProps {
  currentUser: User | null;
  currency: Currency;
  onClose: () => void;
  onDepositSubmitted: () => void;
}

export const DepositModal: React.FC<DepositModalProps> = ({
  currentUser,
  currency: _currency,
  onClose,
  onDepositSubmitted,
}) => {
  const [amount, setAmount] = useState<number>(500);
  const [utrNumber, setUtrNumber] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successTxId, setSuccessTxId] = useState<string | null>(null);

  const minDeposit = storageService.getConfig().minDepositAmount;
  const merchantUpi = 'pulsebet.ops@icici';

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(merchantUpi);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmitDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (amount < minDeposit) {
      setErrorMsg(`Minimum deposit amount is ₹${minDeposit}`);
      return;
    }

    if (!utrNumber.trim() || utrNumber.trim().length < 8) {
      setErrorMsg('Please enter a valid 12-digit UTR transaction reference number');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg(null);

      const tx = storageService.requestDeposit(
        currentUser.id,
        amount,
        utrNumber,
        currentUser.kyc.upiHandle || 'User App'
      );

      // Dispatch custom window event upon submission to trigger immediate UI reactivity across all open tabs/views
      if (typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent('deposit_submitted', {
            detail: {
              transactionId: tx.id,
              userId: currentUser.id,
              userName: currentUser.displayName,
              amount,
              utrNumber: utrNumber.trim().toUpperCase(),
            },
          })
        );
        window.dispatchEvent(new CustomEvent('pending_deposits_updated'));
        window.dispatchEvent(new CustomEvent('balance_updated'));
        window.dispatchEvent(new Event('storage'));
      }

      setSuccessTxId(tx.id);
      onDepositSubmitted();
    } catch (err: any) {
      setErrorMsg(err.message || 'Deposit submission failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-white/15 p-6 shadow-2xl relative my-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-[#10B981]/15 border border-[#10B981]/30 flex items-center justify-center text-[#10B981]">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">Deposit Real Funds</h3>
            <p className="text-xs text-slate-400">
              Min Deposit: <strong className="text-white">₹{minDeposit}</strong> • Instant Verification Rails
            </p>
          </div>
        </div>

        {/* Success confirmation state */}
        {successTxId ? (
          <div className="py-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#10B981]/20 border border-[#10B981] text-[#10B981] flex items-center justify-center mx-auto animate-bounce">
              <Clock className="w-8 h-8" />
            </div>

            <div>
              <h4 className="text-lg font-extrabold text-white">
                UTR Queued for Admin Approval
              </h4>
              <p className="mt-1 text-xs text-slate-300 max-w-xs mx-auto leading-relaxed">
                Your deposit of <strong>₹{amount}</strong> (UTR: <code className="text-[#00F2FE]">{utrNumber.toUpperCase()}</code>) is in the verification queue.
              </p>
            </div>

            <div className="p-3 rounded-2xl bg-[#0B0F17] border border-white/10 text-xs text-slate-400 text-left space-y-1">
              <div className="flex justify-between">
                <span>Fraud Guard Status:</span>
                <span className="text-[#F59E0B] font-bold">PENDING_APPROVAL</span>
              </div>
              <div className="flex justify-between">
                <span>Verification Time:</span>
                <span className="text-white">~1 to 3 minutes</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-extrabold text-xs"
            >
              Done & Return to Markets
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitDeposit} className="space-y-4">
            {/* Amount Selection */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Select or Enter Deposit Amount:
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black">
                  ₹
                </span>
                <input
                  type="number"
                  min={minDeposit}
                  value={amount || ''}
                  onChange={(e) => {
                    setAmount(Number(e.target.value));
                    setErrorMsg(null);
                  }}
                  className="w-full bg-[#111827] border border-white/15 rounded-2xl pl-9 pr-4 py-3 text-white font-black text-lg focus:outline-none focus:border-[#10B981]/60 transition"
                  placeholder="500"
                />
              </div>

              {/* Quick Presets */}
              <div className="grid grid-cols-4 gap-1.5 mt-2">
                {[100, 500, 1000, 2500].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => {
                      setAmount(preset);
                      setErrorMsg(null);
                    }}
                    className={`py-1.5 rounded-xl text-xs font-bold border transition ${
                      amount === preset
                        ? 'bg-[#10B981]/20 border-[#10B981] text-[#10B981]'
                        : 'bg-[#111827] border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    ₹{preset}
                  </button>
                ))}
              </div>
            </div>

            {/* QR Code and UPI VPA Rails */}
            <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 flex flex-col items-center gap-3">
              <div className="w-36 h-36 bg-white p-2.5 rounded-2xl shadow-lg flex flex-col items-center justify-center">
                {/* Visual SVG QR Code pattern */}
                <svg viewBox="0 0 100 100" className="w-full h-full text-black">
                  <path
                    fill="currentColor"
                    d="M10 10h30v30h-30zM15 15v20h20v-20zM22 22h6v6h-6zM60 10h30v30h-30zM65 15v20h20v-20zM72 22h6v6h-6zM10 60h30v30h-30zM15 65v20h20v-20zM22 72h6v6h-6zM50 15h5v5h-5zM50 30h5v15h-5zM60 50h10v10h-10zM75 50h15v5h-15zM50 70h5v20h-5zM65 70h15v5h-15zM80 80h10v10h-10zM60 85h5v5h-5z"
                  />
                </svg>
              </div>

              <div className="text-center w-full">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                  Scan & Pay via GPay / PhonePe / Paytm
                </span>

                <div className="mt-1 flex items-center justify-between bg-[#111827] border border-white/10 rounded-xl px-3 py-1.5 text-xs">
                  <span className="font-mono text-white truncate">{merchantUpi}</span>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="flex items-center gap-1 text-[#00F2FE] hover:text-white font-bold shrink-0 ml-2"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-[#10B981]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* UTR Input (Strict Fraud Control) */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300 block">
                Submit 12-Digit UTR / Transaction Reference:
              </label>
              <input
                type="text"
                value={utrNumber}
                onChange={(e) => {
                  setUtrNumber(e.target.value.toUpperCase());
                  setErrorMsg(null);
                }}
                maxLength={20}
                placeholder="e.g. 439281729481"
                className="w-full bg-[#111827] border border-white/15 rounded-2xl px-4 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-[#00F2FE]/60 transition"
              />
              <p className="text-[10px] text-slate-500">
                Found in payment receipt under "UPI Ref No" or "UTR Number".
              </p>
            </div>

            {/* Strict Fraud Guard Notice */}
            <div className="p-3 rounded-2xl bg-[#F59E0B]/10 border border-[#F59E0B]/20 text-[11px] text-[#F59E0B] flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                <strong>Fraud Control:</strong> Automatic wallet credits on UTR submission are disabled. Your deposit is routed to the Admin Verification Queue and credited upon manual confirmation.
              </span>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#10B981] to-[#00F2FE] text-black font-black text-sm shadow-[0_0_25px_rgba(16,185,129,0.3)] hover:opacity-95 transition flex items-center justify-center gap-2"
            >
              <span>Submit UTR for Verification</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
