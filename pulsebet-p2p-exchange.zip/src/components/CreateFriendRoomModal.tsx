import React, { useState } from 'react';
import {
  X,
  Users,
  Sparkles,
  Lock,
  Globe,
  FileCheck,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Currency, MarketCategory, User } from '../types';
import { storageService } from '../services/storageService';

export interface CreateFriendRoomModalProps {
  currentUser: User | null;
  currency: Currency;
  onClose: () => void;
  onRoomCreated: (newMarketId: string) => void;
  onOpenAuth: () => void;
}

const CATEGORIES: MarketCategory[] = [
  'Cricket',
  'Politics',
  'News',
  'Crypto',
  'Tech',
  'Cinema',
  'Finance',
  'Others',
];

export const CreateFriendRoomModal: React.FC<CreateFriendRoomModalProps> = ({
  currentUser,
  currency: _currency,
  onClose,
  onRoomCreated,
  onOpenAuth,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<MarketCategory>('Cricket');
  const [yesMeaning, setYesMeaning] = useState('');
  const [noMeaning, setNoMeaning] = useState('');
  const [initialSharePrice, setInitialSharePrice] = useState<number>(5.0); // e.g. ₹5.0 YES, ₹5.0 NO
  const [targetPool, setTargetPool] = useState<number>(20000); // Default ₹20,000 pool
  const [isPublicListing, setIsPublicListing] = useState(true); // Hybrid feed default
  const [lifespanDays, setLifespanDays] = useState<number>(3);
  const [resolutionProof, setResolutionProof] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 15% Creator Royalty Calculation matching selected target pool
  const config = storageService.getConfig();
  const royaltyPercent = config.globalCreatorRoyaltyPercent; // 15%
  const guaranteedEarnings = Math.round(targetPool * (royaltyPercent / 100));

  const handlePoolChipSelect = (amount: number) => {
    setTargetPool(amount);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (!title.trim() || title.length < 8) {
      setErrorMsg('Please enter a clear prediction title (at least 8 characters).');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg(null);

      // Generate memorable room code (e.g. GOA26, IPL99)
      const prefix = category.substring(0, 3).toUpperCase();
      const code = `${prefix}${Math.floor(10 + Math.random() * 89)}`;

      const resolvesAt = new Date(Date.now() + lifespanDays * 24 * 3600 * 1000).toISOString();

      // Custom Friend Room starts with 0 initial seed so volume reflects real wagers
      const initialSeedTotal = 0;
      const created = storageService.createMarket(
        {
          title: title.trim(),
          description: `Viral Friend Room hosted by @${currentUser.displayName}. Target Pool: ₹${targetPool.toLocaleString('en-IN')}. Proof source: ${resolutionProof.trim() || 'Verified official scorecard/bulletin'}.`,
          category,
          creatorId: currentUser.id,
          creatorName: currentUser.displayName,
          creatorAvatar: currentUser.avatarUrl,
          isOfficialAdmin: false,
          isPrivate: !isPublicListing,
          isPublic: isPublicListing,
          visibility: isPublicListing ? 'public' : 'private',
          roomCode: code,
          yesMeaning: yesMeaning.trim() || 'YES Outcome Verified',
          noMeaning: noMeaning.trim() || 'NO Outcome / Opposite',
          initialSharePrice,
          resolutionProofSource: resolutionProof.trim() || 'Verified media/official portal',
          targetPool,
          resolvesAt,
        },
        initialSeedTotal
      );

      confetti({
        particleCount: 80,
        spread: 90,
        origin: { y: 0.6 },
        colors: ['#00F2FE', '#10B981', '#F59E0B'],
      });

      onRoomCreated(created.id);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to deploy room.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-3xl bg-[#0F172A] border border-[#00F2FE]/30 shadow-[0_0_50px_rgba(0,242,254,0.15)] p-5 sm:p-7 relative my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#10B981] to-[#00F2FE] p-0.5 shadow-[0_0_15px_rgba(16,185,129,0.4)]">
              <div className="w-full h-full bg-[#0B0F17] rounded-[14px] flex items-center justify-center text-[#10B981]">
                <Users className="w-5 h-5" />
              </div>
            </div>
            <div>
              <h2 className="text-lg font-black text-white">Create Viral Friend Room</h2>
              <p className="text-xs text-slate-400">
                Custom P2P question • Earn guaranteed{' '}
                <strong className="text-[#F59E0B]">15% Creator Royalty</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleCreate} className="overflow-y-auto py-4 space-y-4 pr-1 flex-1">
          {/* Question / Prediction Title */}
          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1">
              Question / Prediction Title:
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                setErrorMsg(null);
              }}
              placeholder="e.g. Will Rohit Sharma hit 5+ sixes in tonight's IPL match?"
              className="w-full bg-[#111827] border border-white/15 rounded-2xl px-4 py-2.5 text-white text-xs sm:text-sm font-semibold focus:outline-none focus:border-[#00F2FE]/60 transition"
              required
            />
          </div>

          {/* Category Dropdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Category:
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as MarketCategory)}
                className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white text-xs font-bold focus:outline-none focus:border-[#10B981]"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Room Lifespan:
              </label>
              <select
                value={lifespanDays}
                onChange={(e) => setLifespanDays(Number(e.target.value))}
                className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white text-xs font-bold focus:outline-none focus:border-[#10B981]"
              >
                <option value={1}>24 Hours (Fast Settle)</option>
                <option value={3}>3 Days (Standard Tournament)</option>
                <option value={7}>7 Days (Weekly)</option>
                <option value={14}>14 Days (Extended)</option>
              </select>
            </div>
          </div>

          {/* YES / NO Option Meanings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-[#0B0F17] border border-white/10">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-[#00F2FE]">YES Option Meaning:</label>
                <span className="text-[10px] text-slate-500">Under BUY YES button</span>
              </div>
              <input
                type="text"
                value={yesMeaning}
                onChange={(e) => setYesMeaning(e.target.value)}
                placeholder="e.g. Hits 5 or more sixes"
                className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#00F2FE]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-rose-400">NO Option Meaning:</label>
                <span className="text-[10px] text-slate-500">Under BUY NO button</span>
              </div>
              <input
                type="text"
                value={noMeaning}
                onChange={(e) => setNoMeaning(e.target.value)}
                placeholder="e.g. Hits 4 or fewer sixes"
                className="w-full bg-[#111827] border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-rose-400"
              />
            </div>
          </div>

          {/* Initial YES / NO Odds Slider */}
          <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300 font-bold">Initial Share Pricing / Odds:</span>
              <span className="font-mono text-xs font-bold">
                <span className="text-[#00F2FE]">YES: ₹{initialSharePrice.toFixed(1)}</span> •{' '}
                <span className="text-rose-400">NO: ₹{(10 - initialSharePrice).toFixed(1)}</span>
              </span>
            </div>

            <input
              type="range"
              min={1.0}
              max={9.0}
              step={0.5}
              value={initialSharePrice}
              onChange={(e) => setInitialSharePrice(Number(e.target.value))}
              className="w-full accent-[#00F2FE] cursor-pointer"
            />

            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>₹1.0 Low YES</span>
              <span>₹5.0 Even Odds (50/50)</span>
              <span>₹9.0 High YES</span>
            </div>
          </div>

          {/* Total Target Pool Amount with Quick-Select Pills */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <label className="font-semibold text-slate-300">
                Total Target Pool Amount:
              </label>
              <span className="font-bold text-white font-mono">
                ₹{targetPool.toLocaleString('en-IN')}
              </span>
            </div>

            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">
                ₹
              </span>
              <input
                type="number"
                min={1000}
                max={500000}
                value={targetPool}
                onChange={(e) => setTargetPool(Number(e.target.value))}
                className="w-full bg-[#111827] border border-white/15 rounded-xl pl-8 pr-4 py-2 text-white text-xs font-bold focus:outline-none focus:border-[#10B981]"
              />
            </div>

            {/* Quick-Select Pill Chips */}
            <div className="flex items-center gap-2">
              {[5000, 20000, 50000, 100000].map((pill) => (
                <button
                  key={pill}
                  type="button"
                  onClick={() => handlePoolChipSelect(pill)}
                  className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition ${
                    targetPool === pill
                      ? 'bg-[#10B981]/20 border-[#10B981] text-[#10B981]'
                      : 'bg-[#111827] border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  ₹{pill >= 100000 ? `${pill / 100000}L` : `${pill / 1000}k`}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive 15% Creator Royalty Box */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#F59E0B]/15 via-[#10B981]/15 to-[#00F2FE]/15 border border-[#F59E0B]/40 shadow-sm space-y-1">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#F59E0B]" />
                <span>15% Creator Royalty Engine</span>
              </span>
              <span className="text-base font-black text-[#F59E0B]">
                Your Guaranteed Earnings: +₹{guaranteedEarnings.toLocaleString('en-IN')}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              When friends wager and the pool reaches target volume, 15% creator royalty is deposited directly into your withdrawable wallet.
            </p>
          </div>

          {/* Hybrid Feed (Public Listing) Toggle Switch */}
          <div className="p-3.5 rounded-2xl bg-[#111827] border border-white/10 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {isPublicListing ? (
                <div className="w-8 h-8 rounded-xl bg-[#00F2FE]/20 text-[#00F2FE] flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
              ) : (
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
              )}
              <div>
                <p className="text-xs font-bold text-white">
                  {isPublicListing ? 'Hybrid Feed (Public Listing)' : 'Private Room (Invite-Only)'}
                </p>
                <p className="text-[10px] text-slate-400">
                  {isPublicListing
                    ? 'Show in main P2P markets feed for maximum liquidity & royalties'
                    : 'Accessible strictly via direct Room Code or WhatsApp invite link'}
                </p>
              </div>
            </div>

            <button
              type="button"
              role="switch"
              aria-checked={isPublicListing}
              aria-label="Toggle Public Listing vs Private Room"
              onClick={() => setIsPublicListing((prev) => !prev)}
              className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 cursor-pointer ${
                isPublicListing ? 'bg-[#00F2FE]' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-black transition-transform duration-200 transform ${
                  isPublicListing ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Resolution Proof Text Input */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1 flex items-center gap-1.5">
              <FileCheck className="w-3.5 h-3.5 text-[#10B981]" />
              <span>Resolution Proof / Verification Source:</span>
            </label>
            <input
              type="text"
              value={resolutionProof}
              onChange={(e) => setResolutionProof(e.target.value)}
              placeholder="e.g. Official BCCI match scorecard link, ECI election portal, or Bloomberg"
              className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-none focus:border-[#10B981]"
            />
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400">
              {errorMsg}
            </div>
          )}

          {/* Action Button: Full-width vibrant button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#10B981] via-[#00F2FE] to-[#10B981] text-black font-black text-sm shadow-[0_0_25px_rgba(16,185,129,0.35)] hover:opacity-95 transition flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>✨ Deploy Viral Friend Room (Instant Live)</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
