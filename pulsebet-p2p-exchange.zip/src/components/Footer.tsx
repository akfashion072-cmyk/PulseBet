import React, { useState } from 'react';
import {
  TrendingUp,
  ShieldCheck,
  FileText,
  Lock,
  Scale,
  CreditCard,
  Zap,
  Building2,
  Globe2,
  AlertTriangle,
  X,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const [activeLegalModal, setActiveLegalModal] = useState<
    'terms' | 'privacy' | 'court' | null
  >(null);

  return (
    <footer className="mt-auto border-t border-white/10 bg-[#070A10] text-slate-300 relative z-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        {/* 3-Column High-Trust Layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12 pb-10 border-b border-white/10">
          {/* Column 1: Brand & Solvency */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#00F2FE] to-[#10B981] p-0.5 shadow-[0_0_15px_rgba(0,242,254,0.4)]">
                <div className="w-full h-full bg-[#0B0F17] rounded-[10px] flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-[#00F2FE]" />
                </div>
              </div>
              <span className="font-black text-lg tracking-wider text-white">
                PULSE<span className="text-[#00F2FE]">BET</span>
              </span>
              <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-[#10B981]/20 text-[#10B981] font-bold border border-[#10B981]/30">
                P2P
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Production-grade Peer-to-Peer Prediction Exchange & Viral Friend Rooms. Built on an
              adaptive parimutuel liquidity engine with 1.01x principal protection guarantee.
            </p>

            {/* Glowing Solvency Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#10B981]/15 border border-[#10B981]/40 text-[#10B981] text-xs font-bold shadow-[0_0_15px_rgba(16,185,129,0.25)]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10B981] animate-ping" />
              <span>🟢 Real-Time Escrow Solvency Verified</span>
            </div>

            <div className="text-[11px] text-slate-500 space-y-0.5 font-mono">
              <div>Escrow Smart Lock: SHA-256 Multi-Sig Audited</div>
              <div>Platform Commission: 10% • Host Royalty: 15%</div>
            </div>
          </div>

          {/* Column 2: Legal & Compliance */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#00F2FE]" />
              <span>Legal & Compliance Suite</span>
            </h4>

            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => setActiveLegalModal('terms')}
                  className="hover:text-white transition flex items-center gap-1.5 text-left"
                >
                  <FileText className="w-3.5 h-3.5 text-[#00F2FE]" />
                  <span>Terms of Service & Settlement Protocol</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveLegalModal('privacy')}
                  className="hover:text-white transition flex items-center gap-1.5 text-left"
                >
                  <Lock className="w-3.5 h-3.5 text-[#10B981]" />
                  <span>DPDP Act 2023 Compliant Privacy Policy</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveLegalModal('court')}
                  className="hover:text-white transition flex items-center gap-1.5 text-left"
                >
                  <Scale className="w-3.5 h-3.5 text-[#F59E0B]" />
                  <span>Supreme Court Precedent & Skill Disclaimer</span>
                </button>
              </li>
            </ul>

            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 text-[11px] text-slate-400 space-y-1">
              <div className="flex items-center gap-1.5 text-[#10B981] font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Anti-Fraud & AML Guard Active</span>
              </div>
              <p>Manual UTR ledger audit prevents double-spend and unauthorized balance injection.</p>
            </div>
          </div>

          {/* Column 3: Banking & Rails */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[#F59E0B]" />
              <span>Banking & Settlement Rails</span>
            </h4>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <Zap className="w-3.5 h-3.5 text-[#00F2FE]" />
                  <span>Micro-UPI</span>
                </div>
                <span className="text-[10px] text-slate-400">PhonePe, GPay, Paytm</span>
              </div>

              <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <Building2 className="w-3.5 h-3.5 text-[#10B981]" />
                  <span>IMPS / NEFT</span>
                </div>
                <span className="text-[10px] text-slate-400">24x7 Bank Clearance</span>
              </div>

              <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <CreditCard className="w-3.5 h-3.5 text-[#F59E0B]" />
                  <span>Cards / RuPay</span>
                </div>
                <span className="text-[10px] text-slate-400">Global Visa, Mastercard</span>
              </div>

              <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <Globe2 className="w-3.5 h-3.5 text-purple-400" />
                  <span>USDT Crypto</span>
                </div>
                <span className="text-[10px] text-slate-400">TRC-20, ERC-20, Solana</span>
              </div>
            </div>

            <div className="text-[10px] text-slate-500">
              Clearance Latency: ~1 to 3 minutes for approved real-money withdrawals.
            </div>
          </div>
        </div>

        {/* Jurisdictional Legal Notice Box */}
        <div className="mt-8 p-4 sm:p-5 rounded-2xl bg-[#0B0F17] border border-white/10 text-xs text-slate-400 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/5 pb-2">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-extrabold text-[10px] border border-rose-500/30">
                18+ ONLY
              </span>
              <strong className="text-white text-xs">
                Jurisdictional Compliance & Skill Precedent Notice
              </strong>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">
              Constitution of India Art. 19(1)(g)
            </span>
          </div>

          <p className="leading-relaxed text-[11px]">
            Prediction markets hosted on PulseBet involve analytical assessment, quantitative modeling,
            and information aggregation. In accordance with landmark Supreme Court of India rulings in{' '}
            <strong className="text-slate-200">
              State of Bombay v. R.M.D. Chamarbaugwala (AIR 1957 SC 699)
            </strong>{' '}
            and{' '}
            <strong className="text-slate-200">
              K.R. Lakshmanan v. State of Tamil Nadu (1996 2 SCC 226)
            </strong>
            , activities where success predominantly depends upon substantial knowledge, experience, and skill
            are recognized as lawful business activities.
          </p>

          <div className="flex items-start gap-2 pt-1 text-[11px] text-amber-300/90">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              <strong>Restricted Territories:</strong> Residents of <strong>Assam, Telangana, Odisha, Nagaland, Sikkim, and Andhra Pradesh</strong> are strictly restricted from participating in real-money wagers under prevailing state regulations. View-only educational browsing remains accessible.
            </span>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} PulseBet P2P Prediction Exchange. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span>Friction-Free Limits (₹10 Trade • ₹100 Deposit • ₹200 Withdrawal)</span>
            <span>Principal 1.01x Guaranteed</span>
          </div>
        </div>
      </div>

      {/* Interactive Legal Modals */}
      {activeLegalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="w-full max-w-lg rounded-3xl bg-[#0F172A] border border-white/15 p-6 shadow-2xl relative max-h-[85vh] flex flex-col">
            <button
              onClick={() => setActiveLegalModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {activeLegalModal === 'terms' && (
              <div className="space-y-3 overflow-y-auto pr-1">
                <h3 className="text-base font-black text-white">Terms of Service & Settlement Protocol</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  PulseBet provides an automated parimutuel peer-to-peer contract execution environment. All wagers are held in transparent smart escrow until the verified resolution time.
                </p>
                <div className="text-xs text-slate-400 space-y-2">
                  <p>1. <strong>Escrow & Settlement:</strong> Upon resolution, net winning payouts are distributed instantly with 10% platform fee on official markets, or 10% platform + 15% creator royalty on friend rooms.</p>
                  <p>2. <strong>1.01x Guarantee:</strong> Winning participants are guaranteed a minimum 1.01x return of principal, protected by dynamic fee capping.</p>
                  <p>3. <strong>Cancellation Refunds:</strong> Any market cancelled by Super Admin executes an automated 100% principal refund to all betters.</p>
                </div>
              </div>
            )}

            {activeLegalModal === 'privacy' && (
              <div className="space-y-3 overflow-y-auto pr-1">
                <h3 className="text-base font-black text-white">DPDP Act 2023 Privacy Policy</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  PulseBet complies with the Digital Personal Data Protection (DPDP) Act, 2023. User data is encrypted at rest and in transit.
                </p>
                <div className="text-xs text-slate-400 space-y-2">
                  <p>• <strong>KYC Data:</strong> PAN numbers and bank/UPI identifiers are used exclusively for regulatory compliance and automated fraud detection.</p>
                  <p>• <strong>Zero Third-Party Sale:</strong> We never sell, lease, or monetize customer identity documents or transaction logs.</p>
                  <p>• <strong>Data Sovereignty:</strong> Storage and financial transaction ledger records are maintained on resilient cloud infrastructure.</p>
                </div>
              </div>
            )}

            {activeLegalModal === 'court' && (
              <div className="space-y-3 overflow-y-auto pr-1">
                <h3 className="text-base font-black text-white">Supreme Court Precedent & Skill Classification</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Legal framework governing skill-based prediction competitions in India:
                </p>
                <div className="text-xs text-slate-400 space-y-2">
                  <p>• <strong>State of Bombay v. R.M.D. Chamarbaugwala (AIR 1957 SC 699):</strong> The Hon’ble Supreme Court established that competitions involving substantial skill do not constitute gambling and are protected under Article 19(1)(g) of the Indian Constitution.</p>
                  <p>• <strong>K.R. Lakshmanan v. State of Tamil Nadu (1996 2 SCC 226):</strong> Re-affirmed that games or competitions where success depends upon superior knowledge, training, attention, experience, and adroitness are games of skill.</p>
                </div>
              </div>
            )}

            <button
              onClick={() => setActiveLegalModal(null)}
              className="mt-4 w-full py-2.5 rounded-xl bg-white/10 text-white font-bold text-xs hover:bg-white/20 transition"
            >
              Close Notice
            </button>
          </div>
        </div>
      )}
    </footer>
  );
};
