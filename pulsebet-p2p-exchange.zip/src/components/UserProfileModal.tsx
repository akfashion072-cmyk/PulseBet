import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  TrendingUp,
  Users,
  Wallet,
  CheckCircle2,
  AlertTriangle,
  Gift,
  Zap,
  Copy,
  Check,
  MapPin,
  Navigation,
  Lock,
  KeyRound,
} from 'lucide-react';
import {
  Currency,
  IndianState,
  Market,
  MarketBet,
  RESTRICTED_INDIAN_STATES,
  User,
} from '../types';
import { storageService } from '../services/storageService';
import { geolocationService } from '../services/geolocationService';

interface UserProfileModalProps {
  currentUser: User | null;
  currency: Currency;
  onClose: () => void;
  onOpenCashout: (bet: MarketBet, market: Market) => void;
  onResolveMarket: (marketId: string, winningSide: 'YES' | 'NO') => void;
  onOpenDeposit: () => void;
  onOpenWithdraw: () => void;
}

const INDIAN_STATES: IndianState[] = [
  'Maharashtra',
  'Delhi',
  'Karnataka',
  'Tamil Nadu',
  'Uttar Pradesh',
  'Gujarat',
  'West Bengal',
  'Rajasthan',
  'Punjab',
  'Haryana',
  'Kerala',
  'Goa',
  'Madhya Pradesh',
  'Bihar',
  'Assam',
  'Telangana',
  'Odisha',
  'Nagaland',
  'Sikkim',
  'Andhra Pradesh',
  'Other',
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  currentUser,
  currency,
  onClose,
  onOpenCashout,
  onResolveMarket,
  onOpenDeposit,
  onOpenWithdraw,
}) => {
  const [activeTab, setActiveTab] = useState<
    'profile' | 'trades' | 'rooms' | 'referrals' | 'ledger'
  >('profile');

  // KYC Form State
  const [legalName, setLegalName] = useState(currentUser?.kyc.legalName || '');
  const [panNumber, setPanNumber] = useState(currentUser?.kyc.panNumber || '');
  const [selectedState, setSelectedState] = useState<IndianState>(
    currentUser?.detectedState || currentUser?.kyc.state || 'Maharashtra'
  );
  const [city, setCity] = useState(currentUser?.kyc.city || '');
  const [phone, setPhone] = useState(currentUser?.kyc.phone || '');
  const [dob, setDob] = useState(currentUser?.kyc.dob || '2000-01-01');
  const [upiHandle, setUpiHandle] = useState(currentUser?.kyc.upiHandle || '');
  const [bankAccount, setBankAccount] = useState(currentUser?.kyc.bankAccount || '');
  const [ifscCode, setIfscCode] = useState(currentUser?.kyc.ifscCode || '');
  const [kycSavedSuccess, setKycSavedSuccess] = useState(false);
  const [copiedRef, setCopiedRef] = useState(false);

  // Auto-Detect Location State
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [detectionMethod, setDetectionMethod] = useState<string | null>(null);

  // Withdrawal PIN Management State
  const [pinInput, setPinInput] = useState('');
  const [pinConfirmInput, setPinConfirmInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [pinSuccess, setPinSuccess] = useState<string | null>(null);

  const [localRefreshTrigger, setLocalRefreshTrigger] = useState(0);

  useEffect(() => {
    const handleReactivity = () => {
      setLocalRefreshTrigger((c) => c + 1);
    };
    window.addEventListener('deposit_submitted', handleReactivity);
    window.addEventListener('deposit_approved', handleReactivity);
    window.addEventListener('balance_updated', handleReactivity);
    window.addEventListener('pending_deposits_updated', handleReactivity);
    window.addEventListener('storage', handleReactivity);

    return () => {
      window.removeEventListener('deposit_submitted', handleReactivity);
      window.removeEventListener('deposit_approved', handleReactivity);
      window.removeEventListener('balance_updated', handleReactivity);
      window.removeEventListener('pending_deposits_updated', handleReactivity);
      window.removeEventListener('storage', handleReactivity);
    };
  }, []);

  if (!currentUser) return null;

  const isRestrictedState = RESTRICTED_INDIAN_STATES.includes(selectedState as any);
  const userBets = storageService.getBets(currentUser.id);
  const allMarkets = storageService.getMarkets();
  const userCreatedRooms = useMemo(() => {
    return storageService.getMarkets().filter((m) => m.creatorId === currentUser.id);
  }, [currentUser.id, localRefreshTrigger]);
  const userTx = useMemo(() => {
    return storageService.getTransactions(currentUser.id);
  }, [currentUser.id, localRefreshTrigger]);

  const handleDeclareOutcome = (roomId: string, side: 'YES' | 'NO') => {
    onResolveMarket(roomId, side);
    setLocalRefreshTrigger((c) => c + 1);
  };

  // PAN Uppercase Transformation handler
  const handlePanChange = (val: string) => {
    const cleaned = val.replace(/\s+/g, '').toUpperCase();
    setPanNumber(cleaned);
  };

  const handleAutoDetectLocation = async () => {
    setIsDetectingLocation(true);
    try {
      const result = await geolocationService.detectLocation();
      setSelectedState(result.state);
      setDetectionMethod(result.method === 'HTML5_GEOLOCATION' ? 'HTML5 GPS Coordinates' : 'IP Location Lookup');
      storageService.setUserDetectedState(currentUser.id, result.state);
      setKycSavedSuccess(true);
      setTimeout(() => setKycSavedSuccess(false), 3000);
    } catch {
      // Keep existing
    } finally {
      setIsDetectingLocation(false);
    }
  };

  const handleSimulateState = (st: IndianState) => {
    setSelectedState(st);
    setDetectionMethod('Manual Compliance Simulation');
    storageService.setUserDetectedState(currentUser.id, st);
    setKycSavedSuccess(true);
    setTimeout(() => setKycSavedSuccess(false), 2500);
  };

  const handleSaveKYC = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.setUserDetectedState(currentUser.id, selectedState);
    storageService.updateKYC(currentUser.id, {
      legalName: legalName.trim(),
      panNumber: panNumber.trim(),
      state: selectedState,
      city: city.trim(),
      phone: phone.trim(),
      dob,
      upiHandle: upiHandle.trim(),
      bankAccount: bankAccount.trim(),
      ifscCode: ifscCode.trim().toUpperCase(),
    });

    setKycSavedSuccess(true);
    setTimeout(() => setKycSavedSuccess(false), 3000);
  };

  const handleCopyReferral = () => {
    const refText = `Join PulseBet P2P Prediction Exchange and claim ₹50 Play Bonus using my code: ${currentUser.referralCode}\n${window.location.origin}?ref=${currentUser.referralCode}`;
    navigator.clipboard.writeText(refText);
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2000);
  };

  const handleUpdatePin = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError(null);
    setPinSuccess(null);
    if (!pinInput || !/^\d{4}$/.test(pinInput)) {
      setPinError('Security PIN must be exactly 4 numeric digits.');
      return;
    }
    if (pinInput !== pinConfirmInput) {
      setPinError('Confirmation PIN does not match.');
      return;
    }
    try {
      storageService.setWithdrawalPin(currentUser.id, pinInput);
      setPinSuccess('4-Digit Withdrawal Security PIN updated successfully!');
      setPinInput('');
      setPinConfirmInput('');
      setLocalRefreshTrigger((c) => c + 1);
      setTimeout(() => setPinSuccess(null), 3500);
    } catch (err: any) {
      setPinError(err.message || 'Failed to update PIN');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-3xl rounded-3xl bg-[#0F172A] border border-white/15 p-5 sm:p-7 shadow-2xl relative my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.displayName}
              className="w-12 h-12 rounded-2xl object-cover border-2 border-[#00F2FE]/40 shadow-[0_0_15px_rgba(0,242,254,0.3)]"
            />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">{currentUser.displayName}</h2>
                {currentUser.kyc.isVerified && (
                  <span className="flex items-center gap-1 text-[10px] bg-[#10B981]/20 text-[#10B981] px-2 py-0.5 rounded-full font-bold border border-[#10B981]/30">
                    <ShieldCheck className="w-3 h-3" />
                    Verified KYC
                  </span>
                )}
                {currentUser.isAdmin && (
                  <span className="text-[10px] bg-red-500/20 text-red-400 px-2 py-0.5 rounded-full font-bold border border-red-500/30">
                    Admin
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">{currentUser.email}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto py-3 border-b border-white/10 shrink-0 scrollbar-none text-xs font-bold">
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition ${
              activeTab === 'profile'
                ? 'bg-gradient-to-r from-[#00F2FE]/20 to-[#10B981]/20 text-[#00F2FE] border border-[#00F2FE]/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Profile & KYC
          </button>

          <button
            onClick={() => setActiveTab('trades')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'trades'
                ? 'bg-gradient-to-r from-[#00F2FE]/20 to-[#10B981]/20 text-[#00F2FE] border border-[#00F2FE]/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>My Trades ({userBets.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('rooms')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'rooms'
                ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>My Created Rooms ({userCreatedRooms.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('referrals')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'referrals'
                ? 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Gift className="w-3.5 h-3.5" />
            <span>Referrals & Rewards</span>
          </button>

          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'ledger'
                ? 'bg-white/10 text-white border border-white/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>Wallet & Ledger</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="overflow-y-auto py-4 flex-1 pr-1">
          {/* TAB 1: PROFILE & KYC COMPLETION */}
          {activeTab === 'profile' && (
            <>
            <form onSubmit={handleSaveKYC} className="space-y-4">
              {/* Geolocation Compliance Banner & Auto-Detect */}
              {isRestrictedState ? (
                <div className="p-4 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-xs text-amber-200 flex items-start gap-3 shadow-[0_0_20px_rgba(245,158,11,0.15)]">
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-extrabold text-white text-sm block">
                      ⚠️ Real-Money Trading Restricted in {selectedState}
                    </span>
                    <p className="mt-1 text-slate-300 leading-relaxed">
                      In compliance with State regulations, real-money trading is disabled for residents of <strong>{selectedState}</strong>. Your account operates in view-only feed browsing mode.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-3.5 rounded-2xl bg-[#10B981]/15 border border-[#10B981]/40 text-xs text-[#10B981] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>State Compliance Verified: Real-money trading active in {selectedState}.</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#10B981]/20 border border-[#10B981]/40 text-white font-bold">
                    PERMITTED
                  </span>
                </div>
              )}

              {/* Geolocation Auto-Detection & Compliance Test Card */}
              <div className="p-3.5 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#00F2FE]" />
                    <span className="text-xs font-bold text-white">Auto-Detect Geolocation Guard:</span>
                    <span className="text-xs font-mono font-bold text-[#00F2FE]">
                      {selectedState}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={handleAutoDetectLocation}
                    disabled={isDetectingLocation}
                    className="px-3 py-1.5 rounded-xl bg-[#00F2FE]/15 hover:bg-[#00F2FE]/30 text-[#00F2FE] border border-[#00F2FE]/40 text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50"
                  >
                    <Navigation className={`w-3.5 h-3.5 ${isDetectingLocation ? 'animate-spin' : ''}`} />
                    <span>{isDetectingLocation ? 'Locating...' : 'Auto-Detect Location (GPS / IP)'}</span>
                  </button>
                </div>

                {detectionMethod && (
                  <p className="text-[10px] text-slate-400">
                    Source: <strong className="text-white">{detectionMethod}</strong>
                  </p>
                )}

                {/* Simulation / Verification Pills */}
                <div className="pt-1 flex flex-wrap items-center gap-2 text-[10px]">
                  <span className="text-slate-400 font-medium">Compliance Test Simulation:</span>
                  <button
                    type="button"
                    onClick={() => handleSimulateState('Assam')}
                    className="px-2 py-0.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition font-semibold"
                  >
                    Test Assam (Restricted)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSimulateState('Telangana')}
                    className="px-2 py-0.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition font-semibold"
                  >
                    Test Telangana (Restricted)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSimulateState('Maharashtra')}
                    className="px-2 py-0.5 rounded-lg bg-[#10B981]/10 hover:bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/30 transition font-semibold"
                  >
                    Test Maharashtra (Allowed)
                  </button>
                </div>
              </div>

              {kycSavedSuccess && (
                <div className="p-3 rounded-2xl bg-[#10B981]/20 border border-[#10B981] text-xs text-[#10B981] flex items-center gap-2 font-bold animate-pulse">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Profile & Location Details Saved Successfully!</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Full Legal Name (as on PAN):
                  </label>
                  <input
                    type="text"
                    value={legalName}
                    onChange={(e) => setLegalName(e.target.value)}
                    placeholder="e.g. Aman Kumar Sharma"
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#00F2FE]"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    PAN Card (Auto-Uppercase Transformation):
                  </label>
                  <input
                    type="text"
                    value={panNumber}
                    onChange={(e) => handlePanChange(e.target.value)}
                    maxLength={10}
                    placeholder="ABCDE1234F"
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs font-mono tracking-widest uppercase focus:outline-none focus:border-[#00F2FE]"
                    required
                  />
                  <span className="text-[10px] text-slate-500">
                    Auto-sanitized to uppercase format (5 letters, 4 digits, 1 letter)
                  </span>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Resident State:
                  </label>
                  <select
                    value={selectedState}
                    onChange={(e) => setSelectedState(e.target.value as IndianState)}
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#00F2FE]"
                  >
                    {INDIAN_STATES.map((st) => (
                      <option key={st} value={st}>
                        {st} {RESTRICTED_INDIAN_STATES.includes(st as any) ? '(Restricted)' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Resident City:
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="e.g. Mumbai"
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#00F2FE]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Mobile Number (+91):
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98201 12345"
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#00F2FE]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Date of Birth (18+ Mandatory):
                  </label>
                  <input
                    type="date"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#00F2FE]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    UPI VPA Handle:
                  </label>
                  <input
                    type="text"
                    value={upiHandle}
                    onChange={(e) => setUpiHandle(e.target.value)}
                    placeholder="yourhandle@paytm or @ybl"
                    className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#00F2FE]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Bank Account & IFSC:
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={bankAccount}
                      onChange={(e) => setBankAccount(e.target.value)}
                      placeholder="Account No."
                      className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#00F2FE]"
                    />
                    <input
                      type="text"
                      value={ifscCode}
                      onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                      placeholder="IFSC (e.g. HDFC0001234)"
                      className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-white text-xs font-mono uppercase focus:outline-none focus:border-[#00F2FE]"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-extrabold text-xs shadow-md hover:opacity-95 transition"
                >
                  Save Profile & Update Verification Details
                </button>
              </div>
            </form>

            {/* 4-Digit Withdrawal Security PIN Card */}
            <div className="mt-6 p-4 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[#00F2FE]/15 border border-[#00F2FE]/30 flex items-center justify-center text-[#00F2FE]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">4-Digit Withdrawal Security PIN</h4>
                    <p className="text-[10px] text-slate-400">Required to authorize real-money cashouts</p>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  currentUser.withdrawalPin
                    ? 'bg-[#10B981]/15 border-[#10B981]/40 text-[#10B981]'
                    : 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                }`}>
                  {currentUser.withdrawalPin ? '🛡️ PIN Configured' : '⚠️ PIN Not Set'}
                </span>
              </div>

              {pinSuccess && (
                <div className="p-2.5 rounded-xl bg-[#10B981]/20 border border-[#10B981]/40 text-xs text-[#10B981] flex items-center gap-2 font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{pinSuccess}</span>
                </div>
              )}

              {pinError && (
                <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2 font-medium">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}

              <form onSubmit={handleUpdatePin} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-medium text-slate-300 block mb-1">
                      New 4-Digit Security PIN:
                    </label>
                    <input
                      type="password"
                      inputMode="numeric"
                      maxLength={4}
                      value={pinInput}
                      onChange={(e) => setPinInput(e.target.value.replace(/\D/g, '').slice(0, 4))}
                      placeholder="••••"
                      className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-center text-white tracking-[0.5em] text-sm font-black focus:outline-none focus:border-[#00F2FE]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-slate-300 block mb-1">
                      Confirm 4-Digit PIN:
                    </label>
                    <input
                      type="password"
                      inputMode="numeric"
                      maxLength={4}
                      value={pinConfirmInput}
                      onChange={(e) => setPinConfirmInput(e.target.value.replace(/\D/g, '').slice(0, 4))}
                      placeholder="••••"
                      className="w-full bg-[#111827] border border-white/10 rounded-xl px-3 py-2 text-center text-white tracking-[0.5em] text-sm font-black focus:outline-none focus:border-[#00F2FE]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/15 flex items-center justify-center gap-2 transition"
                >
                  <KeyRound className="w-3.5 h-3.5 text-[#00F2FE]" />
                  <span>{currentUser.withdrawalPin ? 'Update Withdrawal PIN' : 'Save 4-Digit PIN'}</span>
                </button>
              </form>
            </div>
            </>
          )}

          {/* TAB 2: MY TRADES & CASHOUT POSITION ENGINE */}
          {activeTab === 'trades' && (
            <div className="space-y-3">
              {userBets.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No trades placed yet. Explore the P2P markets and start trading with min ₹10!
                </div>
              ) : (
                userBets.map((bet) => {
                  const market = allMarkets.find((m) => m.id === bet.marketId);
                  const canCashout = bet.status === 'ACTIVE' && market?.status === 'OPEN';
                  const quote = market ? storageService.calculateCashoutQuote(bet, market) : null;

                  return (
                    <div
                      key={bet.id}
                      className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-white/20 transition"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded font-black text-[10px] ${
                              bet.side === 'YES'
                                ? 'bg-[#00F2FE]/20 text-[#00F2FE]'
                                : 'bg-rose-500/20 text-rose-400'
                            }`}
                          >
                            BET {bet.side}
                          </span>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                              bet.status === 'ACTIVE'
                                ? 'bg-[#10B981]/20 text-[#10B981]'
                                : bet.status === 'WON'
                                ? 'bg-[#F59E0B]/20 text-[#F59E0B]'
                                : bet.status === 'CASHED_OUT'
                                ? 'bg-[#00F2FE]/20 text-[#00F2FE]'
                                : 'bg-slate-700 text-slate-300'
                            }`}
                          >
                            {bet.status}
                          </span>
                          <span className="text-[10px] text-slate-500">
                            {new Date(bet.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        <p className="text-xs font-bold text-white line-clamp-1">
                          {market?.title || 'Prediction Market'}
                        </p>

                        <div className="flex items-center gap-3 text-[11px] text-slate-400">
                          <span>Amount: <strong className="text-white">₹{bet.amount}</strong></span>
                          <span>Odds at Bet: <strong className="text-white">{bet.oddsAtBet}%</strong></span>
                          {bet.payoutAmount && (
                            <span className="text-[#10B981] font-bold">
                              Payout: ₹{bet.payoutAmount}
                            </span>
                          )}
                          {bet.cashoutAmount && (
                            <span className="text-[#00F2FE] font-bold">
                              Cashed Out: ₹{bet.cashoutAmount}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Cashout / Exit Position Engine Button */}
                      {canCashout && market && (
                        <button
                          onClick={() => onOpenCashout(bet, market)}
                          className="shrink-0 flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#10B981]/20 to-[#00F2FE]/20 border border-[#10B981]/40 text-[#10B981] hover:bg-[#10B981]/30 hover:border-[#10B981] transition text-xs font-extrabold shadow-sm"
                        >
                          <Zap className="w-3.5 h-3.5 text-[#00F2FE]" />
                          <span>Cashout (Est. ₹{quote?.cashoutValue})</span>
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB 3: MY CREATED ROOMS (15% ROYALTY CREATOR PORTAL) */}
          {activeTab === 'rooms' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-[#10B981]/15 to-[#F59E0B]/15 border border-[#10B981]/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-extrabold text-white">Creator Ownership Portal</h4>
                  <p className="text-xs text-slate-300">
                    You earn a guaranteed <strong className="text-[#F59E0B]">15% Creator Royalty</strong> from the settled pool of every room you host.
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Total Rooms</span>
                  <span className="text-lg font-black text-white">{userCreatedRooms.length}</span>
                </div>
              </div>

              {userCreatedRooms.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs">
                  You haven't created any Friend Rooms yet. Launch a room with custom question and share with friends!
                </div>
              ) : (
                userCreatedRooms.map((room) => {
                  const isOpen = room.status === 'OPEN';
                  const roomBets = storageService.getBets().filter((b) => b.marketId === room.id);
                  const yesBetsCount = roomBets.filter((b) => b.side === 'YES').length;
                  const noBetsCount = roomBets.filter((b) => b.side === 'NO').length;
                  const estRoyalty = Math.round(room.totalVolume * 0.15);

                  return (
                    <div
                      key={room.id}
                      className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-white/10 text-slate-200">
                              #{room.roomCode}
                            </span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                                isOpen ? 'bg-[#10B981]/20 text-[#10B981]' : 'bg-slate-700 text-slate-300'
                              }`}
                            >
                              {room.status}
                            </span>
                            {(room.isPublic === false || room.visibility === 'private' || room.isPrivate === true) && (
                              <span className="text-[10px] bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full font-bold border border-amber-500/30 flex items-center gap-1">
                                <Lock className="w-3 h-3" />
                                <span>Private Room</span>
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                const directUrl = `${window.location.origin}?market=${room.id}`;
                                navigator.clipboard.writeText(directUrl);
                                alert('Direct link copied to clipboard!\n' + directUrl);
                              }}
                              className="text-[10px] text-[#00F2FE] hover:underline font-bold px-1.5 py-0.5 rounded bg-[#00F2FE]/10 border border-[#00F2FE]/30 cursor-pointer"
                              title="Copy direct invite link for this room"
                            >
                              Copy Link
                            </button>
                          </div>
                          <h5 className="text-xs font-bold text-white leading-snug">{room.title}</h5>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-[10px] text-slate-400 block">Est. 15% Royalty</span>
                          <span className="text-sm font-black text-[#F59E0B]">
                            {storageService.formatAmount(estRoyalty, currency)}
                          </span>
                        </div>
                      </div>

                      {/* Pool & Bets Stats */}
                      <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-[#111827] text-center text-xs">
                        <div>
                          <span className="text-[10px] text-slate-400 block">Total Volume</span>
                          <strong className="text-white">
                            {storageService.formatAmount(room.totalVolume, currency)}
                          </strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-[#00F2FE] block">YES Bets</span>
                          <strong className="text-white">{yesBetsCount}</strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-rose-400 block">NO Bets</span>
                          <strong className="text-white">{noBetsCount}</strong>
                        </div>
                      </div>

                      {/* Creator Result Declaration or Settled State */}
                      {room.status === 'RESOLVED' || room.status.startsWith('RESOLVED') ? (
                        <div className="p-3 rounded-xl bg-[#10B981]/15 border border-[#10B981]/30 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
                            <div>
                              <span className="text-xs font-bold text-white">
                                Event Concluded • [{room.winningOption || (room.status === 'RESOLVED_YES' ? 'YES' : 'NO')}] Won
                              </span>
                              <p className="text-[10px] text-slate-300">
                                Escrow payouts disbursed to all winning traders
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-[9px] text-[#10B981] font-bold block uppercase">
                              Royalty Credited
                            </span>
                            <span className="text-xs font-black text-[#10B981]">
                              +{storageService.formatAmount(estRoyalty, currency)}
                            </span>
                          </div>
                        </div>
                      ) : isOpen ? (
                        <div className="flex items-center justify-between pt-1 border-t border-white/5">
                          <span className="text-[11px] text-slate-400">
                            Declare Event Outcome:
                          </span>
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleDeclareOutcome(room.id, 'YES')}
                              className="px-3 py-1.5 rounded-xl bg-[#00F2FE]/20 hover:bg-[#00F2FE] text-[#00F2FE] hover:text-black transition text-xs font-bold border border-[#00F2FE]/40"
                            >
                              Declare YES
                            </button>
                            <button
                              onClick={() => handleDeclareOutcome(room.id, 'NO')}
                              className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500 text-rose-400 hover:text-white transition text-xs font-bold border border-rose-500/40"
                            >
                              Declare NO
                            </button>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB 4: REFERRAL & REWARDS */}
          {activeTab === 'referrals' && (
            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#F59E0B]/20 via-[#0B0F17] to-[#0F172A] border border-[#F59E0B]/40">
                <div className="flex items-center gap-2 mb-2">
                  <Gift className="w-5 h-5 text-[#F59E0B]" />
                  <h4 className="text-sm font-extrabold text-white">Invite Friends & Earn Real Cash</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Earn <strong className="text-[#10B981]">₹25 Real Cash</strong> automatically credited upon your referee's first trade. Friends also receive <strong className="text-[#00F2FE]">₹50 Promo Play Bonus</strong> upon registration!
                </p>

                <div className="mt-4 flex flex-col sm:flex-row items-center gap-2">
                  <div className="w-full bg-[#111827] border border-white/10 rounded-xl px-4 py-2.5 flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">Referral Code:</span>
                    <strong className="text-[#00F2FE] text-sm tracking-wider">{currentUser.referralCode}</strong>
                  </div>

                  <button
                    onClick={handleCopyReferral}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-[#00F2FE] hover:bg-[#00c6ff] text-black font-extrabold text-xs transition flex items-center justify-center gap-1.5 shrink-0"
                  >
                    {copiedRef ? <Check className="w-4 h-4 text-emerald-800" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedRef ? 'Copied Link' : 'Copy Invite Link'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: WALLET & TRANSACTION LEDGER */}
          {activeTab === 'ledger' && (
            <div className="space-y-4">
              {/* Balances Card */}
              <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
                      Real Balance (Withdrawable)
                    </span>
                    <span className="text-lg font-black text-[#10B981]">
                      {storageService.formatAmount(currentUser.realBalance, currency)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
                      Promo Credit (Trade-Only)
                    </span>
                    <span className="text-lg font-black text-[#00F2FE]">
                      {storageService.formatAmount(currentUser.promoBalance, currency)}
                    </span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenDeposit();
                    }}
                    className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-[#10B981] hover:bg-[#059669] text-black font-extrabold text-xs transition"
                  >
                    + Deposit (Min ₹100)
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      onOpenWithdraw();
                    }}
                    className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-[#F59E0B] hover:bg-[#d97706] text-black font-extrabold text-xs transition"
                  >
                    Withdraw (Min ₹200)
                  </button>
                </div>
              </div>

              {/* Transactions List */}
              <div className="space-y-2">
                <h5 className="text-xs font-extrabold text-white">Transaction Audit Trail</h5>
                {userTx.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">
                    No transactions recorded yet.
                  </div>
                ) : (
                  userTx.map((tx) => (
                    <div
                      key={tx.id}
                      className={`p-3.5 rounded-2xl border transition ${
                        tx.status === 'REJECTED'
                          ? 'bg-red-950/20 border-red-500/30'
                          : 'bg-[#0B0F17] border-white/5'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white">{tx.type.replace(/_/g, ' ')}</span>
                            <span
                              className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${
                                tx.status === 'COMPLETED' || tx.status === 'APPROVED'
                                  ? 'bg-[#10B981]/20 text-[#10B981]'
                                  : tx.status === 'PENDING'
                                  ? 'bg-[#F59E0B]/20 text-[#F59E0B]'
                                  : 'bg-red-500/20 text-red-400 font-black border border-red-500/40'
                              }`}
                            >
                              {tx.status}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400">{tx.notes || tx.timestamp}</p>
                        </div>

                        <div className="text-right shrink-0">
                          <span
                            className={`font-black ${
                              tx.type === 'DEPOSIT' ||
                              tx.type === 'TRADE_WIN' ||
                              tx.type === 'WINNING_PAYOUT' ||
                              tx.type === 'TRADE_CASHOUT' ||
                              tx.type === 'TRADE_REFUND' ||
                              tx.type === 'UNMATCHED_REFUND' ||
                              tx.type === 'CREATOR_ROYALTY' ||
                              tx.type === 'ROOM_ROYALTY_PAYOUT' ||
                              tx.type === 'REFERRAL_BONUS' ||
                              tx.type === 'RETENTION_BONUS' ||
                              tx.type === 'SIGNUP_PROMO'
                                ? 'text-[#10B981]'
                                : 'text-slate-300'
                            }`}
                          >
                            {tx.type === 'DEPOSIT' ||
                            tx.type === 'TRADE_WIN' ||
                            tx.type === 'WINNING_PAYOUT' ||
                            tx.type === 'TRADE_CASHOUT' ||
                            tx.type === 'TRADE_REFUND' ||
                            tx.type === 'UNMATCHED_REFUND' ||
                            tx.type === 'CREATOR_ROYALTY' ||
                            tx.type === 'ROOM_ROYALTY_PAYOUT' ||
                            tx.type === 'REFERRAL_BONUS' ||
                            tx.type === 'RETENTION_BONUS' ||
                            tx.type === 'SIGNUP_PROMO'
                              ? '+'
                              : '-'}
                            {storageService.formatAmount(tx.amount, currency)}
                          </span>
                          <span className="text-[9px] text-slate-500 block">
                            {new Date(tx.timestamp).toLocaleDateString('en-IN', {
                              month: 'short',
                              day: 'numeric',
                            })}
                          </span>
                        </div>
                      </div>

                      {/* Prominent Rejection Reason Display */}
                      {tx.status === 'REJECTED' && tx.rejectionReason && (
                        <div className="mt-2.5 p-2.5 rounded-xl bg-red-500/15 border border-red-500/40 text-xs text-red-200 flex items-start gap-2 shadow-[0_0_15px_rgba(239,68,68,0.15)]">
                          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-extrabold text-white text-xs block">
                              Payment Request Rejected
                            </span>
                            <p className="text-[11px] text-red-300 mt-0.5 leading-snug">
                              <strong>Admin Remarks: </strong>"{tx.rejectionReason}"
                            </p>
                            {tx.type === 'WITHDRAWAL' && (
                              <span className="text-[10px] text-emerald-400 font-bold mt-1 block">
                                ✓ Requested amount of {storageService.formatAmount(tx.amount, currency)} has been immediately refunded to your wallet.
                              </span>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Unmatched Trade Refund Tag */}
                      {(tx.notes?.includes('Unmatched Trade Refund') || tx.type === 'UNMATCHED_REFUND') && (
                        <div className="mt-1.5 p-2 rounded-xl bg-[#00F2FE]/10 border border-[#00F2FE]/30 text-[10px] text-[#00F2FE] flex items-center gap-1.5 font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#00F2FE] shrink-0" />
                          <span>100% Principal Returned • No opposing counter-traders placed bets</span>
                        </div>
                      )}

                      {/* Withdrawal Refund (Rejected) Tag */}
                      {tx.notes?.includes('Withdrawal Refund (Rejected)') && (
                        <div className="mt-1.5 p-2 rounded-xl bg-[#10B981]/10 border border-[#10B981]/30 text-[10px] text-[#10B981] flex items-center gap-1.5 font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981] shrink-0" />
                          <span>Withdrawal Refund (Rejected) • Funds returned to real balance</span>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
