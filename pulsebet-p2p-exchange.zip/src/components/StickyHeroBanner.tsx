import React from 'react';
import { Sparkles, ShieldCheck, Flame, ArrowRight, Zap, Trophy, Users } from 'lucide-react';
import { Currency, User } from '../types';
import { storageService } from '../services/storageService';

interface StickyHeroBannerProps {
  currentUser: User | null;
  currency: Currency;
  onOpenAuth: () => void;
  onCreateRoom: () => void;
}

export const StickyHeroBanner: React.FC<StickyHeroBannerProps> = ({
  currentUser,
  currency,
  onOpenAuth,
  onCreateRoom,
}) => {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0F172A] via-[#0B0F17] to-[#111827] border border-white/10 shadow-[0_0_50px_rgba(0,242,254,0.15)] p-5 sm:p-8 my-4">
      {/* Background glow highlights */}
      <div className="absolute -top-24 -left-24 w-72 h-72 bg-[#00F2FE]/20 rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-[#10B981]/20 rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-40 bg-[#F59E0B]/10 rounded-full blur-[90px] pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-6">
        {/* Left Copy */}
        <div className="max-w-2xl text-center lg:text-left">
          {/* Floating High-Converting Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-[#F59E0B]/20 via-[#00F2FE]/20 to-[#10B981]/20 border border-[#F59E0B]/50 shadow-[0_0_15px_rgba(245,158,11,0.3)] mb-4">
            <Flame className="w-4 h-4 text-[#F59E0B] animate-pulse" />
            <span className="text-xs sm:text-sm font-extrabold text-white tracking-wide">
              🔥 Register Now & Get <span className="text-[#00F2FE]">₹50 Play Bonus</span>
            </span>
            <span className="text-[10px] bg-black/40 text-slate-300 px-1.5 py-0.5 rounded font-mono">
              Virtual Credit
            </span>
          </div>

          <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
            The High-Speed <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-[#00F2FE] via-[#10B981] to-[#F59E0B] bg-clip-text text-transparent">
              P2P Prediction Exchange
            </span>
          </h1>

          <p className="mt-3 text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl">
            Trade peer-to-peer on Cricket, Politics, Crypto & Cinema with{' '}
            <strong className="text-white">Adaptive Parimutuel Liquidity</strong>,{' '}
            <strong className="text-[#10B981]">1.01x Principal Protection</strong>, and host custom{' '}
            <strong className="text-[#F59E0B]">Friend Rooms with 15% Creator Royalty</strong>.
          </p>

          {/* Friction-Free Operating Limits Pills */}
          <div className="mt-4 flex flex-wrap items-center justify-center lg:justify-start gap-2 text-[11px] font-semibold text-slate-300">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10">
              <Zap className="w-3.5 h-3.5 text-[#00F2FE]" />
              <span>Min Trade: <strong className="text-white">₹10</strong></span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10">
              <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
              <span>Min Deposit: <strong className="text-white">₹100</strong></span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10">
              <Trophy className="w-3.5 h-3.5 text-[#F59E0B]" />
              <span>Min Withdrawal: <strong className="text-white">₹200</strong></span>
            </div>
          </div>
        </div>

        {/* Right CTA Box */}
        <div className="shrink-0 w-full sm:w-auto flex flex-col sm:flex-row lg:flex-col gap-3">
          {!currentUser ? (
            <button
              onClick={onOpenAuth}
              className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-sm tracking-wide shadow-[0_0_30px_rgba(0,242,254,0.4)] hover:shadow-[0_0_40px_rgba(0,242,254,0.7)] transition transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <Sparkles className="w-4 h-4" />
              <span>Claim ₹50 Play Bonus Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <div className="p-4 rounded-2xl bg-[#0B0F17]/90 border border-white/10 flex flex-col gap-2 min-w-[240px]">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Your Trade Balance:</span>
                <span className="font-extrabold text-[#10B981] text-sm">
                  {storageService.formatAmount(
                    currentUser.realBalance + currentUser.promoBalance,
                    currency
                  )}
                </span>
              </div>
              <div className="text-[10px] text-slate-400">
                Promo Credit: <span className="text-[#00F2FE] font-bold">{storageService.formatAmount(currentUser.promoBalance, currency)}</span> (Usable strictly for trades)
              </div>
              <button
                onClick={onCreateRoom}
                className="mt-1 flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-gradient-to-r from-[#10B981] to-[#00F2FE] text-black font-extrabold text-xs shadow-md hover:opacity-95 transition"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Create Friend Room (15% Royalty)</span>
              </button>
            </div>
          )}

          <div className="text-center text-[11px] text-slate-400">
            ⚡ Instant Parimutuel Settlement • 🔒 100% Escrow Refund Protected
          </div>
        </div>
      </div>
    </div>
  );
};
