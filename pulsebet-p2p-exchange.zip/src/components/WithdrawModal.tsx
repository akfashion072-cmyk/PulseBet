import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  Wallet,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { Currency, User } from '../types';
import { storageService } from '../services/storageService';

interface WithdrawModalProps {
  currentUser: User | null;
  currency: Currency;
  onClose: () => void;
  onWithdrawalSubmitted: () => void;
  onOpenKYC: () => void;
}

export const WithdrawModal: React.FC<WithdrawModalProps> = ({
  currentUser,
  currency,
  onClose,
  onWithdrawalSubmitted,
  onOpenKYC,
}) => {
  const [amount, setAmount] = useState<number>(500);
  const [destination, setDestination] = useState<string>(
    currentUser?.kyc.upiHandle || ''
  );
  const [pin, setPin] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!currentUser) return null;

  const minWithdrawal = storageService.getConfig().minWithdrawalAmount;
  const isRestricted = storageService.isUserInRestrictedState(currentUser);
  const needsKYC = !currentUser.isAdmin && (!currentUser.kyc.isVerified || !currentUser.kyc.panNumber);

  const handleSubmitWithdrawal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination.trim()) {
      setErrorMsg('Please specify your UPI ID or Bank Account');
      return;
    }

    if (!pin || pin.trim().length !== 4) {
      setErrorMsg('Please enter your 4-digit Withdrawal Security PIN');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg(null);
      const tx = storageService.requestWithdrawal(currentUser.id, amount, destination.trim(), pin.trim());
      if (typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent('withdrawal_submitted', {
            detail: {
              transactionId: tx.id,
              userId: currentUser.id,
              userName: currentUser.displayName,
              amount,
              bankDetails: destination.trim(),
            },
          })
        );
        window.dispatchEvent(new CustomEvent('pending_withdrawals_updated'));
        window.dispatchEvent(new CustomEvent('balance_updated'));
        window.dispatchEvent(new Event('storage'));
      }
      setSuccess(true);
      onWithdrawalSubmitted();
    } catch (err: any) {
      setErrorMsg(err.message || 'Withdrawal failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-white/15 p-6 shadow-2xl relative my-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-[#F59E0B]/15 border border-[#F59E0B]/30 flex items-center justify-center text-[#F59E0B]">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">Withdraw Real Cash</h3>
            <p className="text-xs text-slate-400">
              Min Withdrawal: <strong className="text-white">₹{minWithdrawal}</strong> • Direct UPI & Bank
            </p>
          </div>
        </div>

        {success ? (
          <div className="py-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#10B981]/20 border border-[#10B981] text-[#10B981] flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h4 className="text-lg font-extrabold text-white">
                Withdrawal Request Queued
              </h4>
              <p className="mt-1 text-xs text-slate-300 max-w-xs mx-auto leading-relaxed">
                ₹{amount} queued for transfer to <strong>{destination}</strong>.
              </p>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-extrabold text-xs"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitWithdrawal} className="space-y-4">
            {/* Real Balance Disclosure */}
            <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-1">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Withdrawable Real Balance:</span>
                <span className="text-sm font-black text-[#10B981]">
                  {storageService.formatAmount(currentUser.realBalance, currency)}
                </span>
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-400">
                <span>Promo Credit (Virtual Bonus):</span>
                <span className="text-[#00F2FE] font-bold">
                  {storageService.formatAmount(currentUser.promoBalance, currency)} (Trade-only)
                </span>
              </div>
            </div>

            {/* KYC Guard Warning if not verified */}
            {needsKYC && (
              <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 space-y-2">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">KYC Verification Required:</span> Government regulations require PAN & state residency verification before withdrawal.
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenKYC();
                  }}
                  className="w-full py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-bold hover:bg-amber-500/30 transition"
                >
                  Complete KYC Verification Now
                </button>
              </div>
            )}

            {isRestricted && (
              <div className="p-3 rounded-2xl bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <strong>Restricted State:</strong> Real-money transactions are restricted in {currentUser.kyc.state}.
                </div>
              </div>
            )}

            {currentUser.isAdmin && (
              <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-[11px] text-red-400 flex items-center gap-1.5 font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Admin Onboarding Bypass Active: KYC checks waived</span>
              </div>
            )}

            {/* Amount */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Withdrawal Amount (Min ₹{minWithdrawal}):
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black">
                  ₹
                </span>
                <input
                  type="number"
                  min={minWithdrawal}
                  max={currentUser.realBalance}
                  value={amount || ''}
                  onChange={(e) => {
                    setAmount(Number(e.target.value));
                    setErrorMsg(null);
                  }}
                  className="w-full bg-[#111827] border border-white/15 rounded-2xl pl-9 pr-4 py-3 text-white font-black text-lg focus:outline-none focus:border-[#F59E0B]/60 transition"
                  placeholder="500"
                />
              </div>

              {/* Quick Presets */}
              <div className="grid grid-cols-3 gap-2 mt-2">
                {[200, 500, 1000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => {
                      setAmount(preset);
                      setErrorMsg(null);
                    }}
                    className={`py-1.5 rounded-xl text-xs font-bold border transition ${
                      amount === preset
                        ? 'bg-[#F59E0B]/20 border-[#F59E0B] text-[#F59E0B]'
                        : 'bg-[#111827] border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    ₹{preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Destination UPI / Bank */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300 block">
                Destination UPI ID or Bank Details:
              </label>
              <input
                type="text"
                value={destination}
                onChange={(e) => {
                  setDestination(e.target.value);
                  setErrorMsg(null);
                }}
                placeholder="e.g. yourname@okhdfcbank or A/C 9876543210"
                className="w-full bg-[#111827] border border-white/15 rounded-2xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
              />
            </div>

            {/* 4-Digit Security PIN */}
            <div className="space-y-1.5 p-3 rounded-2xl bg-white/[0.03] border border-white/10">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#00F2FE]" />
                  <span>{currentUser.withdrawalPin ? '4-Digit Security PIN:' : 'Set New 4-Digit Security PIN:'}</span>
                </label>
                {!currentUser.withdrawalPin && (
                  <span className="text-[10px] text-amber-400 font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30">
                    Setup Required
                  </span>
                )}
              </div>
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={pin}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                  setPin(val);
                  setErrorMsg(null);
                }}
                placeholder="••••"
                className="w-full bg-[#111827] border border-white/15 rounded-2xl px-4 py-2 text-center text-white tracking-[0.6em] text-lg font-black focus:outline-none focus:border-[#00F2FE]/60 transition placeholder:tracking-normal"
              />
              <p className="text-[10.5px] text-slate-400">
                {currentUser.withdrawalPin
                  ? 'Enter your 4-digit security PIN to authorize this fund payout.'
                  : 'Configure a secret 4-digit PIN to protect all future withdrawal requests.'}
              </p>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting || isRestricted || (needsKYC && !currentUser.isAdmin)}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#F59E0B] to-[#10B981] text-black font-black text-sm shadow-[0_0_20px_rgba(245,158,11,0.3)] hover:opacity-95 transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <span>Submit Withdrawal Request</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
