import { CreateFriendRoomModal } from './CreateFriendRoomModal';
export type { CreateFriendRoomModalProps as CreateMarketModalProps } from './CreateFriendRoomModal';
export { CreateFriendRoomModal as CreateMarketModal, CreateFriendRoomModal };
export default CreateFriendRoomModal;
