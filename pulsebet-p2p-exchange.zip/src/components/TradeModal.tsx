import React, { useState, useMemo } from 'react';
import {
  X,
  ShieldCheck,
  Zap,
  AlertTriangle,
  Info,
  Gift,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { BetSide, Currency, Market, User } from '../types';
import { storageService } from '../services/storageService';

interface TradeModalProps {
  market: Market | null;
  initialSide: BetSide;
  currentUser: User | null;
  currency: Currency;
  onClose: () => void;
  onOpenAuth: () => void;
  onOpenDeposit: () => void;
  onTradeSuccess: () => void;
}

export const TradeModal: React.FC<TradeModalProps> = ({
  market,
  initialSide,
  currentUser,
  currency,
  onClose,
  onOpenAuth,
  onOpenDeposit,
  onTradeSuccess,
}) => {
  const [side, setSide] = useState<BetSide>(initialSide);
  const [amount, setAmount] = useState<number>(50); // Default ₹50
  const [usePromoFirst, setUsePromoFirst] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!market) return null;

  const minTrade = storageService.getConfig().minTradeAmount;
  const isRestricted = storageService.isUserInRestrictedState(currentUser);
  const userDetectedState = storageService.getUserDetectedState(currentUser);

  const realBal = currentUser?.realBalance || 0;
  const promoBal = currentUser?.promoBalance || 0;
  const totalBal = realBal + promoBal;

  // Adaptive parimutuel quote preview
  const quote = useMemo(() => {
    return storageService.calculateParimutuelQuote(market, side, amount || minTrade);
  }, [market, side, amount, minTrade]);

  const handlePreset = (val: number) => {
    setAmount(val);
    setErrorMsg(null);
  };

  const handlePlaceTrade = () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (isRestricted) {
      setErrorMsg(
        `Trading is restricted in ${userDetectedState} under current state regulations. View-only mode active.`
      );
      return;
    }

    if (amount < minTrade) {
      setErrorMsg(`Minimum trade amount is ₹${minTrade}`);
      return;
    }

    if (amount > totalBal) {
      setErrorMsg(`Insufficient wallet balance. Total available: ₹${totalBal.toFixed(1)}`);
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg(null);
      storageService.placeTrade(currentUser.id, market.id, side, amount, usePromoFirst);
      
      // Trigger festive confetti
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#00F2FE', '#10B981', '#F59E0B'],
      });

      onTradeSuccess();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to place trade.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-white/15 p-6 shadow-2xl relative my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition p-1"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="pr-8">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-[10px] text-slate-300 font-semibold mb-2">
            <span>{market.category}</span>
            <span>•</span>
            <span>{market.isOfficialAdmin ? 'Official Market' : `Room by @${market.creatorName}`}</span>
          </div>
          <h2 className="text-base font-extrabold text-white leading-snug">
            {market.title}
          </h2>
        </div>

        {/* Geolocation Compliance Warning if Restricted State */}
        {isRestricted && (
          <div className="mt-4 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2 text-xs text-amber-300">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">State Regulatory Restriction:</span> Residents of{' '}
              <strong>{currentUser?.kyc.state}</strong> are restricted from real-money trades. View-only browsing is permitted.
            </div>
          </div>
        )}

        {/* Side Selector (YES / NO) */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <button
            type="button"
            onClick={() => setSide('YES')}
            className={`py-2.5 px-3 rounded-2xl font-black text-sm flex flex-col items-center justify-center transition border ${
              side === 'YES'
                ? 'bg-[#00F2FE] text-black border-[#00F2FE] shadow-[0_0_20px_rgba(0,242,254,0.4)]'
                : 'bg-[#111827] text-slate-300 border-white/10 hover:border-[#00F2FE]/40'
            }`}
          >
            <span>BUY YES</span>
            {market.yesMeaning && (
              <span className={`text-[10px] font-medium truncate max-w-full leading-tight ${side === 'YES' ? 'text-black' : 'text-slate-300'}`}>
                {market.yesMeaning}
              </span>
            )}
            <span className={`text-[11px] font-semibold mt-0.5 ${side === 'YES' ? 'text-black' : 'text-[#00F2FE]'}`}>
              {quote.yesProbability}% Prob
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSide('NO')}
            className={`py-2.5 px-3 rounded-2xl font-black text-sm flex flex-col items-center justify-center transition border ${
              side === 'NO'
                ? 'bg-rose-500 text-white border-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.4)]'
                : 'bg-[#111827] text-slate-300 border-white/10 hover:border-rose-500/40'
            }`}
          >
            <span>BUY NO</span>
            {market.noMeaning && (
              <span className={`text-[10px] font-medium truncate max-w-full leading-tight ${side === 'NO' ? 'text-white' : 'text-slate-300'}`}>
                {market.noMeaning}
              </span>
            )}
            <span className={`text-[11px] font-semibold mt-0.5 ${side === 'NO' ? 'text-white' : 'text-rose-400'}`}>
              {quote.noProbability}% Prob
            </span>
          </button>
        </div>

        {/* Amount Input & Presets */}
        <div className="mt-5 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-medium">Trade Amount (Min ₹{minTrade}):</span>
            {currentUser && (
              <span className="text-slate-400">
                Wallet Available: <strong className="text-white">{storageService.formatAmount(totalBal, currency)}</strong>
              </span>
            )}
          </div>

          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
              ₹
            </span>
            <input
              type="number"
              min={minTrade}
              value={amount || ''}
              onChange={(e) => {
                setAmount(Number(e.target.value));
                setErrorMsg(null);
              }}
              className="w-full bg-[#111827] border border-white/15 rounded-2xl pl-9 pr-4 py-3 text-white font-extrabold text-lg focus:outline-none focus:border-[#00F2FE]/60 transition"
              placeholder="Enter amount (e.g. 100)"
            />
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-2 pt-1">
            {[10, 50, 100, 250, 500].map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => handlePreset(preset)}
                className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition ${
                  amount === preset
                    ? 'bg-white/20 border-white/40 text-white'
                    : 'bg-[#111827] border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                ₹{preset}
              </button>
            ))}
          </div>
        </div>

        {/* Promo Bonus Toggle if user has Promo Balance */}
        {currentUser && promoBal > 0 && (
          <div className="mt-4 p-3 rounded-2xl bg-gradient-to-r from-[#00F2FE]/10 to-[#10B981]/10 border border-[#00F2FE]/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Gift className="w-4 h-4 text-[#00F2FE]" />
              <div>
                <p className="font-bold text-white">Use ₹{promoBal} Promo Bonus First</p>
                <p className="text-[10px] text-slate-400">Trade-only virtual credit saved for wagers</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={usePromoFirst}
              onChange={(e) => setUsePromoFirst(e.target.checked)}
              className="w-4 h-4 accent-[#00F2FE] cursor-pointer"
            />
          </div>
        )}

        {/* Trade Modal Transparency Disclosure: Adaptive Parimutuel Calculations */}
        <div className="mt-5 p-4 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-2 text-xs">
          <div className="flex justify-between items-center text-slate-300">
            <span className="flex items-center gap-1 text-slate-400">
              <Info className="w-3.5 h-3.5" />
              <span>Est. Win Payout:</span>
            </span>
            <span className="font-black text-sm text-[#10B981]">
              ₹{quote.estimatedWinPayout} ({quote.multiplier}x Net)
            </span>
          </div>

          {/* Explicit Fee Breakdown */}
          <div className="flex justify-between items-center text-[11px] text-slate-400 border-t border-white/5 pt-2">
            <span>Adaptive Engine Fee:</span>
            <span>
              {quote.isUserRoom
                ? `${quote.houseFeePercent}% Platform + ${quote.royaltyPercent}% Creator Royalty`
                : `${quote.houseFeePercent}% Platform Fee`}
            </span>
          </div>

          {/* 1.01x Principal Guarantee Badge */}
          <div className="flex items-center gap-1.5 text-[10px] text-[#00F2FE] pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-[#00F2FE] shrink-0" />
            <span>
              <strong>1.01x Principal Protection Guaranteed:</strong> Heavy one-sided fees capped to safeguard initial stake.
            </span>
          </div>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="mt-3 p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400 flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* State Compliance Guard Banner */}
        {isRestricted && (
          <div className="mt-3 p-3 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-xs text-amber-200 flex items-center gap-2 shadow-[0_0_15px_rgba(245,158,11,0.1)]">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <div>
              <span className="font-extrabold text-amber-300">
                ⚠️ Real-Money Trading Restricted in {userDetectedState}
              </span>
              <p className="text-[10px] text-slate-300 mt-0.5">
                Trading buttons are disabled under state regulations. You may browse markets in view-only mode.
              </p>
            </div>
          </div>
        )}

        {/* Submit Actions */}
        <div className="mt-6 flex flex-col gap-2">
          {!currentUser ? (
            <button
              type="button"
              onClick={onOpenAuth}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-sm shadow-[0_0_20px_rgba(0,242,254,0.4)]"
            >
              Sign In to Place ₹{amount} Trade
            </button>
          ) : totalBal < amount ? (
            <div className="space-y-2">
              <button
                type="button"
                onClick={onOpenDeposit}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#F59E0B] to-[#10B981] text-black font-black text-sm shadow-[0_0_20px_rgba(245,158,11,0.4)]"
              >
                Deposit Funds (Min ₹100)
              </button>
              <p className="text-center text-[11px] text-slate-400">
                You need ₹{(amount - totalBal).toFixed(1)} more to place this bet.
              </p>
            </div>
          ) : (
            <button
              type="button"
              disabled={isSubmitting || isRestricted}
              onClick={handlePlaceTrade}
              className={`w-full py-3.5 rounded-2xl font-black text-sm transition flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed ${
                side === 'YES'
                  ? 'bg-gradient-to-r from-[#00F2FE] to-[#00c6ff] text-black shadow-[0_0_20px_rgba(0,242,254,0.3)]'
                  : 'bg-gradient-to-r from-rose-500 to-rose-600 text-white shadow-[0_0_20px_rgba(244,63,94,0.3)]'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>Confirm ₹{amount} Bet on [{side}]</span>
            </button>
          )}

          <p className="text-center text-[10px] text-slate-500">
            Trades lock in Parimutuel escrow. Instant payout upon verified settlement.
          </p>
        </div>
      </div>
    </div>
  );
};
