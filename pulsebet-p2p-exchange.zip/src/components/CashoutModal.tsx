import React, { useState } from 'react';
import { X, Zap, TrendingUp, TrendingDown, AlertCircle, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Market, MarketBet } from '../types';
import { storageService } from '../services/storageService';

interface CashoutModalProps {
  bet: MarketBet | null;
  market: Market | null;
  onClose: () => void;
  onCashoutSuccess: () => void;
}

export const CashoutModal: React.FC<CashoutModalProps> = ({
  bet,
  market,
  onClose,
  onCashoutSuccess,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!bet || !market) return null;

  const quote = storageService.calculateCashoutQuote(bet, market);
  const isProfit = quote.profitLoss >= 0;

  const handleCashout = () => {
    try {
      setIsProcessing(true);
      setErrorMsg(null);
      storageService.executeCashout(bet.id);

      if (isProfit) {
        confetti({
          particleCount: 50,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#10B981', '#00F2FE', '#F59E0B'],
        });
      }

      onCashoutSuccess();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to execute cashout.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="w-full max-w-sm rounded-3xl bg-[#0F172A] border border-white/15 p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-xl bg-[#00F2FE]/15 border border-[#00F2FE]/30 flex items-center justify-center text-[#00F2FE]">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white">Early Cashout Engine</h3>
            <p className="text-[10px] text-slate-400">Lock in your position before settlement</p>
          </div>
        </div>

        <p className="text-xs font-semibold text-slate-200 line-clamp-2 mb-4 bg-[#0B0F17] p-2.5 rounded-xl border border-white/5">
          {market.title}
        </p>

        {/* Position Comparison */}
        <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-3">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400">Your Position:</span>
            <span
              className={`font-black px-2 py-0.5 rounded text-xs ${
                bet.side === 'YES' ? 'bg-[#00F2FE]/20 text-[#00F2FE]' : 'bg-rose-500/20 text-rose-400'
              }`}
            >
              BET {bet.side} (₹{bet.amount})
            </span>
          </div>

          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400">Probability Shift:</span>
            <span className="font-mono text-slate-300">
              {bet.oddsAtBet}% ➔ <strong className="text-white">{quote.currentProb}%</strong>
            </span>
          </div>

          <div className="border-t border-white/10 pt-3 flex justify-between items-center">
            <span className="text-xs text-slate-400">Instant Cashout Value:</span>
            <span className="text-lg font-black text-white">
              ₹{quote.cashoutValue}
            </span>
          </div>

          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400">Net Return (P/L):</span>
            <span
              className={`font-black flex items-center gap-1 ${
                isProfit ? 'text-[#10B981]' : 'text-rose-400'
              }`}
            >
              {isProfit ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              {isProfit ? '+' : ''}₹{quote.profitLoss}
            </span>
          </div>
        </div>

        {errorMsg && (
          <div className="mt-3 p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <div className="mt-5 space-y-2">
          <button
            disabled={isProcessing || !quote.canCashout}
            onClick={handleCashout}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#10B981] to-[#00F2FE] text-black font-black text-xs shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:opacity-95 transition flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Confirm Cashout for ₹{quote.cashoutValue}</span>
          </button>

          <p className="text-center text-[10px] text-slate-400">
            Funds will be instantly returned to your withdrawable real balance.
          </p>
        </div>
      </div>
    </div>
  );
};
