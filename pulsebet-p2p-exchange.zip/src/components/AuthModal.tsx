import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  ShieldCheck,
  Zap,
  ArrowRight,
  AlertTriangle,
  Gift,
  Navigation,
  Lock,
  Mail,
  Phone,
  KeyRound,
  CheckCircle2,
  ArrowLeft,
  Eye,
  EyeOff,
  RotateCw,
} from 'lucide-react';
import { IndianState, RESTRICTED_INDIAN_STATES } from '../types';
import { storageService } from '../services/storageService';
import { geolocationService } from '../services/geolocationService';

interface AuthModalProps {
  onClose: () => void;
  onLoginSuccess: () => void;
}

const INDIAN_STATES: IndianState[] = [
  'Maharashtra',
  'Delhi',
  'Karnataka',
  'Tamil Nadu',
  'Uttar Pradesh',
  'Gujarat',
  'West Bengal',
  'Rajasthan',
  'Punjab',
  'Haryana',
  'Kerala',
  'Goa',
  'Madhya Pradesh',
  'Bihar',
  'Assam',
  'Telangana',
  'Odisha',
  'Nagaland',
  'Sikkim',
  'Andhra Pradesh',
  'Other',
];

type AuthView = 'SIGN_IN' | 'REGISTER' | 'REGISTER_OTP' | 'FORGOT_PASSWORD' | 'RESET_PASSWORD';

export const AuthModal: React.FC<AuthModalProps> = ({ onClose, onLoginSuccess }) => {
  const [view, setView] = useState<AuthView>('SIGN_IN');

  // Sign In State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Registration State
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regMobile, setRegMobile] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regReferralCode, setRegReferralCode] = useState('');
  const [selectedState, setSelectedState] = useState<IndianState>('Maharashtra');
  const [isAge18Plus, setIsAge18Plus] = useState(true);

  // Clean 6-Digit Individual Fields for Production PIN Input
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [localOtpCode, setLocalOtpCode] = useState<string>('');
  const [resendCountdown, setResendCountdown] = useState<number>(30);
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Password Reset OTP State
  const [resetEmail, setResetEmail] = useState('');
  const [resetOtpDigits, setResetOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const resetOtpInputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  // Auto-Detect Location State
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [detectionSource, setDetectionSource] = useState<string | null>(null);

  // Status Alerts
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const isRestrictedState = RESTRICTED_INDIAN_STATES.includes(selectedState as any);

  // Countdown Timer for Resending Verification Code (30 seconds)
  useEffect(() => {
    let interval: any = null;
    if ((view === 'REGISTER_OTP' || view === 'RESET_PASSWORD') && resendCountdown > 0) {
      interval = setInterval(() => {
        setResendCountdown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [view, resendCountdown]);

  // Digit Input Navigation and Paste Handlers
  const handleDigitChange = (index: number, val: string, isReset = false) => {
    const clean = val.replace(/\D/g, '');
    const current = isReset ? resetOtpDigits : otpDigits;
    const setter = isReset ? setResetOtpDigits : setOtpDigits;
    const refs = isReset ? resetOtpInputRefs : otpInputRefs;

    if (!clean) {
      const next = [...current];
      next[index] = '';
      setter(next);
      return;
    }

    const next = [...current];
    next[index] = clean.slice(-1);
    setter(next);
    setErrorMsg(null);

    // Auto-advance to next input box
    if (index < 5) {
      refs.current[index + 1]?.focus();
    }
  };

  const handleDigitKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>,
    isReset = false
  ) => {
    const current = isReset ? resetOtpDigits : otpDigits;
    const refs = isReset ? resetOtpInputRefs : otpInputRefs;

    if (e.key === 'Backspace') {
      if (!current[index] && index > 0) {
        refs.current[index - 1]?.focus();
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      refs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < 5) {
      refs.current[index + 1]?.focus();
    }
  };

  const handleDigitPaste = (
    e: React.ClipboardEvent<HTMLInputElement>,
    isReset = false
  ) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (!pasted) return;

    const setter = isReset ? setResetOtpDigits : setOtpDigits;
    const refs = isReset ? resetOtpInputRefs : otpInputRefs;
    const next = ['', '', '', '', '', ''];
    for (let i = 0; i < pasted.length; i++) {
      next[i] = pasted[i];
    }
    setter(next);
    setErrorMsg(null);
    const target = Math.min(pasted.length, 5);
    refs.current[target]?.focus();
  };

  // Auto-Detect Location on Mount via HTML5 Geolocation with IP lookup fallback
  useEffect(() => {
    let active = true;
    const runDetection = async () => {
      setIsDetectingLocation(true);
      try {
        const result = await geolocationService.detectLocation();
        if (active) {
          setSelectedState(result.state);
          setDetectionSource(result.method === 'HTML5_GEOLOCATION' ? 'HTML5 GPS' : 'IP Network Lookup');
        }
      } catch {
        // Fallback default
      } finally {
        if (active) setIsDetectingLocation(false);
      }
    };
    runDetection();
    return () => {
      active = false;
    };
  }, []);

  const handleTriggerAutoDetect = async () => {
    setIsDetectingLocation(true);
    try {
      const result = await geolocationService.detectLocation();
      setSelectedState(result.state);
      setDetectionSource(result.method === 'HTML5_GEOLOCATION' ? 'HTML5 GPS' : 'IP Network Lookup');
    } catch {
      // Keep existing
    } finally {
      setIsDetectingLocation(false);
    }
  };

  const handleSimulateState = (st: IndianState) => {
    setSelectedState(st);
    setDetectionSource('Manual Compliance Test');
  };

  // Quick 1-Click Demo Logins
  const handleQuickAdminLogin = () => {
    try {
      storageService.loginWithPassword('admin@pulsebet.com', 'Admin@123');
      onLoginSuccess();
      onClose();
    } catch {
      storageService.loginUser('admin@pulsebet.com', 'Chief Administrator', undefined, 'Delhi');
      onLoginSuccess();
      onClose();
    }
  };

  const handleQuickDemoUser = () => {
    try {
      storageService.loginWithPassword('aman.trader@gmail.com', 'Aman@123');
      onLoginSuccess();
      onClose();
    } catch {
      storageService.loginUser('aman.trader@gmail.com', 'Aman Sharma', undefined, selectedState);
      onLoginSuccess();
      onClose();
    }
  };

  // 1. Sign In Submission
  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!loginEmail.trim() || !loginEmail.includes('@')) {
      setErrorMsg('Please enter a valid email address');
      return;
    }

    try {
      storageService.loginWithPassword(loginEmail, loginPassword);
      onLoginSuccess();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication failed. Please verify credentials.');
    }
  };

  // 2. Step 1 of Registration: Validate details and generate local OTP code
  const handleInitiateRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!regFullName.trim()) {
      setErrorMsg('Please enter your full legal name');
      return;
    }

    if (!regEmail.trim() || !regEmail.includes('@')) {
      setErrorMsg('Please enter a valid email address');
      return;
    }

    const cleanPhone = regMobile.replace(/\D/g, '');
    const tenDigit = cleanPhone.length === 12 && cleanPhone.startsWith('91') ? cleanPhone.slice(2) : cleanPhone;
    if (tenDigit.length !== 10 || !/^[6-9]\d{9}$/.test(tenDigit)) {
      setErrorMsg('Please enter a valid 10-digit Indian mobile number (e.g. 98201 12345)');
      return;
    }

    if (!regPassword || regPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters long');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMsg('Passwords do not match');
      return;
    }

    if (!isAge18Plus) {
      setErrorMsg('You must be 18 years of age or older to participate');
      return;
    }

    try {
      // Generate clean 6-digit numeric OTP without mandatory env blocks or popups
      const code = storageService.generateOtp(regEmail, 'REGISTER', {
        fullName: regFullName,
        phone: tenDigit,
        password: regPassword,
        state: selectedState,
        referralCode: regReferralCode,
      });

      setLocalOtpCode(code);
      setOtpDigits(['', '', '', '', '', '']);
      setResendCountdown(30);
      setView('REGISTER_OTP');
      setTimeout(() => otpInputRefs.current[0]?.focus(), 150);
    } catch (err: any) {
      setErrorMsg(err.message || 'Could not initiate registration');
    }
  };

  // 3. Step 2 of Registration: Strict OTP Verification
  // Blocks account initialization, user session creation, and ₹50 welcome bonus until exact match
  const handleVerifyRegisterOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const enteredCode = otpDigits.join('').trim();
    if (enteredCode.length !== 6) {
      setErrorMsg('Please enter all 6 digits of your verification PIN.');
      return;
    }

    const result = storageService.verifyOtp(regEmail, enteredCode, 'REGISTER');
    if (!result.valid) {
      setErrorMsg('Invalid verification PIN. Please enter the exact matching 6-digit code to proceed.');
      return; // STRICT BLOCK
    }

    try {
      // ONLY now initialize account, create user session, and credit ₹50 welcome bonus
      storageService.registerUser({
        email: regEmail,
        password: regPassword,
        displayName: regFullName,
        phone: regMobile,
        detectedState: selectedState,
        referralCode: regReferralCode,
      });

      onLoginSuccess();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to complete registration');
    }
  };

  // Resend OTP for Registration
  const handleResendRegisterOtp = () => {
    if (resendCountdown > 0) return;
    try {
      const code = storageService.generateOtp(regEmail, 'REGISTER');
      setLocalOtpCode(code);
      setOtpDigits(['', '', '', '', '', '']);
      setResendCountdown(30);
      setErrorMsg(null);
      setSuccessMsg('A fresh 6-digit verification PIN has been generated.');
      setTimeout(() => setSuccessMsg(null), 3500);
      otpInputRefs.current[0]?.focus();
    } catch (e: any) {
      setErrorMsg(e.message || 'Failed to resend code');
    }
  };

  // 4. Request Password Reset OTP
  const handleRequestResetOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!resetEmail.trim() || !resetEmail.includes('@')) {
      setErrorMsg('Please enter a registered email address');
      return;
    }

    try {
      const code = storageService.generateOtp(resetEmail, 'RESET_PASSWORD');
      setLocalOtpCode(code);
      setResetOtpDigits(['', '', '', '', '', '']);
      setResendCountdown(30);
      setView('RESET_PASSWORD');
      setTimeout(() => resetOtpInputRefs.current[0]?.focus(), 150);
    } catch (err: any) {
      setErrorMsg(err.message || 'Password reset request failed');
    }
  };

  // 5. Submit New Password with OTP
  const handleFinalizeResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const enteredCode = resetOtpDigits.join('').trim();
    if (enteredCode.length !== 6) {
      setErrorMsg('Please enter the complete 6-digit verification PIN');
      return;
    }

    if (!newPassword || newPassword.length < 6) {
      setErrorMsg('New password must be at least 6 characters long');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setErrorMsg('Password confirmation does not match');
      return;
    }

    try {
      storageService.resetPasswordWithOTP(resetEmail, enteredCode, newPassword);
      setSuccessMsg('Password reset successful! You can now sign in with your new password.');
      setLoginEmail(resetEmail);
      setLoginPassword('');
      setView('SIGN_IN');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to reset password');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-white/15 p-5 sm:p-7 shadow-2xl relative my-auto max-h-[92vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#00F2FE]/10 border border-[#00F2FE]/30 text-[#00F2FE] text-xs font-bold mb-2">
            <Gift className="w-3.5 h-3.5" />
            <span>₹50 Play Bonus On Sign-up</span>
          </div>

          <h2 className="text-xl font-black text-white">
            {view === 'SIGN_IN' && 'Sign In to PulseBet'}
            {view === 'REGISTER' && 'Create Your Trader Account'}
            {view === 'REGISTER_OTP' && 'Verify Your Email'}
            {view === 'FORGOT_PASSWORD' && 'Reset Account Password'}
            {view === 'RESET_PASSWORD' && 'Create New Password'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Friction-Free P2P Prediction Exchange • Min Trade ₹10
          </p>
        </div>

        {/* Global Success / Error Message Banner */}
        {successMsg && (
          <div className="mb-3 p-3 rounded-2xl bg-[#10B981]/20 border border-[#10B981] text-xs text-[#10B981] flex items-center gap-2 font-bold animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {errorMsg && (
          <div className="mb-3 p-3 rounded-2xl bg-red-500/15 border border-red-500/40 text-xs text-red-400 flex items-center gap-2 font-medium animate-in fade-in">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        <div className="overflow-y-auto flex-1 pr-1 space-y-4">
          {/* ======================================================== */}
          {/* 1. SIGN IN VIEW                                          */}
          {/* ======================================================== */}
          {view === 'SIGN_IN' && (
            <div className="space-y-4">
              {/* Quick Login Bar with Quick Admin Login */}
              <div className="p-3 rounded-2xl bg-[#0B0F17] border border-white/10 space-y-2">
                <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block">
                  1-Click Demo Profiles:
                </span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleQuickAdminLogin}
                    className="flex-1 py-2 rounded-xl bg-red-500/20 hover:bg-red-500 text-red-400 hover:text-white font-extrabold text-xs transition border border-red-500/30 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5 text-red-400" />
                    <span>⚡ Quick Admin</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleQuickDemoUser}
                    className="flex-1 py-2 rounded-xl bg-[#00F2FE]/10 hover:bg-[#00F2FE]/20 text-[#00F2FE] font-bold text-xs transition border border-[#00F2FE]/30 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>Demo Trader</span>
                  </button>
                </div>
              </div>

              <form onSubmit={handleSignIn} className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Email Address:
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={loginEmail}
                      onChange={(e) => {
                        setLoginEmail(e.target.value);
                        setErrorMsg(null);
                      }}
                      placeholder="e.g. yourname@gmail.com"
                      className="w-full bg-[#111827] border border-white/15 rounded-xl pl-10 pr-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                      required
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-semibold text-slate-300">
                      Password:
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setResetEmail(loginEmail);
                        setView('FORGOT_PASSWORD');
                      }}
                      className="text-[11px] text-[#00F2FE] hover:underline font-semibold cursor-pointer"
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={loginPassword}
                      onChange={(e) => {
                        setLoginPassword(e.target.value);
                        setErrorMsg(null);
                      }}
                      placeholder="Enter your password"
                      className="w-full bg-[#111827] border border-white/15 rounded-xl pl-10 pr-10 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-sm shadow-[0_0_20px_rgba(0,242,254,0.3)] hover:opacity-95 transition flex items-center justify-center gap-2 mt-2 cursor-pointer"
                >
                  <span>Sign In</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              <div className="pt-2 text-center border-t border-white/10">
                <p className="text-xs text-slate-400">
                  Don't have an account yet?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMsg(null);
                      setView('REGISTER');
                    }}
                    className="text-[#00F2FE] font-bold hover:underline cursor-pointer"
                  >
                    Register & Claim ₹50 Bonus
                  </button>
                </p>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* 2. REGISTER VIEW                                         */}
          {/* ======================================================== */}
          {view === 'REGISTER' && (
            <form onSubmit={handleInitiateRegistration} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Full Name:
                </label>
                <input
                  type="text"
                  value={regFullName}
                  onChange={(e) => setRegFullName(e.target.value)}
                  placeholder="e.g. Aman Sharma"
                  className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Email Address:
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="e.g. aman@gmail.com"
                    className="w-full bg-[#111827] border border-white/15 rounded-xl pl-10 pr-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Mobile Number (+91 10-Digit):
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={regMobile}
                    onChange={(e) => setRegMobile(e.target.value)}
                    maxLength={14}
                    placeholder="e.g. 98201 12345"
                    className="w-full bg-[#111827] border border-white/15 rounded-xl pl-10 pr-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                    required
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Must start with 6, 7, 8, or 9
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Password:
                  </label>
                  <input
                    type="password"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Confirm Password:
                  </label>
                  <input
                    type="password"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                    required
                  />
                </div>
              </div>

              {/* Resident State Geolocation Compliance */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Resident Indian State:
                  </label>
                  <button
                    type="button"
                    onClick={handleTriggerAutoDetect}
                    disabled={isDetectingLocation}
                    className="text-[10px] text-[#00F2FE] hover:underline flex items-center gap-1 font-bold disabled:opacity-50 cursor-pointer"
                  >
                    <Navigation className={`w-3 h-3 ${isDetectingLocation ? 'animate-spin' : ''}`} />
                    <span>{isDetectingLocation ? 'Locating...' : 'Auto-Detect (GPS/IP)'}</span>
                  </button>
                </div>
                <select
                  value={selectedState}
                  onChange={(e) => {
                    setSelectedState(e.target.value as IndianState);
                    setDetectionSource('Manual Selection');
                  }}
                  className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                >
                  {INDIAN_STATES.map((st) => (
                    <option key={st} value={st}>
                      {st} {RESTRICTED_INDIAN_STATES.includes(st as any) ? '(⚠️ Restricted State)' : ''}
                    </option>
                  ))}
                </select>
                {detectionSource && (
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Location Detected via: <strong className="text-white">{detectionSource}</strong>
                  </span>
                )}

                {/* Quick Test Simulation Pills */}
                <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[10px]">
                  <span className="text-slate-500 font-medium">Test State Guard:</span>
                  <button
                    type="button"
                    onClick={() => handleSimulateState('Assam')}
                    className="px-2 py-0.5 rounded bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 transition font-bold cursor-pointer"
                  >
                    Simulate Assam (Restricted)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSimulateState('Maharashtra')}
                    className="px-2 py-0.5 rounded bg-[#10B981]/15 hover:bg-[#10B981]/25 text-[#10B981] border border-[#10B981]/30 transition font-bold cursor-pointer"
                  >
                    Simulate Maharashtra (Permitted)
                  </button>
                </div>

                {/* Prominent Compliance Badge */}
                {isRestrictedState ? (
                  <div className="mt-2 p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-xs text-amber-200 flex items-start gap-2 shadow-[0_0_15px_rgba(245,158,11,0.1)]">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                    <div>
                      <span className="font-extrabold text-amber-300 block">
                        ⚠️ Real-Money Trading Restricted in {selectedState}
                      </span>
                      <p className="text-[10px] text-slate-300 mt-0.5 leading-snug">
                        Trading buttons will be automatically disabled while retaining full view-only feed browsing.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="mt-2 p-2 rounded-xl bg-[#10B981]/10 border border-[#10B981]/30 text-[10px] text-[#10B981] flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                    <span>P2P Real-Money Trading Permitted in {selectedState}.</span>
                  </div>
                )}
              </div>

              {/* Referral Code */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Referral Code (Optional):
                </label>
                <input
                  type="text"
                  value={regReferralCode}
                  onChange={(e) => setRegReferralCode(e.target.value.toUpperCase())}
                  placeholder="e.g. AMAN2026"
                  className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs font-mono uppercase focus:outline-none focus:border-[#00F2FE]/60 transition"
                />
              </div>

              {/* 18+ Checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="reg-age-18"
                  checked={isAge18Plus}
                  onChange={(e) => setIsAge18Plus(e.target.checked)}
                  className="w-4 h-4 accent-[#00F2FE] cursor-pointer"
                />
                <label htmlFor="reg-age-18" className="text-[11px] text-slate-300 cursor-pointer">
                  I certify that I am <strong>18 years of age or older</strong> and agree to Terms of Service.
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-sm shadow-[0_0_20px_rgba(0,242,254,0.3)] hover:opacity-95 transition flex items-center justify-center gap-2 mt-2 cursor-pointer"
              >
                <span>Continue to 6-Digit PIN Verification</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-2 text-center border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setErrorMsg(null);
                    setView('SIGN_IN');
                  }}
                  className="text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Already have an account? <strong className="text-[#00F2FE]">Sign In</strong>
                </button>
              </div>
            </form>
          )}

          {/* ======================================================== */}
          {/* 3. REGISTER OTP VERIFICATION VIEW (CLEAN 6-DIGIT PIN UI) */}
          {/* ======================================================== */}
          {view === 'REGISTER_OTP' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 text-center space-y-1">
                <p className="text-xs font-bold text-white">Enter 6-Digit Security PIN</p>
                <p className="text-[11px] text-slate-400">
                  Verification PIN sent for <strong className="text-white">{regEmail}</strong>
                </p>
                {localOtpCode && (
                  <div className="pt-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#00F2FE]/10 border border-[#00F2FE]/30 text-[11px] text-[#00F2FE] font-mono">
                      <span>Verification PIN:</span>
                      <strong className="tracking-widest font-black text-white">{localOtpCode}</strong>
                    </span>
                  </div>
                )}
              </div>

              <form onSubmit={handleVerifyRegisterOtp} className="space-y-4">
                {/* Clean 6-Digit Individual Input UI */}
                <div className="flex justify-center gap-2 sm:gap-2.5 py-1">
                  {otpDigits.map((digit, idx) => (
                    <input
                      key={idx}
                      ref={(el) => {
                        otpInputRefs.current[idx] = el;
                      }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleDigitChange(idx, e.target.value, false)}
                      onKeyDown={(e) => handleDigitKeyDown(idx, e, false)}
                      onPaste={(e) => handleDigitPaste(e, false)}
                      className="w-11 h-13 sm:w-12 sm:h-14 bg-[#111827] border border-white/20 focus:border-[#00F2FE] rounded-2xl text-center text-xl sm:text-2xl font-black text-white focus:outline-none focus:ring-2 focus:ring-[#00F2FE]/40 transition shadow-inner"
                    />
                  ))}
                </div>

                <p className="text-center text-[10px] text-slate-500">
                  Strict Verification: Complete all 6 digits to authorize account creation & unlock ₹50 bonus.
                </p>

                <button
                  type="submit"
                  disabled={otpDigits.some((d) => !d)}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-sm shadow-[0_0_20px_rgba(0,242,254,0.3)] hover:opacity-95 transition flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Verify PIN & Activate Account (+₹50 Bonus)</span>
                </button>
              </form>

              <div className="flex items-center justify-between pt-1 text-xs">
                <button
                  type="button"
                  disabled={resendCountdown > 0}
                  onClick={handleResendRegisterOtp}
                  className="text-slate-400 hover:text-white disabled:opacity-50 flex items-center gap-1 cursor-pointer"
                >
                  <RotateCw className="w-3 h-3" />
                  <span>Resend PIN {resendCountdown > 0 ? `(${resendCountdown}s)` : ''}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setErrorMsg(null);
                    setView('REGISTER');
                  }}
                  className="text-[#00F2FE] hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Edit Details</span>
                </button>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* 4. FORGOT PASSWORD REQUEST VIEW                          */}
          {/* ======================================================== */}
          {view === 'FORGOT_PASSWORD' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-300">
                Enter your registered PulseBet account email to receive a password recovery verification PIN.
              </p>

              <form onSubmit={handleRequestResetOtp} className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Registered Email Address:
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={resetEmail}
                      onChange={(e) => {
                        setResetEmail(e.target.value);
                        setErrorMsg(null);
                      }}
                      placeholder="e.g. yourname@gmail.com"
                      className="w-full bg-[#111827] border border-white/15 rounded-xl pl-10 pr-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-sm shadow-[0_0_20px_rgba(0,242,254,0.3)] hover:opacity-95 transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>Send Password Reset PIN</span>
                </button>
              </form>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setErrorMsg(null);
                    setView('SIGN_IN');
                  }}
                  className="text-xs text-slate-400 hover:text-white flex items-center justify-center gap-1.5 mx-auto font-semibold cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Sign In</span>
                </button>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* 5. RESET PASSWORD & CONFIRM VIEW (CLEAN 6-DIGIT PIN UI)  */}
          {/* ======================================================== */}
          {view === 'RESET_PASSWORD' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#0B0F17] border border-white/10 text-center space-y-1">
                <p className="text-xs font-bold text-white">Enter Recovery PIN</p>
                <p className="text-[11px] text-slate-400">
                  Security PIN generated for <strong className="text-white">{resetEmail}</strong>
                </p>
                {localOtpCode && (
                  <div className="pt-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#00F2FE]/10 border border-[#00F2FE]/30 text-[11px] text-[#00F2FE] font-mono">
                      <span>Recovery PIN:</span>
                      <strong className="tracking-widest font-black text-white">{localOtpCode}</strong>
                    </span>
                  </div>
                )}
              </div>

              <form onSubmit={handleFinalizeResetPassword} className="space-y-3">
                {/* 6 Digit PIN Boxes */}
                <div className="flex justify-center gap-2 sm:gap-2.5 py-1">
                  {resetOtpDigits.map((digit, idx) => (
                    <input
                      key={idx}
                      ref={(el) => {
                        resetOtpInputRefs.current[idx] = el;
                      }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleDigitChange(idx, e.target.value, true)}
                      onKeyDown={(e) => handleDigitKeyDown(idx, e, true)}
                      onPaste={(e) => handleDigitPaste(e, true)}
                      className="w-11 h-13 sm:w-12 sm:h-14 bg-[#111827] border border-white/20 focus:border-[#00F2FE] rounded-2xl text-center text-xl sm:text-2xl font-black text-white focus:outline-none focus:ring-2 focus:ring-[#00F2FE]/40 transition shadow-inner"
                    />
                  ))}
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    New Secure Password:
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="Min 6 characters"
                    className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Confirm New Password:
                  </label>
                  <input
                    type="password"
                    value={confirmNewPassword}
                    onChange={(e) => {
                      setConfirmNewPassword(e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="Re-enter new password"
                    className="w-full bg-[#111827] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:outline-none focus:border-[#00F2FE]/60 transition"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={resetOtpDigits.some((d) => !d)}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#00F2FE] to-[#10B981] text-black font-black text-sm shadow-[0_0_20px_rgba(0,242,254,0.3)] hover:opacity-95 transition flex items-center justify-center gap-2 mt-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Update Password & Sign In</span>
                </button>
              </form>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setErrorMsg(null);
                    setView('SIGN_IN');
                  }}
                  className="text-xs text-slate-400 hover:text-white flex items-center justify-center gap-1.5 mx-auto font-semibold cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Cancel & Return to Sign In</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
