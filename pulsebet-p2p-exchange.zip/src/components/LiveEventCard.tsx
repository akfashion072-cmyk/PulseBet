import React, { useState } from 'react';
import {
  ShieldCheck,
  Users,
  Clock,
  Share2,
  Trash2,
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  Lock,
} from 'lucide-react';
import { BetSide, Currency, Market, User } from '../types';
import { storageService } from '../services/storageService';

interface LiveEventCardProps {
  market: Market;
  currentUser: User | null;
  currency: Currency;
  onTradeClick: (market: Market, side: BetSide) => void;
  onAdminDeleteClick?: (market: Market) => void;
}

export const LiveEventCard: React.FC<LiveEventCardProps> = ({
  market,
  currentUser,
  currency,
  onTradeClick,
  onAdminDeleteClick,
}) => {
  const [copied, setCopied] = useState(false);

  // Parimutuel probability calculations
  const totalVolume = market.totalVolume || market.yesPool + market.noPool;
  const yesProb = totalVolume > 0 ? Math.round((market.yesPool / totalVolume) * 100) : 50;
  const noProb = 100 - yesProb;

  // Approximate multiplier preview based on adaptive parimutuel
  const yesQuote = storageService.calculateParimutuelQuote(market, 'YES', 100);
  const noQuote = storageService.calculateParimutuelQuote(market, 'NO', 100);

  const isResolved = market.status === 'RESOLVED' || market.status.startsWith('RESOLVED');
  const isCancelled = market.status === 'CANCELLED';
  const winningSide =
    market.winningOption ||
    (market.status === 'RESOLVED_YES' ? 'YES' : market.status === 'RESOLVED_NO' ? 'NO' : undefined);

  // Auto-Detect Location & State Compliance Guard
  const isRestricted = storageService.isUserInRestrictedState(currentUser);
  const userDetectedState = storageService.getUserDetectedState(currentUser);

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    const shareText = `Check out this P2P prediction market on PulseBet: "${market.title}"${
      market.roomCode ? ` (Room Code: #${market.roomCode})` : ''
    }\n${window.location.origin}?market=${market.id}`;

    if (navigator.share) {
      navigator.share({
        title: market.title,
        text: shareText,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      className={`group relative rounded-2xl glass-card border transition-all duration-300 p-5 flex flex-col justify-between overflow-hidden shadow-lg ${
        isResolved
          ? 'border-white/10 bg-[#0B0F17]/95 opacity-90'
          : 'border-white/10 hover:border-[#00F2FE]/40 hover:shadow-[0_0_30px_rgba(0,242,254,0.15)]'
      }`}
    >
      {/* Top Banner / Tags */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          {/* Creator Badge: Official vs Custom Friend Room */}
          {market.isOfficialAdmin ? (
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#00F2FE]/15 border border-[#00F2FE]/30 text-[#00F2FE] text-[11px] font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Official Market</span>
            </div>
          ) : (
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#10B981]/15 border border-[#10B981]/30 text-[#10B981] text-[11px] font-bold">
              {market.creatorAvatar ? (
                <img
                  src={market.creatorAvatar}
                  alt={market.creatorName}
                  className="w-4 h-4 rounded-full object-cover"
                />
              ) : (
                <Users className="w-3.5 h-3.5" />
              )}
              <span>Created by @{market.creatorName}</span>
              <span className="text-[9px] px-1 bg-[#F59E0B]/20 text-[#F59E0B] rounded font-bold">
                15% Royalty
              </span>
            </div>
          )}

          <div className="flex items-center gap-1.5">
            {/* Resolved Locked Status Icon */}
            {isResolved && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#10B981]/20 text-[#10B981] text-[10px] font-bold border border-[#10B981]/40">
                <Lock className="w-3 h-3" />
                <span>RESOLVED</span>
              </span>
            )}

            {/* Private Room indicator */}
            {market.isPrivate && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[10px] font-bold border border-amber-500/20">
                <Lock className="w-3 h-3" />
                <span>Private</span>
              </span>
            )}

            {/* Room Code Badge */}
            {market.roomCode && (
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-white/5 border border-white/10 text-slate-300">
                #{market.roomCode}
              </span>
            )}

            {/* Share button */}
            <button
              onClick={handleShare}
              className="p-1.5 rounded-lg bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 transition text-xs"
              title="Share Room / Market"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
            {copied && (
              <span className="text-[10px] text-[#10B981] font-bold absolute right-14 top-5 bg-[#0B0F17] px-2 py-0.5 rounded border border-[#10B981]/40">
                Copied!
              </span>
            )}

            {/* Universal Admin Deletion Controls: Red Trash Icon for Super Admin */}
            {currentUser?.isAdmin && onAdminDeleteClick && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAdminDeleteClick(market);
                }}
                className="p-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/30 transition text-xs"
                title="Universal Admin Deletion & 100% Escrow Refund"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Title */}
        <h3 className="text-base font-extrabold text-white leading-snug group-hover:text-[#00F2FE] transition duration-200">
          {market.title}
        </h3>

        {/* Description */}
        <p className="mt-1.5 text-xs text-slate-400 line-clamp-2 leading-relaxed">
          {market.description}
        </p>

        {/* Status Alert if Cancelled or Resolved */}
        {isCancelled && (
          <div className="mt-3 p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <div>
              <span className="font-bold">Cancelled & 100% Refunded:</span>{' '}
              {market.cancellationReason || 'Admin administrative override.'}
            </div>
          </div>
        )}

        {isResolved && (
          <div className="mt-3 p-2.5 rounded-xl bg-[#10B981]/15 border border-[#10B981]/30 text-xs text-[#10B981] flex items-center justify-between shadow-[0_0_15px_rgba(16,185,129,0.15)]">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-[#10B981]" />
              <div>
                <span className="font-extrabold text-white">
                  Concluded & Resolved: [{winningSide || 'SETTLED'}] Won
                </span>
                <p className="text-[10px] text-slate-300">
                  Escrow payouts disbursed with 1.01x minimum guarantee
                </p>
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded font-black bg-[#10B981]/20 border border-[#10B981]/40 text-[#10B981]">
              LOCKED
            </span>
          </div>
        )}

        {/* State Compliance Guard Alert */}
        {!isResolved && isRestricted && (
          <div className="mt-3 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <div>
              <span className="font-bold">⚠️ Real-Money Trading Restricted in {userDetectedState}</span>
              <p className="text-[10px] text-slate-300">View-only feed browsing active</p>
            </div>
          </div>
        )}
      </div>

      {/* Middle: Dynamic Probability Bar */}
      <div className="my-4 space-y-2">
        <div className="flex justify-between items-center text-xs font-bold">
          <span className="text-[#00F2FE] flex items-center gap-1">
            YES <span className="text-white">{yesProb}%</span>
          </span>
          <span className="text-slate-400 text-[11px] font-medium">
            Parimutuel Odds
          </span>
          <span className="text-rose-400 flex items-center gap-1">
            <span className="text-white">{noProb}%</span> NO
          </span>
        </div>

        {/* High-Contrast Dual Progress Bar */}
        <div className="w-full h-3 rounded-full bg-slate-800/80 overflow-hidden flex p-0.5 border border-white/5">
          <div
            style={{ width: `${yesProb}%` }}
            className="h-full bg-gradient-to-r from-[#00F2FE] to-[#00c6ff] rounded-l-full transition-all duration-500 shadow-[0_0_10px_rgba(0,242,254,0.5)]"
          />
          <div
            style={{ width: `${noProb}%` }}
            className="h-full bg-gradient-to-r from-[#f43f5e] to-[#fb7185] rounded-r-full transition-all duration-500 shadow-[0_0_10px_rgba(244,63,94,0.5)]"
          />
        </div>

        {/* Volume & Category details */}
        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
          <div className="flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-[#10B981]" />
            <span>Pool: <strong className="text-slate-200">{storageService.formatAmount(totalVolume, currency)}</strong></span>
          </div>

          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>
              {new Date(market.resolvesAt).toLocaleDateString('en-IN', {
                month: 'short',
                day: 'numeric',
              })}
            </span>
          </div>
        </div>
      </div>

      {/* Action Buttons: YES / NO (Locked if resolved or restricted) */}
      <div className="grid grid-cols-2 gap-2.5 pt-1">
        {isResolved ? (
          <>
            <button
              disabled
              className={`flex flex-col items-center justify-center py-2.5 px-2.5 rounded-xl text-center cursor-not-allowed ${
                winningSide === 'YES'
                  ? 'bg-[#10B981]/20 border border-[#10B981]/50 text-[#10B981] font-black'
                  : 'bg-white/5 border border-white/10 text-slate-500 opacity-50'
              }`}
            >
              <span className="text-xs font-black">
                {winningSide === 'YES' ? '🏆 YES WON' : 'NO (Concluded)'}
              </span>
              <span className="text-[10px] mt-0.5">
                {winningSide === 'YES' ? '1.01x Payout Disbursed' : 'Market Closed'}
              </span>
            </button>

            <button
              disabled
              className={`flex flex-col items-center justify-center py-2.5 px-2.5 rounded-xl text-center cursor-not-allowed ${
                winningSide === 'NO'
                  ? 'bg-[#10B981]/20 border border-[#10B981]/50 text-[#10B981] font-black'
                  : 'bg-white/5 border border-white/10 text-slate-500 opacity-50'
              }`}
            >
              <span className="text-xs font-black">
                {winningSide === 'NO' ? '🏆 NO WON' : 'YES (Concluded)'}
              </span>
              <span className="text-[10px] mt-0.5">
                {winningSide === 'NO' ? '1.01x Payout Disbursed' : 'Market Closed'}
              </span>
            </button>
          </>
        ) : isRestricted ? (
          <>
            <button
              disabled
              className="flex flex-col items-center justify-center py-2.5 px-2 rounded-xl bg-slate-800/60 border border-slate-700 text-slate-500 cursor-not-allowed text-center opacity-60"
            >
              <span className="text-xs font-bold">BUY YES</span>
              <span className="text-[9px] text-amber-400/80 mt-0.5">Restricted in {userDetectedState}</span>
            </button>
            <button
              disabled
              className="flex flex-col items-center justify-center py-2.5 px-2 rounded-xl bg-slate-800/60 border border-slate-700 text-slate-500 cursor-not-allowed text-center opacity-60"
            >
              <span className="text-xs font-bold">BUY NO</span>
              <span className="text-[9px] text-amber-400/80 mt-0.5">Restricted in {userDetectedState}</span>
            </button>
          </>
        ) : (
          <>
            <button
              disabled={market.status !== 'OPEN'}
              onClick={() => onTradeClick(market, 'YES')}
              className="flex flex-col items-center justify-center py-2 px-2.5 rounded-xl bg-[#00F2FE]/10 border border-[#00F2FE]/30 text-[#00F2FE] hover:bg-[#00F2FE] hover:text-black hover:shadow-[0_0_20px_rgba(0,242,254,0.4)] transition duration-200 disabled:opacity-40 disabled:cursor-not-allowed group/btn text-center"
            >
              <div className="flex items-center gap-1 text-xs font-black">
                <span>BUY YES</span>
              </div>
              {market.yesMeaning && (
                <span className="text-[9px] text-slate-300 group-hover/btn:text-black truncate max-w-[125px] font-medium leading-tight">
                  {market.yesMeaning}
                </span>
              )}
              <span className="text-[10px] text-slate-400 group-hover/btn:text-black font-semibold mt-0.5">
                Payout ~{yesQuote.multiplier}x
              </span>
            </button>

            <button
              disabled={market.status !== 'OPEN'}
              onClick={() => onTradeClick(market, 'NO')}
              className="flex flex-col items-center justify-center py-2 px-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 hover:bg-rose-500 hover:text-white hover:shadow-[0_0_20px_rgba(244,63,94,0.4)] transition duration-200 disabled:opacity-40 disabled:cursor-not-allowed group/btn2 text-center"
            >
              <div className="flex items-center gap-1 text-xs font-black">
                <span>BUY NO</span>
              </div>
              {market.noMeaning && (
                <span className="text-[9px] text-slate-300 group-hover/btn2:text-white truncate max-w-[125px] font-medium leading-tight">
                  {market.noMeaning}
                </span>
              )}
              <span className="text-[10px] text-slate-400 group-hover/btn2:text-white font-semibold mt-0.5">
                Payout ~{noQuote.multiplier}x
              </span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};
